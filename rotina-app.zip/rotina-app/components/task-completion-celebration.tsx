"use client"

import { useEffect, useRef } from "react"
import confetti from "canvas-confetti"
import { useMascotContext } from "@/context/mascot-context"

interface TaskCompletionCelebrationProps {
  taskName: string
  onComplete?: () => void
}

export function TaskCompletionCelebration({ taskName, onComplete }: TaskCompletionCelebrationProps) {
  const { playCelebrationSequence } = useMascotContext()
  const confettiRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    // Iniciar a sequência de celebração do mascote
    playCelebrationSequence(`a tarefa "${taskName}"`)

    // Disparar confetti
    if (confettiRef.current) {
      const myConfetti = confetti.create(confettiRef.current, {
        resize: true,
        useWorker: true,
      })

      // Disparo inicial
      myConfetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      })

      // Disparo em cascata
      setTimeout(() => {
        myConfetti({
          particleCount: 50,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
        })
      }, 250)

      setTimeout(() => {
        myConfetti({
          particleCount: 50,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
        })
      }, 400)

      // Notificar quando a animação estiver completa
      setTimeout(() => {
        if (onComplete) {
          onComplete()
        }
      }, 3000)
    }
  }, [taskName, playCelebrationSequence, onComplete])

  return (
    <canvas
      ref={confettiRef}
      className="fixed inset-0 pointer-events-none z-40"
      style={{ width: "100%", height: "100%" }}
    />
  )
}
