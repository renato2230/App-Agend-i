"use client"

import { CheckCircle, Clock, ListChecks, Repeat } from "lucide-react"
import { useSupabaseData } from "@/hooks/use-supabase-data"
import { useAuth } from "@/context/auth-context"

export default function DashboardStats() {
  const { isTestUser } = useAuth()
  const { data: statsData } = useSupabaseData("stats", [])
  const { data: routines } = useSupabaseData("routines", [])
  const { data: tasks } = useSupabaseData("tasks", [])

  // Dados para o usuário de teste
  const testStats = {
    tarefas_completas_total: 12,
    dias_consecutivos: 3,
  }

  // Usar dados do Supabase ou valores padrão
  const stats = [
    {
      title: "Rotinas Ativas",
      value: isTestUser ? "4" : routines.length.toString(),
      icon: ListChecks,
      color: "bg-primary",
    },
    {
      title: "Tarefas Concluídas",
      value: isTestUser
        ? testStats.tarefas_completas_total.toString()
        : statsData.length > 0
          ? statsData[0].tarefas_completas_total.toString()
          : "0",
      icon: CheckCircle,
      color: "bg-green-500",
    },
    {
      title: "Próximas Tarefas",
      value: isTestUser ? "5" : tasks.filter((task) => !task.completed).length.toString(),
      icon: Clock,
      color: "bg-amber-500",
    },
    {
      title: "Sequência Atual",
      value: isTestUser
        ? `${testStats.dias_consecutivos} dias`
        : statsData.length > 0
          ? `${statsData[0].dias_consecutivos} dias`
          : "0 dias",
      icon: Repeat,
      color: "bg-purple-500",
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat) => (
        <div key={stat.title} className="bg-card rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className={`p-3 rounded-full ${stat.color}`}>
              <stat.icon className="h-6 w-6 text-white" />
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-semibold">{stat.title}</h3>
              <p className="text-2xl font-bold">{stat.value}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
