"use client"

import { useState } from "react"
import { useSupabaseData } from "@/hooks/use-supabase-data"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { ChevronLeft, ChevronRight } from "lucide-react"
import RoutineForm from "@/components/routine-form"
import TaskForm from "@/components/task-form"

interface RoutinesCalendarProps {
  filterFrequency?: string
}

export default function RoutinesCalendar({ filterFrequency }: RoutinesCalendarProps) {
  const { data: routines, fetchData } = useSupabaseData("routines", [])
  const { data: tasks } = useSupabaseData("tasks", [])
  const [currentDate, setCurrentDate] = useState(new Date())
  const [selectedRoutine, setSelectedRoutine] = useState<any>(null)
  const [showTaskForm, setShowTaskForm] = useState(false)

  // Filtrar rotinas com base na frequência, se fornecida
  const filteredRoutines = filterFrequency
    ? routines.filter((routine) => routine.frequency === filterFrequency)
    : routines

  // Funções para navegação no calendário
  const goToPreviousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1))
  }

  const goToNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1))
  }

  const goToToday = () => {
    setCurrentDate(new Date())
  }

  // Obter dias do mês atual
  const getDaysInMonth = () => {
    const year = currentDate.getFullYear()
    const month = currentDate.getMonth()
    const firstDay = new Date(year, month, 1)
    const lastDay = new Date(year, month + 1, 0)
    const daysInMonth = lastDay.getDate()
    const startingDayOfWeek = firstDay.getDay()

    const days = []
    // Adicionar dias vazios para preencher o início do calendário
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push({ day: null, isCurrentMonth: false })
    }

    // Adicionar os dias do mês
    for (let day = 1; day <= daysInMonth; day++) {
      days.push({ day, isCurrentMonth: true })
    }

    return days
  }

  // Verificar se uma rotina deve ser exibida em um determinado dia
  const shouldShowRoutineOnDay = (routine: any, day: number) => {
    if (!day) return false

    const routineDate = new Date(routine.created_at)
    const currentYear = currentDate.getFullYear()
    const currentMonth = currentDate.getMonth()

    switch (routine.frequency) {
      case "Diária":
        return true
      case "Semanal":
        // Exibir em dias que correspondem ao dia da semana da criação
        const dayOfWeek = new Date(currentYear, currentMonth, day).getDay()
        return dayOfWeek === routineDate.getDay()
      case "Mensal":
        // Exibir no mesmo dia do mês da criação
        return day === routineDate.getDate()
      default:
        return false
    }
  }

  // Obter rotinas para um dia específico
  const getRoutinesForDay = (day: number | null) => {
    if (!day) return []
    return filteredRoutines.filter((routine) => shouldShowRoutineOnDay(routine, day))
  }

  // Formatar nome do mês
  const formatMonth = () => {
    return new Intl.DateTimeFormat("pt-BR", { month: "long", year: "numeric" }).format(currentDate)
  }

  // Verificar se um dia é hoje
  const isToday = (day: number | null) => {
    if (!day) return false
    const today = new Date()
    return (
      day === today.getDate() &&
      currentDate.getMonth() === today.getMonth() &&
      currentDate.getFullYear() === today.getFullYear()
    )
  }

  const days = getDaysInMonth()

  return (
    <>
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-lg font-medium capitalize">{formatMonth()}</h2>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={goToPreviousMonth}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={goToToday}>
              Hoje
            </Button>
            <Button variant="outline" size="sm" onClick={goToNextMonth}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-1">
          {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"].map((day) => (
            <div key={day} className="text-center text-sm font-medium py-2">
              {day}
            </div>
          ))}

          {days.map((day, index) => {
            const routinesForDay = day.day ? getRoutinesForDay(day.day) : []
            return (
              <Card
                key={index}
                className={`min-h-[100px] ${
                  !day.isCurrentMonth ? "opacity-40" : isToday(day.day) ? "border-primary" : ""
                }`}
              >
                <CardContent className="p-1">
                  {day.day && (
                    <div className="flex flex-col h-full">
                      <div
                        className={`text-right text-sm p-1 ${
                          isToday(day.day) ? "bg-primary text-primary-foreground rounded-sm" : ""
                        }`}
                      >
                        {day.day}
                      </div>
                      <div className="flex-1 overflow-y-auto max-h-24">
                        {routinesForDay.map((routine) => {
                          const routineTasks = tasks.filter((task) => task.routine_id === routine.id)
                          const completedTasks = routineTasks.filter((task) => task.completed).length
                          const allCompleted = completedTasks === routineTasks.length && routineTasks.length > 0

                          return (
                            <div
                              key={routine.id}
                              className={`text-xs p-1 mb-1 rounded cursor-pointer truncate ${
                                allCompleted ? "bg-green-100 dark:bg-green-900/20" : "bg-muted"
                              }`}
                              onClick={() => setSelectedRoutine(routine)}
                            >
                              {routine.name}
                            </div>
                          )
                        })}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>

      {/* Modal de detalhes da rotina */}
      <Dialog open={!!selectedRoutine} onOpenChange={(open) => !open && setSelectedRoutine(null)}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{selectedRoutine?.name}</DialogTitle>
          </DialogHeader>
          {selectedRoutine && (
            <div className="space-y-4">
              <div className="flex flex-wrap gap-2">
                <Badge>{selectedRoutine.category}</Badge>
                <Badge variant="outline">{selectedRoutine.frequency}</Badge>
              </div>

              {selectedRoutine.description && <p className="text-sm">{selectedRoutine.description}</p>}

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Tarefas</h3>
                <div className="space-y-2">
                  {tasks
                    .filter((task) => task.routine_id === selectedRoutine.id)
                    .map((task) => (
                      <div key={task.id} className="flex items-center justify-between bg-muted p-2 rounded-md">
                        <div className="flex items-center gap-2">
                          <div
                            className={`w-3 h-3 rounded-full ${
                              task.completed ? "bg-green-500" : "bg-gray-300 dark:bg-gray-600"
                            }`}
                          ></div>
                          <span className={task.completed ? "line-through text-muted-foreground" : ""}>
                            {task.name}
                          </span>
                        </div>
                        <Badge variant="outline">{task.priority}</Badge>
                      </div>
                    ))}

                  {tasks.filter((task) => task.routine_id === selectedRoutine.id).length === 0 && (
                    <p className="text-sm text-muted-foreground">Nenhuma tarefa cadastrada.</p>
                  )}
                </div>

                <div className="flex justify-between pt-2">
                  <Button variant="outline" onClick={() => setSelectedRoutine(null)}>
                    Fechar
                  </Button>
                  <div className="space-x-2">
                    <Button variant="outline" onClick={() => setShowTaskForm(true)}>
                      Adicionar Tarefa
                    </Button>
                    <Button onClick={() => setSelectedRoutine({ ...selectedRoutine, isEditing: true })}>
                      Editar Rotina
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Modal de edição de rotina */}
      <Dialog
        open={!!selectedRoutine?.isEditing}
        onOpenChange={(open) => !open && setSelectedRoutine((prev: any) => ({ ...prev, isEditing: false }))}
      >
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Editar Rotina</DialogTitle>
          </DialogHeader>
          {selectedRoutine && (
            <RoutineForm
              routine={selectedRoutine}
              onSuccess={() => {
                fetchData()
                setSelectedRoutine(null)
              }}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Modal de adição de tarefa */}
      <Dialog open={showTaskForm} onOpenChange={setShowTaskForm}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Adicionar Tarefa</DialogTitle>
          </DialogHeader>
          {selectedRoutine && (
            <TaskForm
              routineId={selectedRoutine.id}
              onSuccess={() => {
                fetchData()
                setShowTaskForm(false)
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}
