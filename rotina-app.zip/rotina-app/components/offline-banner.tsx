"use client"

import { useOnlineStatus } from "@/hooks/use-online-status"
import { Wifi, WifiOff } from "lucide-react"
import { useEffect, useState } from "react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export function OfflineBanner() {
  const isOnline = useOnlineStatus()
  const [showReconnected, setShowReconnected] = useState(false)

  useEffect(() => {
    if (isOnline) {
      // Se voltou a ficar online, mostrar mensagem por alguns segundos
      setShowReconnected(true)
      const timer = setTimeout(() => {
        setShowReconnected(false)
      }, 3000)

      return () => clearTimeout(timer)
    }
  }, [isOnline])

  if (isOnline && !showReconnected) return null

  return (
    <div className="fixed bottom-4 left-4 right-4 z-50 max-w-md mx-auto">
      {!isOnline ? (
        <Alert variant="destructive">
          <WifiOff className="h-4 w-4" />
          <AlertTitle>Você está offline</AlertTitle>
          <AlertDescription>
            Algumas funcionalidades podem estar limitadas. Suas alterações serão sincronizadas quando a conexão for
            restabelecida.
          </AlertDescription>
        </Alert>
      ) : (
        <Alert
          variant="default"
          className="bg-green-50 border-green-200 text-green-800 dark:bg-green-900 dark:border-green-800 dark:text-green-100"
        >
          <Wifi className="h-4 w-4" />
          <AlertTitle>Conexão restabelecida</AlertTitle>
          <AlertDescription>Você está online novamente. Suas alterações estão sendo sincronizadas.</AlertDescription>
        </Alert>
      )}
    </div>
  )
}
