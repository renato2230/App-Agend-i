"use client"

import { useState } from "react"
import { useSupabaseData } from "@/hooks/use-supabase-data"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, Edit, MoreVertical, Trash2, CheckCircle2 } from "lucide-react"
import RoutineForm from "@/components/routine-form"
import { useToast } from "@/components/ui/use-toast"

interface RoutinesGridProps {
  showActions?: boolean
  filterFrequency?: string
  limit?: number
}

export default function RoutinesGrid({ showActions = false, filterFrequency, limit }: RoutinesGridProps) {
  const { data: routines, updateItem, removeItem, fetchData } = useSupabaseData("routines", [])
  const { data: tasks } = useSupabaseData("tasks", [])
  const [editingRoutine, setEditingRoutine] = useState<any>(null)
  const { toast } = useToast()

  // Filtrar rotinas com base na frequência, se fornecida
  let filteredRoutines = filterFrequency
    ? routines.filter((routine) => routine.frequency === filterFrequency)
    : routines

  // Limitar o número de rotinas, se fornecido
  if (limit && filteredRoutines.length > limit) {
    filteredRoutines = filteredRoutines.slice(0, limit)
  }

  const handleDeleteRoutine = async (id: string) => {
    const success = await removeItem(id)
    if (success) {
      toast({
        title: "Rotina excluída",
        description: "A rotina foi excluída com sucesso.",
      })
    } else {
      toast({
        title: "Erro",
        description: "Não foi possível excluir a rotina.",
        variant: "destructive",
      })
    }
  }

  const handleEditRoutine = (routine: any) => {
    setEditingRoutine(routine)
  }

  const getTasksForRoutine = (routineId: string) => {
    return tasks.filter((task) => task.routine_id === routineId)
  }

  if (filteredRoutines.length === 0) {
    return (
      <div className="text-center py-10">
        <p className="text-muted-foreground">Nenhuma rotina encontrada.</p>
      </div>
    )
  }

  return (
    <>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredRoutines.map((routine) => {
          const routineTasks = getTasksForRoutine(routine.id)
          const completedTasks = routineTasks.filter((task) => task.completed).length
          const progress = routineTasks.length > 0 ? (completedTasks / routineTasks.length) * 100 : 0
          const categoryColors: Record<string, string> = {
            Trabalho: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
            Estudo: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
            Saúde: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
            Lazer: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300",
            Família: "bg-pink-100 text-pink-800 dark:bg-pink-900/30 dark:text-pink-300",
          }

          return (
            <Card key={routine.id} className="overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <h3 className="font-medium">{routine.name}</h3>
                  {showActions && (
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleEditRoutine(routine)}>
                          <Edit className="h-4 w-4 mr-2" />
                          Editar Rotina
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          className="text-destructive focus:text-destructive"
                          onClick={() => handleDeleteRoutine(routine.id)}
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Excluir Rotina
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  )}
                </div>
                <div className="flex flex-wrap gap-2 mt-1">
                  <Badge variant="outline" className={categoryColors[routine.category] || ""}>
                    {routine.category}
                  </Badge>
                  <Badge variant="outline">
                    <Clock className="h-3 w-3 mr-1" />
                    {routine.frequency}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="pb-2">
                {routine.description && (
                  <p className="text-sm text-muted-foreground line-clamp-2 mb-2">{routine.description}</p>
                )}

                <div className="mb-2">
                  <div className="flex justify-between items-center mb-1 text-xs">
                    <span>
                      {completedTasks}/{routineTasks.length} tarefas
                    </span>
                    <span>{Math.round(progress)}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary"
                      style={{ width: `${progress}%`, transition: "width 0.3s ease" }}
                    ></div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="pt-0">
                <div className="flex justify-between items-center w-full text-xs text-muted-foreground">
                  <div className="flex items-center">
                    <Calendar className="h-3 w-3 mr-1" />
                    {new Date(routine.created_at).toLocaleDateString()}
                  </div>
                  {completedTasks === routineTasks.length && routineTasks.length > 0 && (
                    <div className="flex items-center text-green-500">
                      <CheckCircle2 className="h-3 w-3 mr-1" />
                      Completa
                    </div>
                  )}
                </div>
              </CardFooter>
            </Card>
          )
        })}
      </div>

      {/* Modal de edição de rotina */}
      <Dialog open={!!editingRoutine} onOpenChange={(open) => !open && setEditingRoutine(null)}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Editar Rotina</DialogTitle>
          </DialogHeader>
          {editingRoutine && (
            <RoutineForm
              routine={editingRoutine}
              onSuccess={() => {
                fetchData()
                setEditingRoutine(null)
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}
