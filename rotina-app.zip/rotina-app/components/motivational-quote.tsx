"use client"

import { Quote } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { useMotivationalQuote } from "@/hooks/use-motivational-quote"
import { Skeleton } from "@/components/ui/skeleton"

export function MotivationalQuote() {
  const { quote, isLoading } = useMotivationalQuote()

  if (isLoading) {
    return (
      <Card className="border-none bg-gradient-to-r from-primary/10 to-primary/5">
        <CardContent className="p-4">
          <div className="flex items-start gap-4">
            <Quote className="h-8 w-8 text-primary/40 mt-1 flex-shrink-0" />
            <div className="space-y-2 w-full">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-3 w-1/3 mt-2" />
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (!quote) {
    return null
  }

  return (
    <Card className="border-none bg-gradient-to-r from-primary/10 to-primary/5">
      <CardContent className="p-4">
        <div className="flex items-start gap-4">
          <Quote className="h-8 w-8 text-primary/60 mt-1 flex-shrink-0" />
          <div>
            <p className="text-base font-medium">{quote.quote}</p>
            {quote.author && <p className="text-sm text-muted-foreground mt-2">— {quote.author}</p>}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
