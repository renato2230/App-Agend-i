"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { MascotIdle } from "./mascot-idle"
import { MascotHappy } from "./mascot-happy"
import { MascotThinking } from "./mascot-thinking"
import { MascotCelebrating } from "./mascot-celebrating"
import { MascotSleeping } from "./mascot-sleeping"
import { MascotWaving } from "./mascot-waving"
import type { MascotMood, MascotSize } from "./mascot"

interface MascotTransitionProps {
  currentMood: MascotMood
  previousMood?: MascotMood
  size?: MascotSize
  onTransitionComplete?: () => void
}

export function MascotTransition({
  currentMood,
  previousMood,
  size = "md",
  onTransitionComplete,
}: MascotTransitionProps) {
  const [isTransitioning, setIsTransitioning] = useState(false)
  const [displayedMood, setDisplayedMood] = useState<MascotMood>(currentMood)

  // Dimensões baseadas no tamanho
  const dimensions = {
    sm: { width: 80, height: 80 },
    md: { width: 120, height: 120 },
    lg: { width: 160, height: 160 },
  }

  useEffect(() => {
    if (currentMood !== displayedMood) {
      setIsTransitioning(true)

      // Após a animação de saída, mude para o novo humor
      const timer = setTimeout(() => {
        setDisplayedMood(currentMood)

        // Após a animação de entrada, notifique que a transição está completa
        const completeTimer = setTimeout(() => {
          setIsTransitioning(false)
          if (onTransitionComplete) {
            onTransitionComplete()
          }
        }, 300) // Duração da animação de entrada

        return () => clearTimeout(completeTimer)
      }, 300) // Duração da animação de saída

      return () => clearTimeout(timer)
    }
  }, [currentMood, displayedMood, onTransitionComplete])

  // Renderizar o mascote baseado no humor atual
  const renderMascot = (mood: MascotMood) => {
    switch (mood) {
      case "happy":
        return <MascotHappy width={dimensions[size].width} height={dimensions[size].height} />
      case "thinking":
        return <MascotThinking width={dimensions[size].width} height={dimensions[size].height} />
      case "celebrating":
        return <MascotCelebrating width={dimensions[size].width} height={dimensions[size].height} />
      case "sleeping":
        return <MascotSleeping width={dimensions[size].width} height={dimensions[size].height} />
      case "waving":
        return <MascotWaving width={dimensions[size].width} height={dimensions[size].height} />
      case "idle":
      default:
        return <MascotIdle width={dimensions[size].width} height={dimensions[size].height} />
    }
  }

  // Variantes de animação para diferentes transições
  const getTransitionVariants = (from?: MascotMood, to?: MascotMood) => {
    // Transições específicas baseadas nos estados de e para
    if (from === "idle" && to === "happy") {
      return {
        exit: {
          scale: [1, 1.2, 0.8],
          opacity: [1, 0.8, 0],
          rotate: [0, 10, 0],
          transition: { duration: 0.3 },
        },
        initial: {
          scale: 0.8,
          opacity: 0,
          rotate: 0,
        },
        animate: {
          scale: [0.8, 1.2, 1],
          opacity: [0, 0.8, 1],
          rotate: [0, -10, 0],
          transition: { duration: 0.3 },
        },
      }
    }

    if (from === "idle" && to === "thinking") {
      return {
        exit: {
          scale: [1, 0.9],
          opacity: [1, 0],
          y: [0, 10],
          transition: { duration: 0.3 },
        },
        initial: {
          scale: 0.9,
          opacity: 0,
          y: 10,
        },
        animate: {
          scale: [0.9, 1],
          opacity: [0, 1],
          y: [10, 0],
          transition: { duration: 0.3 },
        },
      }
    }

    if (from === "idle" && to === "celebrating") {
      return {
        exit: {
          scale: [1, 0.8],
          opacity: [1, 0],
          y: [0, 20],
          transition: { duration: 0.3 },
        },
        initial: {
          scale: 0.8,
          opacity: 0,
          y: -20,
        },
        animate: {
          scale: [0.8, 1.2, 1],
          opacity: [0, 1],
          y: [-20, 0],
          transition: { duration: 0.4, ease: "easeOut" },
        },
      }
    }

    if (to === "sleeping") {
      return {
        exit: {
          scale: [1, 0.9],
          opacity: [1, 0],
          rotate: [0, -5],
          transition: { duration: 0.4 },
        },
        initial: {
          scale: 0.9,
          opacity: 0,
          rotate: 5,
        },
        animate: {
          scale: [0.9, 1],
          opacity: [0, 1],
          rotate: [5, 0],
          transition: { duration: 0.4, ease: "easeInOut" },
        },
      }
    }

    if (from === "sleeping") {
      return {
        exit: {
          scale: [1, 0.9],
          opacity: [1, 0],
          rotate: [0, 5],
          transition: { duration: 0.3 },
        },
        initial: {
          scale: 0.9,
          opacity: 0,
          rotate: -5,
        },
        animate: {
          scale: [0.9, 1.05, 1],
          opacity: [0, 1],
          rotate: [-5, 0],
          transition: { duration: 0.4 },
        },
      }
    }

    if (to === "waving") {
      return {
        exit: {
          scale: [1, 0.9],
          opacity: [1, 0],
          x: [0, -10],
          transition: { duration: 0.3 },
        },
        initial: {
          scale: 0.9,
          opacity: 0,
          x: 10,
        },
        animate: {
          scale: [0.9, 1],
          opacity: [0, 1],
          x: [10, 0],
          transition: { duration: 0.3 },
        },
      }
    }

    // Transição padrão
    return {
      exit: {
        scale: [1, 0.9],
        opacity: [1, 0],
        transition: { duration: 0.3 },
      },
      initial: {
        scale: 0.9,
        opacity: 0,
      },
      animate: {
        scale: [0.9, 1],
        opacity: [0, 1],
        transition: { duration: 0.3 },
      },
    }
  }

  const variants = getTransitionVariants(previousMood, currentMood)

  return (
    <div className="relative">
      <AnimatePresence mode="wait">
        <motion.div
          key={displayedMood}
          initial={variants.initial}
          animate={variants.animate}
          exit={variants.exit}
          className="relative"
        >
          {renderMascot(displayedMood)}
        </motion.div>
      </AnimatePresence>
    </div>
  )
}
