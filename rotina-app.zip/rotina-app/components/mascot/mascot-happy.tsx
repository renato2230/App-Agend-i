"use client"

import { motion } from "framer-motion"

interface MascotHappyProps {
  width?: number
  height?: number
}

export function MascotHappy({ width = 120, height = 120 }: MascotHappyProps) {
  return (
    <svg width={width} height={height} viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Corpo */}
      <motion.circle
        cx="100"
        cy="100"
        r="70"
        fill="#4CAF50"
        initial={{ scale: 1 }}
        animate={{ scale: [1, 1.05, 1] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1.5, ease: "easeInOut" }}
      />

      {/* Olhos felizes */}
      <motion.g
        initial={{ y: 0 }}
        animate={{ y: [0, -3, 0] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1.5, ease: "easeInOut" }}
      >
        {/* Olho esquerdo */}
        <path d="M65 80 Q75 70 85 80" stroke="white" strokeWidth="3" fill="none" />
        <path d="M65 90 Q75 100 85 90" stroke="white" strokeWidth="3" fill="none" />

        {/* Olho direito */}
        <path d="M115 80 Q125 70 135 80" stroke="white" strokeWidth="3" fill="none" />
        <path d="M115 90 Q125 100 135 90" stroke="white" strokeWidth="3" fill="none" />
      </motion.g>

      {/* Boca grande e feliz */}
      <motion.path
        d="M70 115 Q100 145 130 115"
        stroke="white"
        strokeWidth="4"
        fill="#388E3C"
        initial={{ d: "M70 115 Q100 145 130 115" }}
        animate={{ d: ["M70 115 Q100 145 130 115", "M70 120 Q100 150 130 120", "M70 115 Q100 145 130 115"] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1.5, ease: "easeInOut" }}
      />

      {/* Braços para cima */}
      <motion.g
        initial={{ rotate: 0 }}
        animate={{ rotate: [-10, 10, -10] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1, ease: "easeInOut" }}
        style={{ originX: "60px", originY: "100px" }}
      >
        <path d="M60 100 Q50 70 40 50" stroke="#388E3C" strokeWidth="8" strokeLinecap="round" fill="none" />
      </motion.g>

      <motion.g
        initial={{ rotate: 0 }}
        animate={{ rotate: [10, -10, 10] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1, ease: "easeInOut" }}
        style={{ originX: "140px", originY: "100px" }}
      >
        <path d="M140 100 Q150 70 160 50" stroke="#388E3C" strokeWidth="8" strokeLinecap="round" fill="none" />
      </motion.g>

      {/* Relógio na barriga */}
      <circle cx="100" cy="110" r="15" fill="white" stroke="#388E3C" strokeWidth="2" />
      <line x1="100" y1="110" x2="100" y2="100" stroke="#388E3C" strokeWidth="2" />
      <line x1="100" y1="110" x2="108" y2="110" stroke="#388E3C" strokeWidth="2" />
    </svg>
  )
}
