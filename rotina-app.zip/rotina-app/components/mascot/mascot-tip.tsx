"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Mascot } from "./mascot"
import { X } from "lucide-react"
import { motion } from "framer-motion"
import { useMascotContext } from "@/context/mascot-context"

interface MascotTipProps {
  tips: string[]
  interval?: number
  onClose?: () => void
}

export function MascotTip({ tips, interval = 0, onClose }: MascotTipProps) {
  const [currentTipIndex, setCurrentTipIndex] = useState(0)
  const [isVisible, setIsVisible] = useState(true)
  const { makeThinking, makeHappy } = useMascotContext()

  const currentTip = tips[currentTipIndex]

  // Alternar entre os estados de humor
  useEffect(() => {
    if (currentTipIndex % 2 === 0) {
      makeThinking()
    } else {
      makeHappy()
    }
  }, [currentTipIndex, makeThinking, makeHappy])

  // Alternar entre as dicas automaticamente se o intervalo for maior que 0
  useEffect(() => {
    if (interval > 0) {
      const timer = setInterval(() => {
        setCurrentTipIndex((prev) => (prev + 1) % tips.length)
      }, interval)
      return () => clearInterval(timer)
    }
  }, [interval, tips.length])

  const handleNext = () => {
    setCurrentTipIndex((prev) => (prev + 1) % tips.length)
  }

  const handleClose = () => {
    setIsVisible(false)
    if (onClose) onClose()
  }

  if (!isVisible) return null

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="relative"
    >
      <Card className="border-primary/20">
        <CardContent className="p-4">
          <div className="absolute top-2 right-2">
            <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={handleClose}>
              <X className="h-4 w-4" />
              <span className="sr-only">Fechar</span>
            </Button>
          </div>

          <div className="flex gap-4">
            <div className="flex-shrink-0">
              <Mascot mood={currentTipIndex % 2 === 0 ? "thinking" : "happy"} size="sm" />
            </div>
            <div className="flex-grow">
              <p className="text-sm mb-3">{currentTip}</p>
              {tips.length > 1 && (
                <div className="flex justify-between items-center">
                  <div className="flex gap-1">
                    {tips.map((_, index) => (
                      <div
                        key={index}
                        className={`h-1.5 w-1.5 rounded-full ${
                          index === currentTipIndex ? "bg-primary" : "bg-primary/30"
                        }`}
                      />
                    ))}
                  </div>
                  <Button variant="outline" size="sm" onClick={handleNext}>
                    Próxima dica
                  </Button>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
