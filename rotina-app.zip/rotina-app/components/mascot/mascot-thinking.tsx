"use client"

import { motion } from "framer-motion"

interface MascotThinkingProps {
  width?: number
  height?: number
}

export function MascotThinking({ width = 120, height = 120 }: MascotThinkingProps) {
  return (
    <svg width={width} height={height} viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Corpo */}
      <motion.circle
        cx="100"
        cy="100"
        r="70"
        fill="#4CAF50"
        initial={{ scale: 1 }}
        animate={{ scale: [1, 1.02, 1] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 3, ease: "easeInOut" }}
      />

      {/* Olhos pensativos */}
      <motion.g
        initial={{ y: 0 }}
        animate={{ y: [0, -1, 0, 1, 0] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 4, ease: "easeInOut" }}
      >
        {/* Olho esquerdo */}
        <circle cx="75" cy="85" r="10" fill="white" />
        <motion.circle
          cx="75"
          cy="85"
          r="5"
          fill="black"
          animate={{ cx: [75, 72, 75] }}
          transition={{ repeat: Number.POSITIVE_INFINITY, duration: 3, ease: "easeInOut" }}
        />

        {/* Olho direito */}
        <circle cx="125" cy="85" r="10" fill="white" />
        <motion.circle
          cx="125"
          cy="85"
          r="5"
          fill="black"
          animate={{ cx: [125, 122, 125] }}
          transition={{ repeat: Number.POSITIVE_INFINITY, duration: 3, ease: "easeInOut" }}
        />

        {/* Sobrancelha pensativa */}
        <motion.path
          d="M65 70 Q75 65 85 70"
          stroke="white"
          strokeWidth="3"
          fill="none"
          animate={{ d: ["M65 70 Q75 65 85 70", "M65 68 Q75 63 85 68", "M65 70 Q75 65 85 70"] }}
          transition={{ repeat: Number.POSITIVE_INFINITY, duration: 3, ease: "easeInOut" }}
        />
      </motion.g>

      {/* Boca pensativa */}
      <motion.path
        d="M85 120 Q100 115 115 120"
        stroke="white"
        strokeWidth="4"
        fill="none"
        animate={{ d: ["M85 120 Q100 115 115 120", "M85 118 Q100 113 115 118", "M85 120 Q100 115 115 120"] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 3, ease: "easeInOut" }}
      />

      {/* Braço pensativo */}
      <motion.g
        initial={{ rotate: 0 }}
        animate={{ rotate: [-2, 2, -2] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 3, ease: "easeInOut" }}
        style={{ originX: "60px", originY: "100px" }}
      >
        <path d="M60 100 Q50 80 60 60" stroke="#388E3C" strokeWidth="8" strokeLinecap="round" fill="none" />
      </motion.g>

      {/* Outro braço */}
      <motion.g
        initial={{ rotate: 0 }}
        animate={{ rotate: [0, -5, 0] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 3, ease: "easeInOut" }}
        style={{ originX: "140px", originY: "100px" }}
      >
        <path d="M140 100 Q150 110 155 130" stroke="#388E3C" strokeWidth="8" strokeLinecap="round" fill="none" />
      </motion.g>

      {/* Balão de pensamento */}
      <motion.g
        initial={{ opacity: 0 }}
        animate={{ opacity: [0, 1, 0] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 3, ease: "easeInOut", delay: 1 }}
      >
        <circle cx="150" cy="50" r="10" fill="white" />
        <circle cx="135" cy="60" r="6" fill="white" />
        <circle cx="125" cy="65" r="3" fill="white" />
      </motion.g>

      {/* Relógio na barriga */}
      <circle cx="100" cy="110" r="15" fill="white" stroke="#388E3C" strokeWidth="2" />
      <line x1="100" y1="110" x2="100" y2="100" stroke="#388E3C" strokeWidth="2" />
      <line x1="100" y1="110" x2="108" y2="110" stroke="#388E3C" strokeWidth="2" />
    </svg>
  )
}
