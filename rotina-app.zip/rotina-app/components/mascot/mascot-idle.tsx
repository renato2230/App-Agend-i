"use client"

import { motion } from "framer-motion"

interface MascotIdleProps {
  width?: number
  height?: number
}

export function MascotIdle({ width = 120, height = 120 }: MascotIdleProps) {
  return (
    <svg width={width} height={height} viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Corpo */}
      <motion.circle
        cx="100"
        cy="100"
        r="70"
        fill="#4CAF50"
        initial={{ scale: 1 }}
        animate={{ scale: [1, 1.05, 1] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 3, ease: "easeInOut" }}
      />

      {/* Olhos */}
      <motion.g
        initial={{ y: 0 }}
        animate={{ y: [0, -2, 0, 2, 0] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 3, ease: "easeInOut" }}
      >
        <circle cx="75" cy="85" r="10" fill="white" />
        <circle cx="125" cy="85" r="10" fill="white" />
        <circle cx="75" cy="85" r="5" fill="black" />
        <circle cx="125" cy="85" r="5" fill="black" />
      </motion.g>

      {/* Boca */}
      <motion.path
        d="M70 115 Q100 135 130 115"
        stroke="white"
        strokeWidth="4"
        fill="none"
        initial={{ d: "M70 115 Q100 135 130 115" }}
        animate={{ d: ["M70 115 Q100 135 130 115", "M70 120 Q100 140 130 120", "M70 115 Q100 135 130 115"] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 3, ease: "easeInOut" }}
      />

      {/* Braços */}
      <motion.g
        initial={{ rotate: 0 }}
        animate={{ rotate: [-5, 5, -5] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 2, ease: "easeInOut" }}
        style={{ originX: "90px", originY: "100px" }}
      >
        <path d="M40 100 Q30 110 25 130" stroke="#388E3C" strokeWidth="8" strokeLinecap="round" fill="none" />
      </motion.g>

      <motion.g
        initial={{ rotate: 0 }}
        animate={{ rotate: [5, -5, 5] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 2, ease: "easeInOut" }}
        style={{ originX: "110px", originY: "100px" }}
      >
        <path d="M160 100 Q170 110 175 130" stroke="#388E3C" strokeWidth="8" strokeLinecap="round" fill="none" />
      </motion.g>

      {/* Relógio na barriga */}
      <circle cx="100" cy="110" r="15" fill="white" stroke="#388E3C" strokeWidth="2" />
      <line x1="100" y1="110" x2="100" y2="100" stroke="#388E3C" strokeWidth="2" />
      <line x1="100" y1="110" x2="108" y2="110" stroke="#388E3C" strokeWidth="2" />
    </svg>
  )
}
