"use client"

import { motion } from "framer-motion"

interface MascotSleepingProps {
  width?: number
  height?: number
}

export function MascotSleeping({ width = 120, height = 120 }: MascotSleepingProps) {
  return (
    <svg width={width} height={height} viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Corpo */}
      <motion.circle
        cx="100"
        cy="100"
        r="70"
        fill="#4CAF50"
        initial={{ scale: 1 }}
        animate={{ scale: [1, 1.03, 1] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 4, ease: "easeInOut" }}
      />

      {/* Olhos fechados */}
      <motion.g>
        <path d="M65 85 Q75 80 85 85" stroke="white" strokeWidth="3" fill="none" />
        <path d="M115 85 Q125 80 135 85" stroke="white" strokeWidth="3" fill="none" />
      </motion.g>

      {/* Boca dormindo */}
      <motion.path d="M85 115 Q100 110 115 115" stroke="white" strokeWidth="3" fill="none" />

      {/* ZZZ animados */}
      <motion.g>
        <motion.text
          x="140"
          y="60"
          fontFamily="Arial"
          fontSize="20"
          fill="white"
          initial={{ opacity: 0, y: 0, x: 0 }}
          animate={{ opacity: [0, 1, 0], y: [-10, -20], x: [0, 10] }}
          transition={{ repeat: Number.POSITIVE_INFINITY, duration: 2, ease: "easeInOut" }}
        >
          Z
        </motion.text>
        <motion.text
          x="150"
          y="80"
          fontFamily="Arial"
          fontSize="16"
          fill="white"
          initial={{ opacity: 0, y: 0, x: 0 }}
          animate={{ opacity: [0, 1, 0], y: [-10, -20], x: [0, 10] }}
          transition={{ repeat: Number.POSITIVE_INFINITY, duration: 2, ease: "easeInOut", delay: 0.5 }}
        >
          Z
        </motion.text>
        <motion.text
          x="160"
          y="95"
          fontFamily="Arial"
          fontSize="12"
          fill="white"
          initial={{ opacity: 0, y: 0, x: 0 }}
          animate={{ opacity: [0, 1, 0], y: [-10, -20], x: [0, 10] }}
          transition={{ repeat: Number.POSITIVE_INFINITY, duration: 2, ease: "easeInOut", delay: 1 }}
        >
          z
        </motion.text>
      </motion.g>

      {/* Braços relaxados */}
      <motion.g
        initial={{ rotate: 0 }}
        animate={{ rotate: [-2, 2, -2] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 4, ease: "easeInOut" }}
        style={{ originX: "70px", originY: "100px" }}
      >
        <path d="M70 100 Q60 120 50 140" stroke="#388E3C" strokeWidth="8" strokeLinecap="round" fill="none" />
      </motion.g>

      <motion.g
        initial={{ rotate: 0 }}
        animate={{ rotate: [2, -2, 2] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 4, ease: "easeInOut" }}
        style={{ originX: "130px", originY: "100px" }}
      >
        <path d="M130 100 Q140 120 150 140" stroke="#388E3C" strokeWidth="8" strokeLinecap="round" fill="none" />
      </motion.g>

      {/* Relógio na barriga */}
      <circle cx="100" cy="110" r="15" fill="white" stroke="#388E3C" strokeWidth="2" />
      <motion.g
        animate={{ rotate: 360 }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 10, ease: "linear" }}
        style={{ originX: "100px", originY: "110px" }}
      >
        <line x1="100" y1="110" x2="100" y2="100" stroke="#388E3C" strokeWidth="2" />
        <line x1="100" y1="110" x2="108" y2="110" stroke="#388E3C" strokeWidth="2" />
      </motion.g>
    </svg>
  )
}
