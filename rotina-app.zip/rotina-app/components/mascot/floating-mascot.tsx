"use client"

import { useState, useEffect, useRef } from "react"
import { motion, useMotionValue, useTransform, animate } from "framer-motion"
import { Mascot } from "./mascot"
import { useMascotContext } from "@/context/mascot-context"
import { cn } from "@/lib/utils"

interface FloatingMascotProps {
  className?: string
  size?: "sm" | "md" | "lg"
  initialPosition?: { x: number; y: number }
}

export function FloatingMascot({ className, size = "md", initialPosition = { x: 20, y: 20 } }: FloatingMascotProps) {
  const { mood, message, isVisible, toggleMascot } = useMascotContext()
  const [isDragging, setIsDragging] = useState(false)
  const constraintsRef = useRef<HTMLDivElement>(null)

  // Posição do mascote
  const x = useMotionValue(initialPosition.x)
  const y = useMotionValue(initialPosition.y)

  // Efeito de flutuação
  const floatY = useTransform(useMotionValue(0), [0, 1], [0, 10])

  // Animar a flutuação
  useEffect(() => {
    const floatAnimation = animate(floatY.source, [0, 1, 0], {
      duration: 4,
      ease: "easeInOut",
      repeat: Number.POSITIVE_INFINITY,
    })

    return () => floatAnimation.stop()
  }, [floatY])

  // Aplicar o efeito de flutuação apenas quando não estiver arrastando
  const currentY = useTransform([y, floatY], ([baseY, float]) => (isDragging ? baseY : baseY + float))

  return (
    <div ref={constraintsRef} className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      <motion.div
        drag
        dragMomentum={false}
        dragElastic={0.1}
        style={{ x, y: currentY }}
        onDragStart={() => setIsDragging(true)}
        onDragEnd={() => setIsDragging(false)}
        className={cn("absolute pointer-events-auto", className)}
        transition={{ type: "spring", damping: 20 }}
        whileDrag={{ scale: 1.05 }}
        dragConstraints={constraintsRef}
      >
        <Mascot
          mood={mood}
          message={message}
          size={size}
          onMascotClick={toggleMascot}
          className={cn("transition-all duration-300", isDragging ? "cursor-grabbing" : "cursor-grab")}
        />
      </motion.div>
    </div>
  )
}
