"use client"

import { useState, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { MascotTransition } from "./mascot-transition"
import { cn } from "@/lib/utils"
import { useSoundContext } from "@/context/sound-context"

export type MascotMood = "idle" | "happy" | "thinking" | "celebrating" | "sleeping" | "waving"
export type MascotSize = "sm" | "md" | "lg"

interface MascotProps {
  mood?: MascotMood
  size?: MascotSize
  message?: string
  autoHide?: boolean
  hideAfter?: number
  className?: string
  onMascotClick?: () => void
  playSounds?: boolean
}

export function Mascot({
  mood = "idle",
  size = "md",
  message,
  autoHide = false,
  hideAfter = 5000,
  className,
  onMascotClick,
  playSounds = true,
}: MascotProps) {
  const [isVisible, setIsVisible] = useState(true)
  const [currentMood, setCurrentMood] = useState<MascotMood>(mood)
  const [previousMood, setPreviousMood] = useState<MascotMood | undefined>(undefined)
  const [isTransitioning, setIsTransitioning] = useState(false)
  const [currentMessage, setCurrentMessage] = useState(message)
  const moodQueueRef = useRef<MascotMood[]>([])
  const { playSound, isEnabled, loadedSounds } = useSoundContext()
  const previousMoodRef = useRef<MascotMood | undefined>(undefined)

  // Atualizar o humor quando a prop mudar
  useEffect(() => {
    if (mood !== currentMood && !isTransitioning) {
      setPreviousMood(currentMood)
      previousMoodRef.current = currentMood
      setCurrentMood(mood)
      setIsTransitioning(true)

      // Reproduzir som se estiver habilitado e o som estiver carregado
      if (playSounds && isEnabled && mood !== "idle" && loadedSounds.includes(mood)) {
        playSound(mood)
      }
    } else if (mood !== currentMood) {
      // Se já estiver em transição, adicione à fila
      moodQueueRef.current.push(mood)
    }
  }, [mood, currentMood, isTransitioning, playSound, isEnabled, playSounds, loadedSounds])

  // Processar a fila de humores após a conclusão da transição
  const handleTransitionComplete = () => {
    setIsTransitioning(false)

    // Verificar se há mais humores na fila
    if (moodQueueRef.current.length > 0) {
      const nextMood = moodQueueRef.current.shift()
      if (nextMood) {
        setPreviousMood(currentMood)
        previousMoodRef.current = currentMood
        setCurrentMood(nextMood)
        setIsTransitioning(true)

        // Reproduzir som se estiver habilitado e o som estiver carregado
        if (playSounds && isEnabled && nextMood !== "idle" && loadedSounds.includes(nextMood)) {
          playSound(nextMood)
        }
      }
    }
  }

  // Atualizar a mensagem quando a prop mudar
  useEffect(() => {
    if (message !== currentMessage) {
      setCurrentMessage(message)

      // Reproduzir som de notificação quando a mensagem mudar
      if (playSounds && isEnabled && message && message !== currentMessage && loadedSounds.includes("notification")) {
        playSound("notification")
      }
    }
  }, [message, currentMessage, playSound, isEnabled, playSounds, loadedSounds])

  // Auto-esconder após o tempo especificado
  useEffect(() => {
    if (autoHide && isVisible) {
      const timer = setTimeout(() => {
        setIsVisible(false)
      }, hideAfter)
      return () => clearTimeout(timer)
    }
  }, [autoHide, hideAfter, isVisible])

  const handleClick = () => {
    // Reproduzir som de clique se estiver carregado
    if (playSounds && isEnabled && loadedSounds.includes("click")) {
      playSound("click")
    }

    if (onMascotClick) {
      onMascotClick()
    } else {
      // Comportamento padrão: alternar entre visível/invisível
      setIsVisible(!isVisible)
    }
  }

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.8, y: 20 }}
          transition={{ type: "spring", damping: 15 }}
          className={cn("relative cursor-pointer select-none", className)}
          onClick={handleClick}
        >
          {currentMessage && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 10 }}
              transition={{ delay: 0.2 }}
              className="absolute -top-16 left-1/2 transform -translate-x-1/2 bg-white dark:bg-gray-800 p-3 rounded-lg shadow-md text-sm max-w-[200px] z-10"
            >
              <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-white dark:bg-gray-800 rotate-45" />
              <p className="relative z-10 text-center">{currentMessage}</p>
            </motion.div>
          )}
          <div className="relative z-0">
            <MascotTransition
              currentMood={currentMood}
              previousMood={previousMood}
              size={size}
              onTransitionComplete={handleTransitionComplete}
            />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
