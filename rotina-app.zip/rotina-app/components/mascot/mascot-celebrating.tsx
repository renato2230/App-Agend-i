"use client"

import { motion } from "framer-motion"

interface MascotCelebratingProps {
  width?: number
  height?: number
}

export function MascotCelebrating({ width = 120, height = 120 }: MascotCelebratingProps) {
  return (
    <svg width={width} height={height} viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Corpo pulando */}
      <motion.circle
        cx="100"
        cy="100"
        r="70"
        fill="#4CAF50"
        initial={{ y: 0 }}
        animate={{ y: [0, -10, 0] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 0.8, ease: "easeInOut" }}
      />

      {/* Olhos animados */}
      <motion.g
        initial={{ y: 0 }}
        animate={{ y: [0, -10, 0] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 0.8, ease: "easeInOut" }}
      >
        {/* Olhos com estrelas */}
        <circle cx="75" cy="85" r="12" fill="white" />
        <circle cx="125" cy="85" r="12" fill="white" />

        <motion.path
          d="M75 85 L75 79 M75 85 L75 91 M75 85 L69 85 M75 85 L81 85"
          stroke="#FFD700"
          strokeWidth="2"
          initial={{ scale: 0.8, opacity: 0.5 }}
          animate={{ scale: [0.8, 1.2, 0.8], opacity: [0.5, 1, 0.5], rotate: [0, 45, 0] }}
          transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1.5, ease: "easeInOut" }}
        />

        <motion.path
          d="M125 85 L125 79 M125 85 L125 91 M125 85 L119 85 M125 85 L131 85"
          stroke="#FFD700"
          strokeWidth="2"
          initial={{ scale: 0.8, opacity: 0.5 }}
          animate={{ scale: [0.8, 1.2, 0.8], opacity: [0.5, 1, 0.5], rotate: [0, -45, 0] }}
          transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1.5, ease: "easeInOut" }}
        />
      </motion.g>

      {/* Boca grande e feliz */}
      <motion.path
        d="M70 115 Q100 145 130 115"
        stroke="white"
        strokeWidth="4"
        fill="#388E3C"
        initial={{ d: "M70 115 Q100 145 130 115" }}
        animate={{
          d: ["M70 115 Q100 145 130 115", "M70 120 Q100 155 130 120", "M70 115 Q100 145 130 115"],
          y: [0, -10, 0],
        }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 0.8, ease: "easeInOut" }}
      />

      {/* Braços celebrando */}
      <motion.g
        initial={{ rotate: -45 }}
        animate={{ rotate: [-45, -30, -45], y: [0, -10, 0] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 0.8, ease: "easeInOut" }}
        style={{ originX: "60px", originY: "100px" }}
      >
        <path d="M60 100 Q50 70 40 50" stroke="#388E3C" strokeWidth="8" strokeLinecap="round" fill="none" />
      </motion.g>

      <motion.g
        initial={{ rotate: 45 }}
        animate={{ rotate: [45, 30, 45], y: [0, -10, 0] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 0.8, ease: "easeInOut" }}
        style={{ originX: "140px", originY: "100px" }}
      >
        <path d="M140 100 Q150 70 160 50" stroke="#388E3C" strokeWidth="8" strokeLinecap="round" fill="none" />
      </motion.g>

      {/* Confetes */}
      <motion.g>
        {[...Array(10)].map((_, i) => (
          <motion.circle
            key={i}
            cx={40 + i * 15}
            cy={30 + (i % 3) * 20}
            r={2 + (i % 3)}
            fill={["#FF5252", "#FFD740", "#448AFF", "#FF4081"][i % 4]}
            initial={{ y: -20, opacity: 0 }}
            animate={{
              y: [20, 160],
              opacity: [0, 1, 0],
              x: [0, i % 2 === 0 ? 10 : -10, 0],
            }}
            transition={{
              repeat: Number.POSITIVE_INFINITY,
              duration: 2,
              ease: "easeInOut",
              delay: i * 0.2,
              repeatDelay: 0.5,
            }}
          />
        ))}
      </motion.g>

      {/* Relógio na barriga */}
      <motion.g
        animate={{ y: [0, -10, 0] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 0.8, ease: "easeInOut" }}
      >
        <circle cx="100" cy="110" r="15" fill="white" stroke="#388E3C" strokeWidth="2" />
        <line x1="100" y1="110" x2="100" y2="100" stroke="#388E3C" strokeWidth="2" />
        <line x1="100" y1="110" x2="108" y2="110" stroke="#388E3C" strokeWidth="2" />
      </motion.g>
    </svg>
  )
}
