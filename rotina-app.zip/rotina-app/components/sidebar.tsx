"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  Calendar,
  Home,
  LogOut,
  Settings,
  List,
  Award,
  BarChart,
  Timer,
  CalendarCheck2,
  User,
  History,
  Share2,
} from "lucide-react"
import { useAuth } from "@/context/auth-context"

export default function Sidebar() {
  const pathname = usePathname()
  const [collapsed, setCollapsed] = useState(false)
  const { signOut } = useAuth()

  const menuItems = [
    { icon: Home, label: "Dashboard", href: "/dashboard" },
    { icon: List, label: "Rotinas", href: "/dashboard/rotinas" },
    { icon: Calendar, label: "Calendário", href: "/dashboard/calendario" },
    { icon: Timer, label: "Pomodoro", href: "/dashboard/pomodoro" },
    { icon: Award, label: "Conquistas", href: "/dashboard/conquistas" },
    { icon: BarChart, label: "Estatísticas", href: "/dashboard/estatisticas" },
    { icon: History, label: "Histórico", href: "/dashboard/historico" },
    { icon: Share2, label: "Redes Sociais", href: "/dashboard/social-media" },
    { icon: User, label: "Perfil", href: "/dashboard/perfil" },
    { icon: Settings, label: "Configurações", href: "/dashboard/configuracoes" },
  ]

  return (
    <aside
      className={`bg-card text-card-foreground border-r border-border transition-all duration-300 ${collapsed ? "w-16" : "w-64"}`}
    >
      <div className="p-4 flex items-center justify-between border-b border-border">
        {!collapsed ? (
          <div className="flex items-center gap-2">
            <CalendarCheck2 className="h-6 w-6 text-primary" />
            <h2 className="text-xl font-bold logo-text">Agendêi</h2>
          </div>
        ) : (
          <CalendarCheck2 className="h-6 w-6 text-primary mx-auto" />
        )}
        <button onClick={() => setCollapsed(!collapsed)} className="p-1 rounded-md hover:bg-accent">
          {collapsed ? "→" : "←"}
        </button>
      </div>

      <nav className="mt-6">
        <ul className="space-y-2 px-2">
          {menuItems.map((item) => {
            const isActive = pathname === item.href || pathname.startsWith(`${item.href}/`)

            return (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className={`flex items-center p-3 rounded-md transition-colors ${
                    isActive ? "bg-primary text-primary-foreground" : "text-foreground hover:bg-accent"
                  }`}
                >
                  <item.icon className="h-5 w-5" />
                  {!collapsed && <span className="ml-3">{item.label}</span>}
                </Link>
              </li>
            )
          })}
        </ul>
      </nav>

      <div className="absolute bottom-0 w-full p-4 border-t border-border">
        <button
          onClick={signOut}
          className="flex items-center p-3 w-full text-left text-foreground hover:bg-accent rounded-md transition-colors"
        >
          <LogOut className="h-5 w-5" />
          {!collapsed && <span className="ml-3">Sair</span>}
        </button>
      </div>
    </aside>
  )
}
