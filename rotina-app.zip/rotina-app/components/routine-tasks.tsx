"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { useSupabaseData } from "@/hooks/use-supabase-data"
import { Plus, Edit, Trash2, Clock } from "lucide-react"
import TaskForm from "@/components/task-form"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/components/ui/use-toast"

interface RoutineTasksProps {
  routineId: string
  showHeader?: boolean
}

export default function RoutineTasks({ routineId, showHeader = true }: RoutineTasksProps) {
  const {
    data: tasks,
    addItem,
    updateItem,
    removeItem,
    fetchData,
  } = useSupabaseData("tasks", [], {
    filter: { routine_id: routineId },
  })
  const [editingTask, setEditingTask] = useState<any>(null)
  const { toast } = useToast()

  const handleTaskStatusChange = async (task: any, completed: boolean) => {
    await updateItem(task.id, { completed })
  }

  const handleDeleteTask = async (taskId: string) => {
    if (confirm("Tem certeza que deseja excluir esta tarefa?")) {
      const success = await removeItem(taskId)
      if (success) {
        toast({
          title: "Tarefa excluída",
          description: "A tarefa foi excluída com sucesso.",
        })
      }
    }
  }

  return (
    <Card>
      {showHeader && (
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-md font-medium">Tarefas</CardTitle>
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <Plus className="mr-2 h-4 w-4" />
                Adicionar
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Adicionar Tarefa</DialogTitle>
              </DialogHeader>
              <TaskForm
                routineId={routineId}
                onSuccess={() => {
                  fetchData()
                }}
              />
            </DialogContent>
          </Dialog>
        </CardHeader>
      )}
      <CardContent>
        {tasks.length === 0 ? (
          <div className="text-center py-4">
            <p className="text-muted-foreground">Nenhuma tarefa cadastrada.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {tasks.map((task) => (
              <div key={task.id} className="flex items-center justify-between p-2 bg-muted/50 rounded-md">
                <div className="flex items-center gap-2">
                  <Checkbox
                    checked={task.completed}
                    onCheckedChange={(checked) => handleTaskStatusChange(task, !!checked)}
                  />
                  <span className={task.completed ? "line-through text-muted-foreground" : ""}>{task.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-xs">
                    <Clock className="mr-1 h-3 w-3" />
                    {task.duration} min
                  </Badge>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-7 w-7">
                        <Edit className="h-3 w-3" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Editar Tarefa</DialogTitle>
                      </DialogHeader>
                      <TaskForm
                        task={task}
                        routineId={routineId}
                        onSuccess={() => {
                          fetchData()
                        }}
                      />
                    </DialogContent>
                  </Dialog>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-destructive"
                    onClick={() => handleDeleteTask(task.id)}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Modal de edição de tarefa */}
        <Dialog open={!!editingTask} onOpenChange={(open) => !open && setEditingTask(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Editar Tarefa</DialogTitle>
            </DialogHeader>
            {editingTask && (
              <TaskForm
                task={editingTask}
                routineId={routineId}
                onSuccess={() => {
                  fetchData()
                  setEditingTask(null)
                }}
              />
            )}
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  )
}
