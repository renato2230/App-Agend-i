"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { CalendarCheck2, Clock, Award, BarChart, ArrowRight, Check } from "lucide-react"
import { useSupabaseData } from "@/hooks/use-supabase-data"
import { useAuth } from "@/context/auth-context"

interface OnboardingProps {
  onComplete: () => void
}

const steps = [
  {
    title: "Bem-vindo ao Agendêi!",
    description: "Organize sua vida com facilidade usando nosso aplicativo de gerenciamento de rotinas e tarefas.",
    icon: CalendarCheck2,
    color: "bg-primary/20",
    iconColor: "text-primary",
  },
  {
    title: "Crie suas rotinas",
    description: "Organize suas atividades em rotinas personalizadas para diferentes áreas da sua vida.",
    icon: Clock,
    color: "bg-blue-100 dark:bg-blue-900/20",
    iconColor: "text-blue-500",
  },
  {
    title: "Acompanhe seu progresso",
    description: "Visualize estatísticas e conquistas para manter-se motivado e produtivo.",
    icon: BarChart,
    color: "bg-amber-100 dark:bg-amber-900/20",
    iconColor: "text-amber-500",
  },
  {
    title: "Ganhe conquistas",
    description: "Complete tarefas e mantenha sequências para desbloquear conquistas especiais.",
    icon: Award,
    color: "bg-purple-100 dark:bg-purple-900/20",
    iconColor: "text-purple-500",
  },
]

export default function Onboarding({ onComplete }: OnboardingProps) {
  const [currentStep, setCurrentStep] = useState(0)
  const [completed, setCompleted] = useState(false)
  const router = useRouter()
  const { user } = useAuth()
  const { updateItem } = useSupabaseData("profiles", [])

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      setCompleted(true)
      // Marcar o onboarding como concluído
      if (user) {
        updateItem(user.id, { onboarding_completed: true })
      }
    }
  }

  const handleSkip = () => {
    setCompleted(true)
    // Marcar o onboarding como concluído mesmo se pulado
    if (user) {
      updateItem(user.id, { onboarding_completed: true })
    }
  }

  const handleFinish = () => {
    onComplete()
  }

  if (completed) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background/80 backdrop-blur-sm z-50">
        <Card className="w-full max-w-md mx-auto">
          <CardContent className="pt-6 pb-8 px-6 text-center space-y-6">
            <div className="mx-auto w-16 h-16 rounded-full bg-green-100 dark:bg-green-900/20 flex items-center justify-center">
              <Check className="h-8 w-8 text-green-500" />
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl font-bold">Tudo pronto!</h2>
              <p className="text-muted-foreground">
                Você está pronto para começar a usar o Agendêi e organizar sua vida com facilidade.
              </p>
            </div>
            <Button onClick={handleFinish} className="w-full">
              Começar a usar
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Obter o componente de ícone atual
  const IconComponent = steps[currentStep].icon

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-background/80 backdrop-blur-sm z-50">
      <Card className="w-full max-w-md mx-auto">
        <CardContent className="pt-6 pb-8 px-6">
          <div className="space-y-6">
            {/* Indicador de progresso */}
            <div className="flex justify-center space-x-2">
              {steps.map((_, index) => (
                <div
                  key={index}
                  className={`h-2 w-2 rounded-full transition-colors ${
                    index === currentStep ? "bg-primary" : "bg-muted"
                  }`}
                />
              ))}
            </div>

            {/* Conteúdo do passo atual */}
            <div className="text-center space-y-4">
              <div
                className={`mx-auto w-16 h-16 rounded-full ${steps[currentStep].color} flex items-center justify-center`}
              >
                {IconComponent && <IconComponent className={`h-8 w-8 ${steps[currentStep].iconColor}`} />}
              </div>
              <h2 className="text-2xl font-bold">{steps[currentStep].title}</h2>
              <p className="text-muted-foreground">{steps[currentStep].description}</p>
            </div>

            {/* Botões de navegação */}
            <div className="flex justify-between pt-4">
              <Button variant="ghost" onClick={handleSkip}>
                Pular
              </Button>
              <Button onClick={handleNext}>
                {currentStep < steps.length - 1 ? (
                  <>
                    Próximo <ArrowRight className="ml-2 h-4 w-4" />
                  </>
                ) : (
                  "Concluir"
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
