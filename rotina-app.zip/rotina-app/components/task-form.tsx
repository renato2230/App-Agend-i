"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { useSupabaseData } from "@/hooks/use-supabase-data"
import { useAuth } from "@/context/auth-context"
import { Loader2 } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

interface TaskFormProps {
  task?: any
  routineId: string
  onSuccess?: () => void
}

export default function TaskForm({ task, routineId, onSuccess }: TaskFormProps) {
  const [isLoading, setIsLoading] = useState(false)
  const { user } = useAuth()
  const { addItem, updateItem } = useSupabaseData("tasks", [])
  const { toast } = useToast()

  const [formData, setFormData] = useState({
    name: task?.name || "",
    description: task?.description || "",
    duration: task?.duration || 15,
    priority: task?.priority || "Média",
    completed: task?.completed || false,
    routine_id: routineId,
    order: task?.order || 0,
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData({ ...formData, [name]: value })
  }

  const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData({ ...formData, [name]: Number.parseInt(value) || 0 })
  }

  const handleSelectChange = (field: string, value: string) => {
    setFormData({ ...formData, [field]: value })
  }

  const handleSwitchChange = (field: string, checked: boolean) => {
    setFormData({ ...formData, [field]: checked })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      if (!user) {
        throw new Error("Usuário não autenticado")
      }

      if (task) {
        // Atualizar tarefa existente
        await updateItem(task.id, formData)
        toast({
          title: "Tarefa atualizada",
          description: "A tarefa foi atualizada com sucesso.",
        })
      } else {
        // Criar nova tarefa
        await addItem({
          ...formData,
          user_id: user.id,
        })
        toast({
          title: "Tarefa criada",
          description: "A tarefa foi criada com sucesso.",
        })
      }

      if (onSuccess) {
        onSuccess()
      }
    } catch (error: any) {
      console.error("Erro ao salvar tarefa:", error)
      toast({
        title: "Erro",
        description: error.message || "Não foi possível salvar a tarefa.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Nome da Tarefa</Label>
        <Input
          id="name"
          name="name"
          value={formData.name}
          onChange={handleChange}
          placeholder="Ex: Ler 20 páginas"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Descrição (opcional)</Label>
        <Textarea
          id="description"
          name="description"
          value={formData.description}
          onChange={handleChange}
          placeholder="Detalhes adicionais sobre a tarefa"
          rows={2}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="duration">Duração (minutos)</Label>
          <Input
            id="duration"
            name="duration"
            type="number"
            min={1}
            value={formData.duration}
            onChange={handleNumberChange}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="priority">Prioridade</Label>
          <Select value={formData.priority} onValueChange={(value) => handleSelectChange("priority", value)}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione a prioridade" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Baixa">Baixa</SelectItem>
              <SelectItem value="Média">Média</SelectItem>
              <SelectItem value="Alta">Alta</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex items-center space-x-2">
        <Switch
          id="completed"
          checked={formData.completed}
          onCheckedChange={(checked) => handleSwitchChange("completed", checked)}
        />
        <Label htmlFor="completed">Tarefa concluída</Label>
      </div>

      <div className="flex justify-end pt-4">
        <Button type="submit" disabled={isLoading}>
          {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {task ? "Atualizar Tarefa" : "Adicionar Tarefa"}
        </Button>
      </div>
    </form>
  )
}
