"use client"

import { CheckCircle } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { useSupabaseData } from "@/hooks/use-supabase-data"
import { useAuth } from "@/context/auth-context"

interface Task {
  id: string
  name: string
  routine_id: string
  duration: number
  priority: string
  completed: boolean
}

interface Routine {
  id: string
  name: string
}

// Dados de exemplo para o usuário de teste
const TEST_TASKS = [
  {
    id: "test-task-1",
    name: "Revisar documentos",
    routine_id: "test-routine-1",
    duration: 30,
    priority: "Alta",
    completed: false,
  },
  {
    id: "test-task-2",
    name: "Preparar apresentação",
    routine_id: "test-routine-2",
    duration: 45,
    priority: "Média",
    completed: false,
  },
  {
    id: "test-task-3",
    name: "Responder emails",
    routine_id: "test-routine-1",
    duration: 20,
    priority: "Baixa",
    completed: true,
  },
]

const TEST_ROUTINES = [
  {
    id: "test-routine-1",
    name: "Trabalho",
  },
  {
    id: "test-routine-2",
    name: "Estudos",
  },
]

export default function UpcomingTasks() {
  const { isTestUser } = useAuth()
  const { data: tasks, updateItem } = useSupabaseData<Task>("tasks", [], {
    orderBy: "created_at",
    orderDirection: "desc",
  })

  const { data: routines } = useSupabaseData<Routine>("routines", [])
  const { data: statsData, updateItem: updateStats } = useSupabaseData("stats", [])

  const handleComplete = async (id: string, completed: boolean) => {
    try {
      await updateItem(id, { completed: !completed })

      // Se a tarefa foi marcada como concluída, atualizar estatísticas
      if (!completed && statsData && statsData.length > 0) {
        const stats = statsData[0]
        await updateStats(stats.id, {
          tarefas_completas_hoje: (stats.tarefas_completas_hoje || 0) + 1,
          tarefas_completas_total: (stats.tarefas_completas_total || 0) + 1,
        })
      }
    } catch (error) {
      console.error("Erro ao atualizar tarefa:", error)
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "Alta":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
      case "Média":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      case "Baixa":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
    }
  }

  // Usar dados de teste ou dados reais
  const displayTasks = isTestUser ? TEST_TASKS : tasks
  const displayRoutines = isTestUser ? TEST_ROUTINES : routines

  // Encontrar o nome da rotina para cada tarefa
  const tasksWithRoutines = displayTasks.map((task) => {
    const routine = displayRoutines.find((r) => r.id === task.routine_id)
    return {
      ...task,
      routineName: routine?.name || "Rotina",
    }
  })

  return (
    <div className="space-y-4">
      {tasksWithRoutines.length === 0 ? (
        <p className="text-muted-foreground text-center py-4">Nenhuma tarefa próxima.</p>
      ) : (
        <div className="divide-y divide-border">
          {tasksWithRoutines.map((task) => (
            <div key={task.id} className="py-3 flex items-center">
              <button
                onClick={() => handleComplete(task.id, task.completed)}
                className={`flex-shrink-0 h-5 w-5 rounded-full border ${
                  task.completed ? "bg-primary border-primary text-primary-foreground" : "border-muted-foreground"
                } flex items-center justify-center`}
              >
                {task.completed && <CheckCircle className="h-4 w-4" />}
              </button>

              <div className="ml-3 flex-1">
                <p className={`text-sm font-medium ${task.completed ? "text-muted-foreground line-through" : ""}`}>
                  {task.name}
                </p>
                <p className="text-xs text-muted-foreground">
                  {task.routineName} • {task.duration || 0} min
                </p>
              </div>

              <Badge className={`ml-2 ${getPriorityColor(task.priority || "Média")}`}>{task.priority || "Média"}</Badge>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
