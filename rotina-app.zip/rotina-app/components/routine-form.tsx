"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useSupabaseData } from "@/hooks/use-supabase-data"
import { useAuth } from "@/context/auth-context"
import { Loader2 } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

interface RoutineFormProps {
  routine?: any
  onSuccess?: () => void
}

export default function RoutineForm({ routine, onSuccess }: RoutineFormProps) {
  const { user } = useAuth()
  const { addItem, updateItem } = useSupabaseData("routines", [])
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const [formData, setFormData] = useState({
    name: routine?.name || "",
    description: routine?.description || "",
    frequency: routine?.frequency || "Diária",
    category: routine?.category || "Trabalho",
    user_id: user?.id || "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData({ ...formData, [name]: value })
  }

  const handleSelectChange = (field: string, value: string) => {
    setFormData({ ...formData, [field]: value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!user) {
      toast({
        title: "Erro",
        description: "Você precisa estar logado para criar uma rotina.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      if (routine) {
        // Atualizar rotina existente
        await updateItem(routine.id, formData)
        toast({
          title: "Rotina atualizada",
          description: "A rotina foi atualizada com sucesso.",
        })
      } else {
        // Criar nova rotina
        await addItem({
          ...formData,
          user_id: user.id,
        })
        toast({
          title: "Rotina criada",
          description: "A rotina foi criada com sucesso.",
        })
      }

      if (onSuccess) {
        onSuccess()
      }
    } catch (error) {
      console.error("Erro ao salvar rotina:", error)
      toast({
        title: "Erro",
        description: "Não foi possível salvar a rotina.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Nome da Rotina</Label>
        <Input
          id="name"
          name="name"
          value={formData.name}
          onChange={handleChange}
          placeholder="Ex: Rotina de Trabalho"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Descrição (opcional)</Label>
        <Textarea
          id="description"
          name="description"
          value={formData.description}
          onChange={handleChange}
          placeholder="Descreva o objetivo desta rotina"
          rows={3}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="frequency">Frequência</Label>
          <Select value={formData.frequency} onValueChange={(value) => handleSelectChange("frequency", value)}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione a frequência" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Diária">Diária</SelectItem>
              <SelectItem value="Semanal">Semanal</SelectItem>
              <SelectItem value="Mensal">Mensal</SelectItem>
              <SelectItem value="Personalizada">Personalizada</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="category">Categoria</Label>
          <Select value={formData.category} onValueChange={(value) => handleSelectChange("category", value)}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione a categoria" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Trabalho">Trabalho</SelectItem>
              <SelectItem value="Estudo">Estudo</SelectItem>
              <SelectItem value="Saúde">Saúde</SelectItem>
              <SelectItem value="Lazer">Lazer</SelectItem>
              <SelectItem value="Família">Família</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex justify-end pt-4">
        <Button type="submit" disabled={isLoading}>
          {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {routine ? "Atualizar Rotina" : "Criar Rotina"}
        </Button>
      </div>
    </form>
  )
}
