"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { useLocalStorage } from "@/hooks/use-local-storage"
import { Plus, Trash2, Share2, Copy, Check, Download } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

interface BudgetItem {
  id: string
  descricao: string
  quantidade: number
  valorUnitario: number
}

interface Budget {
  id: string
  cliente: string
  data: string
  validade: string
  itens: BudgetItem[]
  observacoes: string
  incluirDesconto: boolean
  percentualDesconto: number
}

export default function BudgetCreator() {
  const [budgets, setBudgets] = useLocalStorage<Budget[]>("budgets", [
    {
      id: "1",
      cliente: "João Silva",
      data: "2023-05-15",
      validade: "2023-06-15",
      itens: [
        { id: "101", descricao: "Design de Logo", quantidade: 1, valorUnitario: 500 },
        { id: "102", descricao: "Cartão de Visita", quantidade: 1, valorUnitario: 150 },
      ],
      observacoes: "Prazo de entrega: 7 dias úteis após aprovação.",
      incluirDesconto: true,
      percentualDesconto: 10,
    },
  ])

  const [clients] = useLocalStorage<any[]>("clients", [])
  const [currentBudget, setCurrentBudget] = useState<Budget | null>(null)
  const [showPreview, setShowPreview] = useState(false)
  const [copied, setCopied] = useState(false)

  const newBudgetTemplate: Budget = {
    id: "",
    cliente: "",
    data: new Date().toISOString().split("T")[0],
    validade: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    itens: [{ id: Date.now().toString(), descricao: "", quantidade: 1, valorUnitario: 0 }],
    observacoes: "",
    incluirDesconto: false,
    percentualDesconto: 0,
  }

  const [formData, setFormData] = useState<Budget>(newBudgetTemplate)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData({ ...formData, [name]: value })
  }

  const handleItemChange = (id: string, field: keyof BudgetItem, value: string | number) => {
    setFormData({
      ...formData,
      itens: formData.itens.map((item) => (item.id === id ? { ...item, [field]: value } : item)),
    })
  }

  const addItem = () => {
    setFormData({
      ...formData,
      itens: [...formData.itens, { id: Date.now().toString(), descricao: "", quantidade: 1, valorUnitario: 0 }],
    })
  }

  const removeItem = (id: string) => {
    if (formData.itens.length > 1) {
      setFormData({
        ...formData,
        itens: formData.itens.filter((item) => item.id !== id),
      })
    }
  }

  const handleSwitchChange = (checked: boolean) => {
    setFormData({
      ...formData,
      incluirDesconto: checked,
      percentualDesconto: checked ? formData.percentualDesconto : 0,
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const newBudget = {
      ...formData,
      id: currentBudget ? currentBudget.id : Date.now().toString(),
    }

    if (currentBudget) {
      setBudgets(budgets.map((budget) => (budget.id === currentBudget.id ? newBudget : budget)))
    } else {
      setBudgets([...budgets, newBudget])
    }

    setCurrentBudget(null)
    setFormData(newBudgetTemplate)
  }

  const editBudget = (budget: Budget) => {
    setCurrentBudget(budget)
    setFormData(budget)
  }

  const deleteBudget = (id: string) => {
    if (confirm("Tem certeza que deseja excluir este orçamento?")) {
      setBudgets(budgets.filter((budget) => budget.id !== id))
    }
  }

  const calculateTotal = (budget: Budget) => {
    const subtotal = budget.itens.reduce((acc, item) => acc + item.quantidade * item.valorUnitario, 0)
    const discount = budget.incluirDesconto ? subtotal * (budget.percentualDesconto / 100) : 0
    return subtotal - discount
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(value)
  }

  const generateWhatsAppMessage = (budget: Budget) => {
    const subtotal = budget.itens.reduce((acc, item) => acc + item.quantidade * item.valorUnitario, 0)
    const discount = budget.incluirDesconto ? subtotal * (budget.percentualDesconto / 100) : 0
    const total = subtotal - discount

    let message = `*ORÇAMENTO*\n\n`
    message += `*Cliente:* ${budget.cliente}\n`
    message += `*Data:* ${new Date(budget.data).toLocaleDateString("pt-BR")}\n`
    message += `*Validade:* ${new Date(budget.validade).toLocaleDateString("pt-BR")}\n\n`
    message += `*ITENS*\n`

    budget.itens.forEach((item, index) => {
      message += `${index + 1}. ${item.descricao}\n`
      message += `   ${item.quantidade} x ${formatCurrency(item.valorUnitario)} = ${formatCurrency(item.quantidade * item.valorUnitario)}\n`
    })

    message += `\n*Subtotal:* ${formatCurrency(subtotal)}\n`

    if (budget.incluirDesconto) {
      message += `*Desconto (${budget.percentualDesconto}%):* ${formatCurrency(discount)}\n`
    }

    message += `*TOTAL:* ${formatCurrency(total)}\n\n`

    if (budget.observacoes) {
      message += `*Observações:*\n${budget.observacoes}\n\n`
    }

    message += `Agradeço a oportunidade e estou à disposição para qualquer esclarecimento.`

    return encodeURIComponent(message)
  }

  const shareViaWhatsApp = (budget: Budget) => {
    const message = generateWhatsAppMessage(budget)
    window.open(`https://wa.me/?text=${message}`, "_blank")
  }

  const copyToClipboard = (budget: Budget) => {
    const message = decodeURIComponent(generateWhatsAppMessage(budget))
    navigator.clipboard.writeText(message)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const previewBudget = (budget: Budget) => {
    setCurrentBudget(budget)
    setShowPreview(true)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <h2 className="text-lg font-semibold">Meus Orçamentos</h2>
        <Dialog>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Novo Orçamento
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Criar Novo Orçamento</DialogTitle>
              <DialogDescription>Preencha os detalhes do orçamento para enviar ao cliente.</DialogDescription>
            </DialogHeader>

            <form onSubmit={handleSubmit} className="space-y-6 py-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="cliente">Cliente</Label>
                  <Select
                    value={formData.cliente}
                    onValueChange={(value) => setFormData({ ...formData, cliente: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione um cliente" />
                    </SelectTrigger>
                    <SelectContent>
                      {clients.map((client) => (
                        <SelectItem key={client.id} value={client.nome}>
                          {client.nome}
                        </SelectItem>
                      ))}
                      <SelectItem value="Outro">Outro</SelectItem>
                    </SelectContent>
                  </Select>

                  {formData.cliente === "Outro" && (
                    <Input
                      className="mt-2"
                      placeholder="Nome do cliente"
                      value={formData.cliente === "Outro" ? "" : formData.cliente}
                      onChange={(e) => setFormData({ ...formData, cliente: e.target.value })}
                    />
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="data">Data</Label>
                    <Input id="data" name="data" type="date" value={formData.data} onChange={handleChange} />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="validade">Validade</Label>
                    <Input
                      id="validade"
                      name="validade"
                      type="date"
                      value={formData.validade}
                      onChange={handleChange}
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>Itens do Orçamento</Label>
                  <Button type="button" variant="outline" size="sm" onClick={addItem}>
                    <Plus className="mr-1 h-4 w-4" />
                    Adicionar Item
                  </Button>
                </div>

                {formData.itens.map((item, index) => (
                  <div key={item.id} className="grid grid-cols-12 gap-4 items-center">
                    <div className="col-span-6">
                      <Input
                        placeholder="Descrição do item"
                        value={item.descricao}
                        onChange={(e) => handleItemChange(item.id, "descricao", e.target.value)}
                      />
                    </div>
                    <div className="col-span-2">
                      <Input
                        type="number"
                        min="1"
                        placeholder="Qtd"
                        value={item.quantidade}
                        onChange={(e) => handleItemChange(item.id, "quantidade", Number.parseInt(e.target.value) || 0)}
                      />
                    </div>
                    <div className="col-span-3">
                      <Input
                        type="number"
                        min="0"
                        step="0.01"
                        placeholder="Valor"
                        value={item.valorUnitario}
                        onChange={(e) =>
                          handleItemChange(item.id, "valorUnitario", Number.parseFloat(e.target.value) || 0)
                        }
                      />
                    </div>
                    <div className="col-span-1 flex justify-end">
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => removeItem(item.id)}
                        disabled={formData.itens.length <= 1}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="incluirDesconto"
                    checked={formData.incluirDesconto}
                    onCheckedChange={handleSwitchChange}
                  />
                  <Label htmlFor="incluirDesconto">Incluir Desconto</Label>
                </div>

                {formData.incluirDesconto && (
                  <div className="flex items-center space-x-2">
                    <Input
                      type="number"
                      min="0"
                      max="100"
                      className="w-24"
                      value={formData.percentualDesconto}
                      onChange={(e) =>
                        setFormData({ ...formData, percentualDesconto: Number.parseFloat(e.target.value) || 0 })
                      }
                    />
                    <span>%</span>
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="observacoes">Observações</Label>
                <Textarea
                  id="observacoes"
                  name="observacoes"
                  placeholder="Condições de pagamento, prazo de entrega, etc."
                  rows={3}
                  value={formData.observacoes}
                  onChange={handleChange}
                />
              </div>

              <DialogFooter>
                <Button type="submit">{currentBudget ? "Atualizar Orçamento" : "Criar Orçamento"}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {budgets.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">
          <p>Nenhum orçamento criado ainda.</p>
          <p className="text-sm">Clique em "Novo Orçamento" para começar.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {budgets.map((budget) => (
            <Card key={budget.id} className="overflow-hidden">
              <CardContent className="p-0">
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-medium">{budget.cliente}</h3>
                      <p className="text-sm text-muted-foreground">
                        Criado em {new Date(budget.data).toLocaleDateString("pt-BR")}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-lg">{formatCurrency(calculateTotal(budget))}</p>
                      <p className="text-xs text-muted-foreground">
                        Válido até {new Date(budget.validade).toLocaleDateString("pt-BR")}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-1">
                    {budget.itens.slice(0, 2).map((item) => (
                      <div key={item.id} className="text-sm flex justify-between">
                        <span className="truncate max-w-[70%]">{item.descricao}</span>
                        <span>{formatCurrency(item.quantidade * item.valorUnitario)}</span>
                      </div>
                    ))}

                    {budget.itens.length > 2 && (
                      <p className="text-xs text-muted-foreground">+ {budget.itens.length - 2} outros itens</p>
                    )}
                  </div>
                </div>

                <Separator />

                <div className="p-4 bg-muted/50 flex justify-between">
                  <div className="flex space-x-2">
                    <Button variant="ghost" size="sm" onClick={() => editBudget(budget)}>
                      Editar
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => deleteBudget(budget.id)}>
                      Excluir
                    </Button>
                  </div>

                  <div className="flex space-x-2">
                    <Button variant="ghost" size="icon" onClick={() => copyToClipboard(budget)}>
                      {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => previewBudget(budget)}>
                      <Download className="h-4 w-4" />
                    </Button>
                    <Button variant="default" size="sm" onClick={() => shareViaWhatsApp(budget)}>
                      <Share2 className="mr-2 h-4 w-4" />
                      WhatsApp
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Visualizar Orçamento</DialogTitle>
          </DialogHeader>

          {currentBudget && (
            <div className="space-y-6 py-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-xl font-bold">Orçamento</h3>
                  <p className="text-muted-foreground">{new Date(currentBudget.data).toLocaleDateString("pt-BR")}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm">Válido até:</p>
                  <p className="font-medium">{new Date(currentBudget.validade).toLocaleDateString("pt-BR")}</p>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="font-medium">Cliente</h4>
                <p>{currentBudget.cliente}</p>
              </div>

              <div className="space-y-4">
                <h4 className="font-medium">Itens</h4>
                <div className="border rounded-md overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-muted">
                      <tr>
                        <th className="text-left p-3">Descrição</th>
                        <th className="text-center p-3">Qtd</th>
                        <th className="text-right p-3">Valor Unit.</th>
                        <th className="text-right p-3">Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {currentBudget.itens.map((item) => (
                        <tr key={item.id}>
                          <td className="p-3">{item.descricao}</td>
                          <td className="p-3 text-center">{item.quantidade}</td>
                          <td className="p-3 text-right">{formatCurrency(item.valorUnitario)}</td>
                          <td className="p-3 text-right">{formatCurrency(item.quantidade * item.valorUnitario)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="flex flex-col items-end space-y-1">
                  <div className="flex justify-between w-48">
                    <span>Subtotal:</span>
                    <span>
                      {formatCurrency(
                        currentBudget.itens.reduce((acc, item) => acc + item.quantidade * item.valorUnitario, 0),
                      )}
                    </span>
                  </div>

                  {currentBudget.incluirDesconto && (
                    <div className="flex justify-between w-48">
                      <span>Desconto ({currentBudget.percentualDesconto}%):</span>
                      <span>
                        {formatCurrency(
                          currentBudget.itens.reduce((acc, item) => acc + item.quantidade * item.valorUnitario, 0) *
                            (currentBudget.percentualDesconto / 100),
                        )}
                      </span>
                    </div>
                  )}

                  <div className="flex justify-between w-48 font-bold text-lg">
                    <span>Total:</span>
                    <span>{formatCurrency(calculateTotal(currentBudget))}</span>
                  </div>
                </div>
              </div>

              {currentBudget.observacoes && (
                <div className="space-y-2">
                  <h4 className="font-medium">Observações</h4>
                  <p className="text-sm whitespace-pre-line">{currentBudget.observacoes}</p>
                </div>
              )}

              <DialogFooter>
                <Button variant="outline" onClick={() => copyToClipboard(currentBudget)}>
                  {copied ? <Check className="mr-2 h-4 w-4" /> : <Copy className="mr-2 h-4 w-4" />}
                  Copiar Texto
                </Button>
                <Button onClick={() => shareViaWhatsApp(currentBudget)}>
                  <Share2 className="mr-2 h-4 w-4" />
                  Enviar via WhatsApp
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
