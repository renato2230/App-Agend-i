"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { usePWAInstall } from "@/hooks/use-pwa-install"
import { Download, X } from "lucide-react"
import { useState } from "react"

export function PWAInstallPrompt() {
  const { canInstall, installPWA } = usePWAInstall()
  const [dismissed, setDismissed] = useState(false)

  if (!canInstall || dismissed) return null

  return (
    <div className="fixed bottom-4 right-4 z-40 max-w-sm">
      <Card className="border-primary shadow-lg">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg">Instale o Agendêi</CardTitle>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setDismissed(true)}>
              <X className="h-4 w-4" />
              <span className="sr-only">Fechar</span>
            </Button>
          </div>
          <CardDescription>Instale o app para acesso rápido e uso offline</CardDescription>
        </CardHeader>
        <CardContent className="pb-2">
          <div className="flex items-center gap-4">
            <div className="rounded-lg bg-primary/10 p-2">
              <img src="/icons/icon-192x192.png" alt="Ícone do Agendêi" className="h-12 w-12" />
            </div>
            <div>
              <p className="text-sm font-medium">Agendêi</p>
              <p className="text-xs text-muted-foreground">Organize sua vida com facilidade</p>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button className="w-full" onClick={installPWA}>
            <Download className="mr-2 h-4 w-4" />
            Instalar App
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
