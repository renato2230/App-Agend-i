"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useAuth } from "@/context/auth-context"
import { useSupabaseData } from "@/hooks/use-supabase-data"
import Onboarding from "@/components/onboarding"

interface OnboardingWrapperProps {
  children: React.ReactNode
  isTestUser: boolean
  onboardingCompleted?: boolean
}

export default function OnboardingWrapper({
  children,
  isTestUser,
  onboardingCompleted: initialOnboardingCompleted,
}: OnboardingWrapperProps) {
  const [showOnboarding, setShowOnboarding] = useState(false)
  const { user } = useAuth()
  const { data: profiles } = useSupabaseData("profiles", [])

  useEffect(() => {
    // Se for usuário de teste, verificar localStorage
    if (isTestUser) {
      const testOnboardingCompleted = localStorage.getItem("testOnboardingCompleted") === "true"
      setShowOnboarding(!testOnboardingCompleted)
      return
    }

    // Para usuários normais, verificar o status do onboarding
    if (initialOnboardingCompleted === false) {
      setShowOnboarding(true)
    } else if (profiles.length > 0) {
      const profile = profiles[0]
      setShowOnboarding(profile.onboarding_completed !== true)
    }
  }, [isTestUser, initialOnboardingCompleted, profiles, user])

  // Função para marcar o onboarding como concluído
  const handleOnboardingComplete = () => {
    if (isTestUser) {
      localStorage.setItem("testOnboardingCompleted", "true")
    }
    setShowOnboarding(false)
  }

  return (
    <>
      {showOnboarding && <Onboarding onComplete={handleOnboardingComplete} />}
      {children}
    </>
  )
}
