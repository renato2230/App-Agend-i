"use client"

import { useState } from "react"
import { useSupabaseData } from "@/hooks/use-supabase-data"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Calendar, Clock, Edit, MoreVertical, Plus, Trash2, CheckCircle2 } from "lucide-react"
import RoutineForm from "@/components/routine-form"
import TaskForm from "@/components/task-form"
import { useToast } from "@/components/ui/use-toast"
import { Checkbox } from "@/components/ui/checkbox"
import { DragDropContext, Draggable, Droppable } from "@hello-pangea/dnd"

interface RoutinesListProps {
  showActions?: boolean
  filterFrequency?: string
  limit?: number
}

export default function RoutinesList({ showActions = false, filterFrequency, limit }: RoutinesListProps) {
  const { data: routines, updateItem, removeItem, fetchData } = useSupabaseData("routines", [])
  const { data: tasks, addItem: addTask, updateItem: updateTask, removeItem: removeTask } = useSupabaseData("tasks", [])
  const [editingRoutine, setEditingRoutine] = useState<any>(null)
  const [editingTask, setEditingTask] = useState<any>(null)
  const [currentRoutineId, setCurrentRoutineId] = useState<string | null>(null)
  const { toast } = useToast()

  // Filtrar rotinas com base na frequência, se fornecida
  let filteredRoutines = filterFrequency
    ? routines.filter((routine) => routine.frequency === filterFrequency)
    : routines

  // Limitar o número de rotinas, se fornecido
  if (limit && filteredRoutines.length > limit) {
    filteredRoutines = filteredRoutines.slice(0, limit)
  }

  const handleDeleteRoutine = async (id: string) => {
    const success = await removeItem(id)
    if (success) {
      toast({
        title: "Rotina excluída",
        description: "A rotina foi excluída com sucesso.",
      })
    } else {
      toast({
        title: "Erro",
        description: "Não foi possível excluir a rotina.",
        variant: "destructive",
      })
    }
  }

  const handleEditRoutine = (routine: any) => {
    setEditingRoutine(routine)
  }

  const handleEditTask = (task: any) => {
    setEditingTask(task)
  }

  const handleDeleteTask = async (id: string) => {
    const success = await removeTask(id)
    if (success) {
      toast({
        title: "Tarefa excluída",
        description: "A tarefa foi excluída com sucesso.",
      })
    } else {
      toast({
        title: "Erro",
        description: "Não foi possível excluir a tarefa.",
        variant: "destructive",
      })
    }
  }

  const handleTaskStatusChange = async (task: any, completed: boolean) => {
    await updateTask(task.id, { completed })
  }

  const getTasksForRoutine = (routineId: string) => {
    return tasks.filter((task) => task.routine_id === routineId)
  }

  const handleDragEnd = async (result: any) => {
    if (!result.destination) return

    const routineId = result.source.droppableId
    const routineTasks = getTasksForRoutine(routineId)

    // Reordenar tarefas
    const reorderedTasks = Array.from(routineTasks)
    const [removed] = reorderedTasks.splice(result.source.index, 1)
    reorderedTasks.splice(result.destination.index, 0, removed)

    // Atualizar a ordem no banco de dados
    for (let i = 0; i < reorderedTasks.length; i++) {
      await updateTask(reorderedTasks[i].id, { order: i })
    }

    // Atualizar a interface
    fetchData()
  }

  if (filteredRoutines.length === 0) {
    return (
      <div className="text-center py-10">
        <p className="text-muted-foreground mb-4">Nenhuma rotina encontrada.</p>
        {showActions && (
          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Criar Nova Rotina
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Criar Nova Rotina</DialogTitle>
              </DialogHeader>
              <RoutineForm onSuccess={() => fetchData()} />
            </DialogContent>
          </Dialog>
        )}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {filteredRoutines.map((routine) => {
        const routineTasks = getTasksForRoutine(routine.id)
        const completedTasks = routineTasks.filter((task) => task.completed).length
        const progress = routineTasks.length > 0 ? (completedTasks / routineTasks.length) * 100 : 0

        return (
          <Card key={routine.id} className="overflow-hidden">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-lg">{routine.name}</CardTitle>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline">{routine.category}</Badge>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Clock className="h-3 w-3 mr-1" />
                      {routine.frequency}
                    </div>
                  </div>
                </div>
                {showActions && (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <Dialog>
                        <DialogTrigger asChild>
                          <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                            <Edit className="h-4 w-4 mr-2" />
                            Editar Rotina
                          </DropdownMenuItem>
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-[600px]">
                          <DialogHeader>
                            <DialogTitle>Editar Rotina</DialogTitle>
                          </DialogHeader>
                          <RoutineForm routine={routine} onSuccess={() => fetchData()} />
                        </DialogContent>
                      </Dialog>
                      <DropdownMenuItem
                        className="text-destructive focus:text-destructive"
                        onClick={() => handleDeleteRoutine(routine.id)}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Excluir Rotina
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}
              </div>
            </CardHeader>
            <CardContent className="pb-2">
              {routine.description && <p className="text-sm text-muted-foreground mb-4">{routine.description}</p>}

              <div className="mb-4">
                <div className="flex justify-between items-center mb-1 text-sm">
                  <span>
                    Progresso: {completedTasks}/{routineTasks.length} tarefas
                  </span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary"
                    style={{ width: `${progress}%`, transition: "width 0.3s ease" }}
                  ></div>
                </div>
              </div>

              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="tasks">
                  <AccordionTrigger className="text-sm font-medium">Tarefas ({routineTasks.length})</AccordionTrigger>
                  <AccordionContent>
                    <DragDropContext onDragEnd={handleDragEnd}>
                      <Droppable droppableId={routine.id}>
                        {(provided) => (
                          <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-2">
                            {routineTasks
                              .sort((a, b) => (a.order || 0) - (b.order || 0))
                              .map((task, index) => (
                                <Draggable key={task.id} draggableId={task.id} index={index}>
                                  {(provided) => (
                                    <div
                                      ref={provided.innerRef}
                                      {...provided.draggableProps}
                                      {...provided.dragHandleProps}
                                      className="flex items-center justify-between p-2 bg-muted/50 rounded-md"
                                    >
                                      <div className="flex items-center gap-2">
                                        <Checkbox
                                          checked={task.completed}
                                          onCheckedChange={(checked) => handleTaskStatusChange(task, !!checked)}
                                        />
                                        <span className={task.completed ? "line-through text-muted-foreground" : ""}>
                                          {task.name}
                                        </span>
                                      </div>
                                      <div className="flex items-center">
                                        <Dialog>
                                          <DialogTrigger asChild>
                                            <Button variant="ghost" size="icon" className="h-7 w-7">
                                              <Edit className="h-3 w-3" />
                                            </Button>
                                          </DialogTrigger>
                                          <DialogContent>
                                            <DialogHeader>
                                              <DialogTitle>Editar Tarefa</DialogTitle>
                                            </DialogHeader>
                                            <TaskForm
                                              task={task}
                                              routineId={routine.id}
                                              onSuccess={() => fetchData()}
                                            />
                                          </DialogContent>
                                        </Dialog>
                                        <Button
                                          variant="ghost"
                                          size="icon"
                                          className="h-7 w-7 text-destructive"
                                          onClick={() => handleDeleteTask(task.id)}
                                        >
                                          <Trash2 className="h-3 w-3" />
                                        </Button>
                                      </div>
                                    </div>
                                  )}
                                </Draggable>
                              ))}
                            {provided.placeholder}
                          </div>
                        )}
                      </Droppable>
                    </DragDropContext>

                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm" className="w-full mt-2">
                          <Plus className="h-4 w-4 mr-2" />
                          Adicionar Tarefa
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Adicionar Tarefa</DialogTitle>
                        </DialogHeader>
                        <TaskForm routineId={routine.id} onSuccess={() => fetchData()} />
                      </DialogContent>
                    </Dialog>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
            <CardFooter className="pt-0">
              <div className="flex justify-between items-center w-full text-xs text-muted-foreground">
                <div className="flex items-center">
                  <Calendar className="h-3 w-3 mr-1" />
                  Criada em {new Date(routine.created_at).toLocaleDateString()}
                </div>
                {completedTasks === routineTasks.length && routineTasks.length > 0 && (
                  <div className="flex items-center text-green-500">
                    <CheckCircle2 className="h-3 w-3 mr-1" />
                    Completa
                  </div>
                )}
              </div>
            </CardFooter>
          </Card>
        )
      })}

      {/* Modal de edição de rotina */}
      <Dialog open={!!editingRoutine} onOpenChange={(open) => !open && setEditingRoutine(null)}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Editar Rotina</DialogTitle>
          </DialogHeader>
          {editingRoutine && (
            <RoutineForm
              routine={editingRoutine}
              onSuccess={() => {
                fetchData()
                setEditingRoutine(null)
              }}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Modal de edição de tarefa */}
      <Dialog open={!!editingTask} onOpenChange={(open) => !open && setEditingTask(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Tarefa</DialogTitle>
          </DialogHeader>
          {editingTask && (
            <TaskForm
              task={editingTask}
              routineId={editingTask.routine_id}
              onSuccess={() => {
                fetchData()
                setEditingTask(null)
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
