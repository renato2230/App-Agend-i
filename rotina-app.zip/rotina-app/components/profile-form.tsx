"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useLocalStorage } from "@/hooks/use-local-storage"
import { Check, Loader2 } from "lucide-react"

interface ProfileFormProps {
  initialData: {
    nome: string
    profissao: string
    telefone: string
    email: string
    website: string
    bio: string
  }
}

export default function ProfileForm({ initialData }: ProfileFormProps) {
  const [profileData, setProfileData] = useLocalStorage("profileData", initialData)
  const [isLoading, setIsLoading] = useState(false)
  const [isSaved, setIsSaved] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setProfileData({ ...profileData, [name]: value })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulando uma requisição
    setTimeout(() => {
      setIsLoading(false)
      setIsSaved(true)

      setTimeout(() => {
        setIsSaved(false)
      }, 3000)
    }, 1000)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="nome">Nome Completo</Label>
          <Input
            id="nome"
            name="nome"
            value={profileData.nome}
            onChange={handleChange}
            placeholder="Seu nome completo"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="profissao">Profissão</Label>
          <Input
            id="profissao"
            name="profissao"
            value={profileData.profissao}
            onChange={handleChange}
            placeholder="Sua profissão"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="telefone">Telefone</Label>
          <Input
            id="telefone"
            name="telefone"
            value={profileData.telefone}
            onChange={handleChange}
            placeholder="(00) 00000-0000"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            name="email"
            type="email"
            value={profileData.email}
            onChange={handleChange}
            placeholder="seu@email.com"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="website">Website</Label>
          <Input
            id="website"
            name="website"
            value={profileData.website}
            onChange={handleChange}
            placeholder="www.seusite.com.br"
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="bio">Biografia Profissional</Label>
        <Textarea
          id="bio"
          name="bio"
          value={profileData.bio}
          onChange={handleChange}
          placeholder="Descreva sua experiência e especialidades"
          rows={4}
        />
      </div>

      <Button type="submit" disabled={isLoading || isSaved} className="w-full md:w-auto">
        {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
        {isSaved && <Check className="mr-2 h-4 w-4" />}
        {isLoading ? "Salvando..." : isSaved ? "Salvo!" : "Salvar Alterações"}
      </Button>
    </form>
  )
}
