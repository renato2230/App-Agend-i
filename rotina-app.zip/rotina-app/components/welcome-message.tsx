"use client"

import { useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { useMascotContext } from "@/context/mascot-context"
import { useAuth } from "@/context/auth-context"

export function WelcomeMessage() {
  const { user } = useAuth()
  const { playWelcomeSequence } = useMascotContext()

  useEffect(() => {
    // Mostrar a sequência de boas-vindas quando o componente montar
    const timer = setTimeout(() => {
      playWelcomeSequence(user?.user_metadata?.name || user?.email?.split("@")[0])
    }, 1000)

    return () => clearTimeout(timer)
  }, [playWelcomeSequence, user])

  const userName = user?.user_metadata?.name || user?.email?.split("@")[0] || "Usuário"
  const currentHour = new Date().getHours()

  let greeting = "Bom dia"
  if (currentHour >= 12 && currentHour < 18) {
    greeting = "Boa tarde"
  } else if (currentHour >= 18 || currentHour < 5) {
    greeting = "Boa noite"
  }

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-2xl font-bold mb-2">
          {greeting}, {userName}!
        </h2>
        <p className="text-gray-600 dark:text-gray-400">
          Bem-vindo ao Agendêi. Organize seu dia e aumente sua produtividade.
        </p>
      </CardContent>
    </Card>
  )
}
