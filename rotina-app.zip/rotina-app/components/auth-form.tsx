"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { CalendarCheck2, Loader2 } from "lucide-react"
import { useAuth } from "@/context/auth-context"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function AuthForm() {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()
  const { signIn, signUp } = useAuth()

  // Estado para o formulário de login
  const [loginData, setLoginData] = useState({
    email: "",
    password: "",
  })

  // Estado para o formulário de registro
  const [registerData, setRegisterData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  })

  const handleLoginChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setLoginData({ ...loginData, [name]: value })
  }

  const handleRegisterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setRegisterData({ ...registerData, [name]: value })
  }

  // Função para definir o cookie de teste
  const setTestCookie = () => {
    // Definir cookie para o usuário de teste
    document.cookie = "test_session=admin; path=/; max-age=86400"
    // Também armazenar no localStorage como backup
    localStorage.setItem("testUserActive", "true")
  }

  // Modificar a função handleLogin para aceitar login com usuário/senha "admin"
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    try {
      // Para fins de teste durante desenvolvimento
      if (loginData.email === "admin" && loginData.password === "admin") {
        // Definir cookie para o usuário de teste
        setTestCookie()

        // Simular um login bem-sucedido
        await signIn(loginData.email, loginData.password)

        // Pequeno atraso para garantir que o cookie seja definido
        setTimeout(() => {
          router.push("/dashboard")
        }, 100)

        return
      }

      const { error } = await signIn(loginData.email, loginData.password)

      if (error) {
        setError(error.message)
        setIsLoading(false)
        return
      }

      router.push("/dashboard")
    } catch (err: any) {
      setError(err.message || "Ocorreu um erro durante o login")
      setIsLoading(false)
    }
  }

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (registerData.password !== registerData.confirmPassword) {
      setError("As senhas não coincidem")
      return
    }

    setIsLoading(true)

    try {
      const { error } = await signUp(registerData.email, registerData.password, registerData.name)

      if (error) {
        setError(error.message)
        setIsLoading(false)
        return
      }

      // Redirecionar para o dashboard ou mostrar mensagem de confirmação
      setError("Registro realizado com sucesso! Verifique seu email para confirmar sua conta.")
      setIsLoading(false)
    } catch (err: any) {
      setError(err.message || "Ocorreu um erro durante o registro")
      setIsLoading(false)
    }
  }

  // Função para fazer login direto como admin (para facilitar o teste)
  const handleTestLogin = () => {
    setTestCookie()
    signIn("admin", "admin").then(() => {
      router.push("/dashboard")
    })
  }

  return (
    <div className="bg-card p-8 rounded-xl shadow-lg w-96 space-y-6">
      <div className="text-center">
        <div className="flex justify-center mb-2">
          <div className="h-12 w-12 bg-primary/20 rounded-full flex items-center justify-center">
            <CalendarCheck2 className="h-7 w-7 text-primary" />
          </div>
        </div>
        <h1 className="text-3xl font-bold logo-text">Agendêi</h1>
        <p className="text-muted-foreground mt-2">Organize sua vida com facilidade</p>
      </div>

      {error && (
        <div
          className="bg-destructive/10 border border-destructive text-destructive px-4 py-3 rounded-lg relative"
          role="alert"
        >
          <span className="block sm:inline">{error}</span>
        </div>
      )}

      <Tabs defaultValue="login" className="w-full">
        <TabsList className="grid grid-cols-2 w-full">
          <TabsTrigger value="login">Login</TabsTrigger>
          <TabsTrigger value="register">Cadastro</TabsTrigger>
        </TabsList>

        <TabsContent value="login">
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <Label htmlFor="email">Usuário</Label>
              <Input
                id="email"
                name="email"
                type="text"
                placeholder="Digite seu usuário"
                value={loginData.email}
                onChange={handleLoginChange}
                required
              />
            </div>

            <div>
              <Label htmlFor="password">Senha</Label>
              <Input
                id="password"
                name="password"
                type="password"
                placeholder="Digite sua senha"
                value={loginData.password}
                onChange={handleLoginChange}
                required
              />
            </div>

            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Entrando...
                </>
              ) : (
                "Entrar"
              )}
            </Button>

            <div className="text-center text-sm text-muted-foreground">
              <p>
                Para teste, use: <br />
                Usuário: admin <br />
                Senha: admin
              </p>
              <Button type="button" variant="link" className="mt-2 text-primary" onClick={handleTestLogin}>
                Entrar como Admin (Teste)
              </Button>
            </div>
          </form>
        </TabsContent>

        <TabsContent value="register">
          <form onSubmit={handleRegister} className="space-y-4">
            <div>
              <Label htmlFor="name">Nome</Label>
              <Input
                id="name"
                name="name"
                type="text"
                placeholder="Seu nome completo"
                value={registerData.name}
                onChange={handleRegisterChange}
                required
              />
            </div>

            <div>
              <Label htmlFor="register-email">Email</Label>
              <Input
                id="register-email"
                name="email"
                type="email"
                placeholder="seu@email.com"
                value={registerData.email}
                onChange={handleRegisterChange}
                required
              />
            </div>

            <div>
              <Label htmlFor="register-password">Senha</Label>
              <Input
                id="register-password"
                name="password"
                type="password"
                placeholder="Crie uma senha"
                value={registerData.password}
                onChange={handleRegisterChange}
                required
              />
            </div>

            <div>
              <Label htmlFor="confirmPassword">Confirme a senha</Label>
              <Input
                id="confirmPassword"
                name="confirmPassword"
                type="password"
                placeholder="Confirme sua senha"
                value={registerData.confirmPassword}
                onChange={handleRegisterChange}
                required
              />
            </div>

            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Cadastrando...
                </>
              ) : (
                "Cadastrar"
              )}
            </Button>
          </form>
        </TabsContent>
      </Tabs>
    </div>
  )
}
