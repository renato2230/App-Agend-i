"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { CalendarCheck2 } from "lucide-react"

export default function LoginForm() {
  const [usuario, setUsuario] = useState("")
  const [senha, setSenha] = useState("")
  const [error, setError] = useState("")
  const router = useRouter()

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (usuario === "admin" && senha === "admin") {
      router.push("/dashboard")
    } else {
      setError("Usuário ou senha incorretos")
    }
  }

  return (
    <div className="bg-card p-8 rounded-xl shadow-lg w-96 space-y-6">
      <div className="text-center">
        <div className="flex justify-center mb-2">
          <div className="h-12 w-12 bg-primary/20 rounded-full flex items-center justify-center">
            <CalendarCheck2 className="h-7 w-7 text-primary" />
          </div>
        </div>
        <h1 className="text-3xl font-bold logo-text">Agendêi</h1>
        <p className="text-muted-foreground mt-2">Organize sua vida com facilidade</p>
      </div>

      {error && (
        <div
          className="bg-destructive/10 border border-destructive text-destructive px-4 py-3 rounded-lg relative"
          role="alert"
        >
          <span className="block sm:inline">{error}</span>
        </div>
      )}

      <form onSubmit={handleLogin} className="space-y-4">
        <div>
          <label htmlFor="usuario" className="block text-sm font-medium mb-1">
            Usuário
          </label>
          <input
            id="usuario"
            type="text"
            placeholder="Digite seu usuário"
            value={usuario}
            onChange={(e) => setUsuario(e.target.value)}
            className="w-full p-3 border border-input bg-background rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
            required
          />
        </div>

        <div>
          <label htmlFor="senha" className="block text-sm font-medium mb-1">
            Senha
          </label>
          <input
            id="senha"
            type="password"
            placeholder="Digite sua senha"
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
            className="w-full p-3 border border-input bg-background rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
            required
          />
        </div>

        <button
          type="submit"
          className="w-full bg-primary text-primary-foreground py-3 rounded-md hover:bg-primary/90 transition duration-200 font-medium"
        >
          Entrar
        </button>
      </form>

      <div className="text-center text-sm text-muted-foreground">
        <p>
          Não tem uma conta?{" "}
          <a href="#" className="text-primary hover:underline">
            Cadastre-se
          </a>
        </p>
      </div>
    </div>
  )
}
