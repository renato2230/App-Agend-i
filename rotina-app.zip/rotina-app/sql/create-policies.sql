-- Criar políticas de segurança para rotinas
CREATE POLICY "Usuários podem ver suas próprias rotinas" 
  ON routines FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Usuários podem inserir suas próprias rotinas" 
  ON routines FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Usuários podem atualizar suas próprias rotinas" 
  ON routines FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Usuários podem excluir suas próprias rotinas" 
  ON routines FOR DELETE 
  USING (auth.uid() = user_id);

-- Criar políticas de segurança para tarefas
CREATE POLICY "Usuários podem ver suas próprias tarefas" 
  ON tasks FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Usuários podem inserir suas próprias tarefas" 
  ON tasks FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Usuários podem atualizar suas próprias tarefas" 
  ON tasks FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Usuários podem excluir suas próprias tarefas" 
  ON tasks FOR DELETE 
  USING (auth.uid() = user_id);

-- Criar políticas de segurança para posts de redes sociais
CREATE POLICY "Usuários podem ver seus próprios posts" 
  ON social_media_posts FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Usuários podem inserir seus próprios posts" 
  ON social_media_posts FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Usuários podem atualizar seus próprios posts" 
  ON social_media_posts FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Usuários podem excluir seus próprios posts" 
  ON social_media_posts FOR DELETE 
  USING (auth.uid() = user_id);
