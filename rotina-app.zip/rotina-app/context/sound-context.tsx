"use client"

import { createContext, useContext, type ReactNode, useEffect, useState } from "react"
import { useSoundEffects, type SoundEffect } from "@/hooks/use-sound-effects"
import { useLocalStorage } from "@/hooks/use-local-storage"

interface SoundContextType {
  isEnabled: boolean
  volume: number
  isLoaded: boolean
  loadedSounds: string[]
  playSound: (sound: SoundEffect) => void
  stopSound: (sound: SoundEffect) => void
  stopAllSounds: () => void
  toggleSounds: () => void
  setVolume: (volume: number) => void
}

const SoundContext = createContext<SoundContextType | undefined>(undefined)

export function SoundProvider({ children }: { children: ReactNode }) {
  // Verificar se estamos no navegador
  const [isBrowser, setIsBrowser] = useState(false)

  useEffect(() => {
    setIsBrowser(typeof window !== "undefined")
  }, [])

  // Usar localStorage para persistir as preferências de som (apenas no navegador)
  const [storedSoundEnabled, setStoredSoundEnabled] = useLocalStorage("sound-enabled", true)
  const [storedVolume, setStoredVolume] = useLocalStorage("sound-volume", 0.5)

  const sound = useSoundEffects({
    enabled: storedSoundEnabled,
    volume: storedVolume,
  })

  // Sincronizar as mudanças com o localStorage (apenas no navegador)
  useEffect(() => {
    if (isBrowser) {
      setStoredSoundEnabled(sound.isEnabled)
    }
  }, [sound.isEnabled, setStoredSoundEnabled, isBrowser])

  useEffect(() => {
    if (isBrowser) {
      setStoredVolume(sound.volume)
    }
  }, [sound.volume, setStoredVolume, isBrowser])

  return <SoundContext.Provider value={sound}>{children}</SoundContext.Provider>
}

export function useSoundContext() {
  const context = useContext(SoundContext)
  if (context === undefined) {
    throw new Error("useSoundContext must be used within a SoundProvider")
  }
  return context
}
