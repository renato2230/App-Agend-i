"use client"

import { createContext, useContext, type ReactNode } from "react"
import { useMascot } from "@/hooks/use-mascot"
import type { MascotMood } from "@/components/mascot/mascot"

interface MascotContextType {
  mood: MascotMood
  message?: string
  isVisible: boolean
  isTransitioning: boolean
  showMascot: (mood?: MascotMood, message?: string) => void
  hideMascot: () => void
  toggleMascot: () => void
  changeMood: (mood: MascotMood, message?: string) => void
  makeHappy: (message?: string, duration?: number) => void
  makeThinking: (message?: string, duration?: number) => void
  makeCelebrating: (message?: string, duration?: number) => void
  makeSleeping: (message?: string, duration?: number) => void
  makeWaving: (message?: string, duration?: number) => void
  makeIdle: (message?: string) => void
  transitionMoods: (transitions: { mood: MascotMood; message?: string; duration?: number }[]) => void
  playWelcomeSequence: (userName?: string) => void
  playCelebrationSequence: (achievement?: string) => void
  clearTransitionQueue: () => void
}

const MascotContext = createContext<MascotContextType | undefined>(undefined)

export function MascotProvider({ children }: { children: ReactNode }) {
  const mascot = useMascot()

  return <MascotContext.Provider value={mascot}>{children}</MascotContext.Provider>
}

export function useMascotContext() {
  const context = useContext(MascotContext)
  if (context === undefined) {
    throw new Error("useMascotContext must be used within a MascotProvider")
  }
  return context
}
