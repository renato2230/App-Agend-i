if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register("/sw.js")
      .then((registration) => {
        console.log("Service Worker registrado com sucesso:", registration.scope)
      })
      .catch((error) => {
        console.log("Falha ao registrar o Service Worker:", error)
      })
  })
}

// Verificar atualizações do Service Worker
if ("serviceWorker" in navigator && "SyncManager" in window) {
  navigator.serviceWorker.ready.then((registration) => {
    // Registrar sincronização em segundo plano
    document.addEventListener("online", () => {
      registration.sync.register("sync-tasks")
    })
  })
}

// Solicitar permissão para notificações
function requestNotificationPermission() {
  if ("Notification" in window) {
    Notification.requestPermission().then((permission) => {
      if (permission === "granted") {
        console.log("Permissão de notificação concedida")
        // Aqui você pode registrar o endpoint de push notification
      }
    })
  }
}

// Verificar se o app está sendo executado como PWA
function isPWA() {
  return window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true
}

// Detectar quando o app é instalado
window.addEventListener("appinstalled", (event) => {
  console.log("Aplicativo instalado")
  // Você pode atualizar a UI ou enviar analytics aqui
})

// Expor funções úteis globalmente
window.pwaHelpers = {
  requestNotificationPermission,
  isPWA,
}
