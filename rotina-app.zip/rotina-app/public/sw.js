const CACHE_NAME = "agendei-cache-v1"
const urlsToCache = [
  "/",
  "/offline",
  "/dashboard",
  "/icons/icon-192x192.png",
  "/icons/icon-512x512.png",
  "/manifest.json",
]

// Instalação do Service Worker
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log("Cache aberto")
      return cache.addAll(urlsToCache)
    }),
  )
})

// Ativação do Service Worker
self.addEventListener("activate", (event) => {
  const cacheWhitelist = [CACHE_NAME]
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName)
          }
        }),
      )
    }),
  )
})

// Estratégia de cache: Network First, fallback para cache
self.addEventListener("fetch", (event) => {
  event.respondWith(
    fetch(event.request)
      .then((response) => {
        // Se a resposta for válida, clone-a e armazene-a no cache
        if (response && response.status === 200 && response.type === "basic") {
          const responseToCache = response.clone()
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseToCache)
          })
        }
        return response
      })
      .catch(() => {
        // Se a rede falhar, tente buscar do cache
        return caches.match(event.request).then((response) => {
          if (response) {
            return response
          }

          // Se o recurso não estiver no cache e for uma página de navegação,
          // retorne a página offline
          if (event.request.mode === "navigate") {
            return caches.match("/offline")
          }

          // Para imagens, retorne um placeholder
          if (event.request.destination === "image") {
            return new Response(
              '<svg width="400" height="300" xmlns="http://www.w3.org/2000/svg">' +
                '<rect width="400" height="300" fill="#eee" />' +
                '<text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-family="sans-serif" font-size="24" fill="#999">Imagem Indisponível</text>' +
                "</svg>",
              { headers: { "Content-Type": "image/svg+xml" } },
            )
          }

          // Para outros recursos, retorne uma resposta vazia
          return new Response("", { status: 408, statusText: "Recurso não disponível offline" })
        })
      }),
  )
})

// Sincronização em segundo plano
self.addEventListener("sync", (event) => {
  if (event.tag === "sync-tasks") {
    event.waitUntil(syncTasks())
  }
})

// Função para sincronizar tarefas quando a conexão for restabelecida
async function syncTasks() {
  try {
    const pendingTasks = await getPendingTasks()
    if (pendingTasks.length > 0) {
      await sendPendingTasks(pendingTasks)
      await clearPendingTasks()
      // Notificar o usuário que as tarefas foram sincronizadas
      self.registration.showNotification("Agendêi", {
        body: "Suas tarefas foram sincronizadas com sucesso!",
        icon: "/icons/icon-192x192.png",
      })
    }
  } catch (error) {
    console.error("Erro ao sincronizar tarefas:", error)
  }
}

// Funções auxiliares para gerenciar tarefas pendentes
async function getPendingTasks() {
  const db = await openDatabase()
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(["pendingTasks"], "readonly")
    const store = transaction.objectStore("pendingTasks")
    const request = store.getAll()

    request.onsuccess = () => {
      resolve(request.result)
    }

    request.onerror = () => {
      reject(request.error)
    }
  })
}

async function sendPendingTasks(tasks) {
  // Implementar lógica para enviar tarefas para o servidor
  return Promise.resolve()
}

async function clearPendingTasks() {
  const db = await openDatabase()
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(["pendingTasks"], "readwrite")
    const store = transaction.objectStore("pendingTasks")
    const request = store.clear()

    request.onsuccess = () => {
      resolve()
    }

    request.onerror = () => {
      reject(request.error)
    }
  })
}

async function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("agendeiOfflineDB", 1)

    request.onupgradeneeded = (event) => {
      const db = event.target.result
      if (!db.objectStoreNames.contains("pendingTasks")) {
        db.createObjectStore("pendingTasks", { keyPath: "id", autoIncrement: true })
      }
    }

    request.onsuccess = () => {
      resolve(request.result)
    }

    request.onerror = () => {
      reject(request.error)
    }
  })
}

// Notificações push
self.addEventListener("push", (event) => {
  const data = event.data.json()
  const options = {
    body: data.body,
    icon: "/icons/icon-192x192.png",
    badge: "/icons/icon-72x72.png",
    vibrate: [100, 50, 100],
    data: {
      url: data.url || "/",
    },
  }

  event.waitUntil(self.registration.showNotification(data.title, options))
})

// Ação ao clicar na notificação
self.addEventListener("notificationclick", (event) => {
  event.notification.close()

  event.waitUntil(
    clients.matchAll({ type: "window" }).then((clientList) => {
      // Se já houver uma janela aberta, foque nela
      for (const client of clientList) {
        if (client.url === event.notification.data.url && "focus" in client) {
          return client.focus()
        }
      }
      // Caso contrário, abra uma nova janela
      if (clients.openWindow) {
        return clients.openWindow(event.notification.data.url)
      }
    }),
  )
})
