"use client"

import { useState, useEffect } from "react"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"

interface MotivationalQuote {
  id: string
  quote: string
  author: string | null
  category: string | null
}

export function useMotivationalQuote() {
  const [quote, setQuote] = useState<MotivationalQuote | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const supabase = createClientComponentClient()

  useEffect(() => {
    const fetchQuote = async () => {
      try {
        setIsLoading(true)

        // Usar a data atual como seed para selecionar a mesma frase durante todo o dia
        const today = new Date().toISOString().split("T")[0]
        const dateHash = hashString(today)

        // Buscar todas as frases ativas
        const { data, error } = await supabase
          .from("motivational_quotes")
          .select("id, quote, author, category")
          .eq("is_active", true)

        if (error) {
          throw error
        }

        if (data && data.length > 0) {
          // Selecionar uma frase baseada na data atual
          const index = dateHash % data.length
          setQuote(data[index])
        }
      } catch (error) {
        console.error("Erro ao buscar frase motivacional:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchQuote()
  }, [supabase])

  return { quote, isLoading }
}

// Função para gerar um hash numérico a partir de uma string
function hashString(str: string): number {
  let hash = 0
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i)
    hash = (hash << 5) - hash + char
    hash = hash & hash // Converter para um inteiro de 32 bits
  }
  return Math.abs(hash)
}
