"use client"

import { useState, useCallback, useRef } from "react"
import type { MascotMood } from "@/components/mascot/mascot"
import { useSoundContext } from "@/context/sound-context"

interface UseMascotOptions {
  initialMood?: MascotMood
  initialMessage?: string
  playSounds?: boolean
}

interface MoodTransition {
  mood: MascotMood
  message?: string
  duration?: number
  playSound?: boolean
}

export function useMascot(options: UseMascotOptions = {}) {
  const [mood, setMood] = useState<MascotMood>(options.initialMood || "idle")
  const [message, setMessage] = useState<string | undefined>(options.initialMessage)
  const [isVisible, setIsVisible] = useState(true)
  const [isTransitioning, setIsTransitioning] = useState(false)
  const transitionQueueRef = useRef<MoodTransition[]>([])
  const timeoutRef = useRef<NodeJS.Timeout | null>(null)
  const { playSound, isEnabled } = useSoundContext()
  const playSounds = options.playSounds !== undefined ? options.playSounds : true

  const clearTransitionQueue = useCallback(() => {
    transitionQueueRef.current = []
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current)
      timeoutRef.current = null
    }
  }, [])

  const showMascot = useCallback(
    (newMood?: MascotMood, newMessage?: string) => {
      if (newMood) {
        setMood(newMood)
        // Reproduzir som se estiver habilitado
        if (playSounds && isEnabled && newMood !== "idle") {
          playSound(newMood)
        }
      }
      if (newMessage !== undefined) {
        setMessage(newMessage)
        // Reproduzir som de notificação quando a mensagem mudar
        if (playSounds && isEnabled && newMessage) {
          playSound("notification")
        }
      }
      setIsVisible(true)
    },
    [isEnabled, playSound, playSounds],
  )

  const hideMascot = useCallback(() => {
    setIsVisible(false)
  }, [])

  const toggleMascot = useCallback(() => {
    setIsVisible((prev) => !prev)
    // Reproduzir som de clique
    if (playSounds && isEnabled) {
      playSound("click")
    }
  }, [isEnabled, playSound, playSounds])

  const changeMood = useCallback(
    (newMood: MascotMood, newMessage?: string) => {
      setMood(newMood)
      // Reproduzir som se estiver habilitado
      if (playSounds && isEnabled && newMood !== "idle") {
        playSound(newMood)
      }

      if (newMessage !== undefined) {
        setMessage(newMessage)
        // Reproduzir som de notificação quando a mensagem mudar
        if (playSounds && isEnabled && newMessage) {
          playSound("notification")
        }
      }
    },
    [isEnabled, playSound, playSounds],
  )

  // Função para processar a próxima transição na fila
  const processNextTransition = useCallback(() => {
    if (transitionQueueRef.current.length > 0) {
      const nextTransition = transitionQueueRef.current.shift()
      if (nextTransition) {
        setMood(nextTransition.mood)

        // Reproduzir som se estiver habilitado
        if (playSounds && isEnabled && nextTransition.playSound !== false && nextTransition.mood !== "idle") {
          playSound(nextTransition.mood)
        }

        if (nextTransition.message !== undefined) {
          setMessage(nextTransition.message)
          // Reproduzir som de notificação quando a mensagem mudar
          if (playSounds && isEnabled && nextTransition.message) {
            playSound("notification")
          }
        }

        setIsTransitioning(true)

        // Configurar o próximo timeout se houver uma duração
        if (nextTransition.duration) {
          timeoutRef.current = setTimeout(() => {
            setIsTransitioning(false)
            processNextTransition()
          }, nextTransition.duration)
        } else {
          // Se não houver duração, marque como não transitando imediatamente
          setIsTransitioning(false)
        }
      }
    } else {
      setIsTransitioning(false)
    }
  }, [isEnabled, playSound, playSounds])

  // Função para encadear várias transições de humor
  const transitionMoods = useCallback(
    (transitions: MoodTransition[]) => {
      // Limpar a fila atual
      clearTransitionQueue()

      // Adicionar novas transições à fila
      transitionQueueRef.current = [...transitions]

      // Iniciar o processamento se não estiver já transitando
      if (!isTransitioning) {
        processNextTransition()
      }
    },
    [clearTransitionQueue, isTransitioning, processNextTransition],
  )

  // Funções de conveniência para mudar o humor
  const makeHappy = useCallback(
    (message?: string, duration?: number) => {
      if (duration) {
        transitionMoods([{ mood: "happy", message, duration }, { mood: "idle" }])
      } else {
        changeMood("happy", message)
      }
    },
    [changeMood, transitionMoods],
  )

  const makeThinking = useCallback(
    (message?: string, duration?: number) => {
      if (duration) {
        transitionMoods([{ mood: "thinking", message, duration }, { mood: "idle" }])
      } else {
        changeMood("thinking", message)
      }
    },
    [changeMood, transitionMoods],
  )

  const makeCelebrating = useCallback(
    (message?: string, duration?: number) => {
      if (duration) {
        transitionMoods([
          { mood: "celebrating", message, duration },
          { mood: "happy", duration: 1000 },
          { mood: "idle" },
        ])
      } else {
        changeMood("celebrating", message)
      }

      // Reproduzir som de conclusão para celebrações
      if (playSounds && isEnabled) {
        playSound("complete")
      }
    },
    [changeMood, transitionMoods, isEnabled, playSound, playSounds],
  )

  const makeSleeping = useCallback(
    (message?: string, duration?: number) => {
      if (duration) {
        transitionMoods([{ mood: "sleeping", message, duration }, { mood: "idle" }])
      } else {
        changeMood("sleeping", message)
      }
    },
    [changeMood, transitionMoods],
  )

  const makeWaving = useCallback(
    (message?: string, duration?: number) => {
      if (duration) {
        transitionMoods([{ mood: "waving", message, duration }, { mood: "idle" }])
      } else {
        changeMood("waving", message)
      }
    },
    [changeMood, transitionMoods],
  )

  const makeIdle = useCallback(
    (message?: string) => {
      changeMood("idle", message)
    },
    [changeMood],
  )

  // Sequência de boas-vindas
  const playWelcomeSequence = useCallback(
    (userName?: string) => {
      const welcomeMessage = userName ? `Olá, ${userName}! Bem-vindo ao Agendêi!` : "Olá! Bem-vindo ao Agendêi!"

      transitionMoods([
        { mood: "waving", message: welcomeMessage, duration: 2000 },
        { mood: "happy", message: "Estou aqui para ajudar você a organizar seu dia!", duration: 2000 },
        { mood: "thinking", message: "Vamos começar criando uma rotina?", duration: 2000 },
        { mood: "idle", message: "Clique em mim se precisar de ajuda!" },
      ])

      // Reproduzir som de boas-vindas
      if (playSounds && isEnabled) {
        playSound("welcome")
      }
    },
    [transitionMoods, isEnabled, playSound, playSounds],
  )

  // Sequência de celebração
  const playCelebrationSequence = useCallback(
    (achievement?: string) => {
      const celebrationMessage = achievement ? `Parabéns! Você completou ${achievement}!` : "Parabéns! Você conseguiu!"

      transitionMoods([
        { mood: "celebrating", message: celebrationMessage, duration: 3000 },
        { mood: "happy", message: "Continue assim!", duration: 1500 },
        { mood: "idle" },
      ])

      // Reproduzir som de conclusão
      if (playSounds && isEnabled) {
        playSound("complete")
      }
    },
    [transitionMoods, isEnabled, playSound, playSounds],
  )

  return {
    mood,
    message,
    isVisible,
    isTransitioning,
    showMascot,
    hideMascot,
    toggleMascot,
    changeMood,
    makeHappy,
    makeThinking,
    makeCelebrating,
    makeSleeping,
    makeWaving,
    makeIdle,
    transitionMoods,
    playWelcomeSequence,
    playCelebrationSequence,
    clearTransitionQueue,
  }
}
