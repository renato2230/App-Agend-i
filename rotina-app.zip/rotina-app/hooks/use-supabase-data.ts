"use client"

import { useState, useEffect, useCallback } from "react"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"
import { useAuth } from "@/context/auth-context"
import { useToast } from "@/components/ui/use-toast"

interface UseSupabaseDataOptions {
  orderBy?: string
  orderDirection?: "asc" | "desc"
  limit?: number
  filter?: Record<string, any>
}

export function useSupabaseData<T = any>(table: string, initialData: T[] = [], options: UseSupabaseDataOptions = {}) {
  const [data, setData] = useState<T[]>(initialData)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<Error | null>(null)
  const supabase = createClientComponentClient()
  const { user, isTestUser } = useAuth()
  const { toast } = useToast()

  const fetchData = useCallback(async () => {
    if (isTestUser) {
      return // Não buscar dados para usuário de teste
    }

    if (!user) {
      setData([])
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      let query = supabase.from(table).select("*").eq("user_id", user.id)

      // Aplicar filtros adicionais
      if (options.filter) {
        Object.entries(options.filter).forEach(([key, value]) => {
          query = query.eq(key, value)
        })
      }

      // Aplicar ordenação
      if (options.orderBy) {
        query = query.order(options.orderBy, {
          ascending: options.orderDirection !== "desc",
        })
      }

      // Aplicar limite
      if (options.limit) {
        query = query.limit(options.limit)
      }

      const { data: fetchedData, error } = await query

      if (error) {
        throw error
      }

      setData(fetchedData || [])
    } catch (err: any) {
      console.error(`Erro ao buscar dados da tabela ${table}:`, err)
      setError(err)
      toast({
        title: "Erro ao carregar dados",
        description: err.message || "Não foi possível carregar os dados.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }, [user, isTestUser, supabase, table, options, toast])

  const addItem = useCallback(
    async (item: any) => {
      if (isTestUser) {
        toast({
          title: "Modo de demonstração",
          description: "Esta ação não é permitida no modo de demonstração.",
        })
        return null
      }

      if (!user) {
        toast({
          title: "Erro",
          description: "Você precisa estar logado para realizar esta ação.",
          variant: "destructive",
        })
        return null
      }

      try {
        const { data: insertedData, error } = await supabase
          .from(table)
          .insert({ ...item, user_id: user.id })
          .select()

        if (error) {
          throw error
        }

        // Atualizar o estado local
        setData((prevData) => [...prevData, ...(insertedData || [])])
        return insertedData?.[0] || null
      } catch (err: any) {
        console.error(`Erro ao adicionar item na tabela ${table}:`, err)
        toast({
          title: "Erro ao adicionar item",
          description: err.message || "Não foi possível adicionar o item.",
          variant: "destructive",
        })
        return null
      }
    },
    [user, isTestUser, supabase, table, toast],
  )

  const updateItem = useCallback(
    async (id: string, updates: any) => {
      if (isTestUser) {
        toast({
          title: "Modo de demonstração",
          description: "Esta ação não é permitida no modo de demonstração.",
        })
        return false
      }

      if (!user) {
        toast({
          title: "Erro",
          description: "Você precisa estar logado para realizar esta ação.",
          variant: "destructive",
        })
        return false
      }

      try {
        const { data: updatedData, error } = await supabase
          .from(table)
          .update(updates)
          .eq("id", id)
          .eq("user_id", user.id)
          .select()

        if (error) {
          throw error
        }

        // Atualizar o estado local
        setData((prevData) => prevData.map((item: any) => (item.id === id ? { ...item, ...updates } : item)))
        return true
      } catch (err: any) {
        console.error(`Erro ao atualizar item na tabela ${table}:`, err)
        toast({
          title: "Erro ao atualizar item",
          description: err.message || "Não foi possível atualizar o item.",
          variant: "destructive",
        })
        return false
      }
    },
    [user, isTestUser, supabase, table, toast],
  )

  const removeItem = useCallback(
    async (id: string) => {
      if (isTestUser) {
        toast({
          title: "Modo de demonstração",
          description: "Esta ação não é permitida no modo de demonstração.",
        })
        return false
      }

      if (!user) {
        toast({
          title: "Erro",
          description: "Você precisa estar logado para realizar esta ação.",
          variant: "destructive",
        })
        return false
      }

      try {
        const { error } = await supabase.from(table).delete().eq("id", id).eq("user_id", user.id)

        if (error) {
          throw error
        }

        // Atualizar o estado local
        setData((prevData) => prevData.filter((item: any) => item.id !== id))
        return true
      } catch (err: any) {
        console.error(`Erro ao remover item da tabela ${table}:`, err)
        toast({
          title: "Erro ao remover item",
          description: err.message || "Não foi possível remover o item.",
          variant: "destructive",
        })
        return false
      }
    },
    [user, isTestUser, supabase, table, toast],
  )

  // Buscar dados ao montar o componente ou quando o usuário mudar
  useEffect(() => {
    fetchData()
  }, [fetchData])

  return {
    data,
    isLoading,
    error,
    fetchData,
    addItem,
    updateItem,
    removeItem,
  }
}
