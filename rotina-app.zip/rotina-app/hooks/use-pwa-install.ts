"use client"

import { useState, useEffect } from "react"

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>
}

export function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null)
  const [canInstall, setCanInstall] = useState(false)

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      // Impedir que o Chrome mostre o prompt automaticamente
      e.preventDefault()
      // Armazenar o evento para uso posterior
      setDeferredPrompt(e as BeforeInstallPromptEvent)
      // Atualizar o estado para mostrar o botão de instalação
      setCanInstall(true)
    }

    const handleAppInstalled = () => {
      // Limpar o prompt armazenado
      setDeferredPrompt(null)
      // Ocultar o botão de instalação
      setCanInstall(false)
      // Opcional: registrar que o app foi instalado
      console.log("PWA foi instalado com sucesso")
    }

    // Verificar se o app já está instalado
    if (window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true) {
      setCanInstall(false)
    }

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt)
    window.addEventListener("appinstalled", handleAppInstalled)

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt)
      window.removeEventListener("appinstalled", handleAppInstalled)
    }
  }, [])

  const installPWA = async () => {
    if (!deferredPrompt) {
      console.log("Não é possível instalar o PWA agora")
      return
    }

    // Mostrar o prompt de instalação
    deferredPrompt.prompt()

    // Aguardar a escolha do usuário
    const choiceResult = await deferredPrompt.userChoice

    // Limpar o prompt armazenado
    setDeferredPrompt(null)

    if (choiceResult.outcome === "accepted") {
      console.log("Usuário aceitou a instalação do PWA")
    } else {
      console.log("Usuário recusou a instalação do PWA")
    }
  }

  return { canInstall, installPWA }
}
