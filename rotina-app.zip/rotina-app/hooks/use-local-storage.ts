"use client"

import { useState, useEffect } from "react"

export function useLocalStorage<T>(key: string, initialValue: T) {
  // Estado para armazenar o valor
  const [storedValue, setStoredValue] = useState<T>(initialValue)

  // Flag para verificar se estamos no navegador
  const [isClient, setIsClient] = useState(false)

  // Definir isClient como true quando o componente montar
  useEffect(() => {
    setIsClient(true)
  }, [])

  // Inicializar o valor do localStorage
  useEffect(() => {
    if (isClient) {
      try {
        const item = window.localStorage.getItem(key)
        if (item) {
          setStoredValue(JSON.parse(item))
        }
      } catch (error) {
        console.warn(`Erro ao ler ${key} do localStorage:`, error)
        setStoredValue(initialValue)
      }
    }
  }, [key, initialValue, isClient])

  // Função para atualizar o valor no localStorage
  const setValue = (value: T | ((val: T) => T)) => {
    try {
      // Permitir que o valor seja uma função
      const valueToStore = value instanceof Function ? value(storedValue) : value

      // Salvar no estado
      setStoredValue(valueToStore)

      // Salvar no localStorage apenas se estivermos no navegador
      if (isClient) {
        window.localStorage.setItem(key, JSON.stringify(valueToStore))
      }
    } catch (error) {
      console.warn(`Erro ao salvar ${key} no localStorage:`, error)
    }
  }

  return [storedValue, setValue] as const
}
