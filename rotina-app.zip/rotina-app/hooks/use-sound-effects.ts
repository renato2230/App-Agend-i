"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { AudioService } from "@/lib/audio-service"

// Definir os tipos de sons disponíveis
export type SoundEffect =
  | "welcome"
  | "happy"
  | "thinking"
  | "celebrating"
  | "sleeping"
  | "waving"
  | "click"
  | "complete"
  | "notification"
  | "error"

interface UseSoundEffectsOptions {
  enabled?: boolean
  volume?: number
}

export function useSoundEffects(options: UseSoundEffectsOptions = {}) {
  const [isEnabled, setIsEnabled] = useState(options.enabled ?? true)
  const [volume, setVolume] = useState(options.volume ?? 0.5)
  const audioServiceRef = useRef<AudioService | null>(null)
  const [isLoaded, setIsLoaded] = useState(false)
  const [loadedSounds, setLoadedSounds] = useState<string[]>([])

  // Inicializar o serviço de áudio
  useEffect(() => {
    // Verificar se estamos no navegador
    if (typeof window === "undefined") {
      return
    }

    const audioService = new AudioService()
    audioServiceRef.current = audioService

    // Definir o volume inicial
    audioService.setVolume(volume)

    // Pré-carregar sons com tratamento de erros
    const loadSounds = async () => {
      try {
        // Lista de sons para carregar
        const soundsToLoad = [
          { id: "welcome", url: "/sounds/welcome.mp3" },
          { id: "happy", url: "/sounds/happy.mp3" },
          { id: "thinking", url: "/sounds/thinking.mp3" },
          { id: "celebrating", url: "/sounds/celebrating.mp3" },
          { id: "sleeping", url: "/sounds/sleeping.mp3" },
          { id: "waving", url: "/sounds/waving.mp3" },
          { id: "click", url: "/sounds/click.mp3" },
          { id: "complete", url: "/sounds/complete.mp3" },
          { id: "notification", url: "/sounds/notification.mp3" },
          { id: "error", url: "/sounds/error.mp3" },
        ]

        // Carregar cada som individualmente
        const results = await Promise.all(
          soundsToLoad.map(async (sound) => {
            const success = await audioService.loadSound(sound.id, sound.url)
            return { id: sound.id, success }
          }),
        )

        // Filtrar os sons carregados com sucesso
        const successfullyLoaded = results.filter((result) => result.success).map((result) => result.id)

        setLoadedSounds(successfullyLoaded)
        setIsLoaded(successfullyLoaded.length > 0)
      } catch (error) {
        console.error("Erro ao carregar sons:", error)
        setIsLoaded(false)
      }
    }

    loadSounds()

    return () => {
      // Limpar recursos ao desmontar
      if (audioServiceRef.current) {
        audioServiceRef.current.dispose()
      }
    }
  }, [volume])

  // Reproduzir um som com verificação
  const playSound = useCallback(
    (sound: SoundEffect) => {
      if (isEnabled && audioServiceRef.current) {
        // Verificar se o som está na lista de sons carregados
        if (loadedSounds.includes(sound)) {
          audioServiceRef.current.playSound(sound)
        }
      }
    },
    [isEnabled, loadedSounds],
  )

  // Parar um som
  const stopSound = useCallback((sound: SoundEffect) => {
    if (audioServiceRef.current) {
      audioServiceRef.current.stopSound(sound)
    }
  }, [])

  // Parar todos os sons
  const stopAllSounds = useCallback(() => {
    if (audioServiceRef.current) {
      audioServiceRef.current.stopAllSounds()
    }
  }, [])

  // Ativar/desativar sons
  const toggleSounds = useCallback(() => {
    setIsEnabled((prev) => !prev)
  }, [])

  // Definir o volume
  const setAudioVolume = useCallback((newVolume: number) => {
    setVolume(newVolume)
    if (audioServiceRef.current) {
      audioServiceRef.current.setVolume(newVolume)
    }
  }, [])

  return {
    isEnabled,
    volume,
    isLoaded,
    loadedSounds,
    playSound,
    stopSound,
    stopAllSounds,
    toggleSounds,
    setVolume: setAudioVolume,
  }
}
