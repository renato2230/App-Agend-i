"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { WifiOff, RefreshCw, Home } from "lucide-react"
import Link from "next/link"

export default function OfflinePage() {
  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gray-50 dark:bg-gray-900">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto bg-yellow-100 dark:bg-yellow-900 p-3 rounded-full w-16 h-16 flex items-center justify-center mb-4">
            <WifiOff className="h-8 w-8 text-yellow-600 dark:text-yellow-300" />
          </div>
          <CardTitle className="text-2xl">Você está offline</CardTitle>
          <CardDescription>
            Não foi possível carregar esta página porque você está sem conexão com a internet.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-center text-sm text-muted-foreground">
            Algumas funcionalidades do Agendêi estão disponíveis offline. Você pode acessar suas rotinas e tarefas
            salvas anteriormente.
          </p>
        </CardContent>
        <CardFooter className="flex flex-col gap-2">
          <Button className="w-full" onClick={() => window.location.reload()}>
            <RefreshCw className="mr-2 h-4 w-4" />
            Tentar novamente
          </Button>
          <Link href="/dashboard" className="w-full">
            <Button variant="outline" className="w-full">
              <Home className="mr-2 h-4 w-4" />
              Ir para o Dashboard
            </Button>
          </Link>
        </CardFooter>
      </Card>
    </div>
  )
}
