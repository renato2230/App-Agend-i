"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/context/auth-context"
import Link from "next/link"
import { Settings, Bell, Palette, Volume2, Shield, Quote } from "lucide-react"

export default function ConfiguracoesPage() {
  const { isAdmin } = useAuth()
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("perfil")

  const handleSave = () => {
    toast({
      title: "Configurações salvas",
      description: "Suas configurações foram atualizadas com sucesso.",
    })
  }

  return (
    <div className="container mx-auto py-6">
      <h1 className="text-2xl font-bold mb-6">Configurações</h1>

      <Tabs defaultValue="perfil" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid grid-cols-2 md:grid-cols-6 gap-2">
          <TabsTrigger value="perfil" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            <span className="hidden md:inline">Perfil</span>
          </TabsTrigger>
          <TabsTrigger value="aparencia" className="flex items-center gap-2">
            <Palette className="h-4 w-4" />
            <span className="hidden md:inline">Aparência</span>
          </TabsTrigger>
          <TabsTrigger value="notificacoes" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            <span className="hidden md:inline">Notificações</span>
          </TabsTrigger>
          <TabsTrigger value="som" className="flex items-center gap-2">
            <Volume2 className="h-4 w-4" />
            <span className="hidden md:inline">Som</span>
          </TabsTrigger>
          <TabsTrigger value="privacidade" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            <span className="hidden md:inline">Privacidade</span>
          </TabsTrigger>
          {isAdmin && (
            <TabsTrigger value="admin" className="flex items-center gap-2">
              <Quote className="h-4 w-4" />
              <span className="hidden md:inline">Admin</span>
            </TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="perfil">
          <Card>
            <CardHeader>
              <CardTitle>Perfil</CardTitle>
              <CardDescription>Gerencie suas informações pessoais e preferências de conta.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nome">Nome</Label>
                  <Input id="nome" placeholder="Seu nome" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" placeholder="seu@email.com" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="profissao">Profissão</Label>
                  <Input id="profissao" placeholder="Sua profissão" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="telefone">Telefone</Label>
                  <Input id="telefone" placeholder="(00) 00000-0000" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="bio">Biografia</Label>
                <Textarea id="bio" placeholder="Conte um pouco sobre você" />
              </div>
              <Button onClick={handleSave}>Salvar alterações</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="aparencia">
          <Card>
            <CardHeader>
              <CardTitle>Aparência</CardTitle>
              <CardDescription>Personalize a aparência do aplicativo de acordo com suas preferências.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="dark-mode">Modo escuro</Label>
                    <p className="text-sm text-muted-foreground">Ative o modo escuro para reduzir o cansaço visual.</p>
                  </div>
                  <Switch id="dark-mode" />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="compact-mode">Modo compacto</Label>
                    <p className="text-sm text-muted-foreground">
                      Reduza o espaçamento entre os elementos para ver mais conteúdo.
                    </p>
                  </div>
                  <Switch id="compact-mode" />
                </div>
                <div className="space-y-2">
                  <Label>Cor principal</Label>
                  <div className="grid grid-cols-5 gap-2">
                    {["#7c3aed", "#2563eb", "#059669", "#d97706", "#dc2626"].map((color) => (
                      <div
                        key={color}
                        className="w-full aspect-square rounded-md cursor-pointer border-2 border-transparent hover:border-primary"
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                </div>
              </div>
              <Button onClick={handleSave}>Salvar alterações</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notificacoes">
          <Card>
            <CardHeader>
              <CardTitle>Notificações</CardTitle>
              <CardDescription>Configure como e quando você deseja receber notificações.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="email-notif">Notificações por email</Label>
                    <p className="text-sm text-muted-foreground">Receba atualizações importantes por email.</p>
                  </div>
                  <Switch id="email-notif" />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="push-notif">Notificações push</Label>
                    <p className="text-sm text-muted-foreground">
                      Receba notificações em tempo real no seu dispositivo.
                    </p>
                  </div>
                  <Switch id="push-notif" />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="reminder-notif">Lembretes de tarefas</Label>
                    <p className="text-sm text-muted-foreground">Receba lembretes para tarefas próximas do prazo.</p>
                  </div>
                  <Switch id="reminder-notif" />
                </div>
              </div>
              <Button onClick={handleSave}>Salvar alterações</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="som">
          <Card>
            <CardHeader>
              <CardTitle>Som</CardTitle>
              <CardDescription>Configure os sons e alertas do aplicativo.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="sound-effects">Efeitos sonoros</Label>
                    <p className="text-sm text-muted-foreground">Ative sons para ações e eventos no aplicativo.</p>
                  </div>
                  <Switch id="sound-effects" />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="completion-sound">Som de conclusão</Label>
                    <p className="text-sm text-muted-foreground">Toque um som quando uma tarefa for concluída.</p>
                  </div>
                  <Switch id="completion-sound" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="volume">Volume</Label>
                  <Input id="volume" type="range" min="0" max="100" />
                </div>
              </div>
              <Button onClick={handleSave}>Salvar alterações</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="privacidade">
          <Card>
            <CardHeader>
              <CardTitle>Privacidade</CardTitle>
              <CardDescription>Gerencie suas configurações de privacidade e segurança.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="data-collection">Coleta de dados</Label>
                    <p className="text-sm text-muted-foreground">
                      Permitir coleta de dados anônimos para melhorar o aplicativo.
                    </p>
                  </div>
                  <Switch id="data-collection" />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="two-factor">Autenticação de dois fatores</Label>
                    <p className="text-sm text-muted-foreground">Adicione uma camada extra de segurança à sua conta.</p>
                  </div>
                  <Switch id="two-factor" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Alterar senha</Label>
                  <Input id="password" type="password" placeholder="Nova senha" />
                  <Input id="confirm-password" type="password" placeholder="Confirmar nova senha" className="mt-2" />
                </div>
              </div>
              <Button onClick={handleSave}>Salvar alterações</Button>
            </CardContent>
          </Card>
        </TabsContent>

        {isAdmin && (
          <TabsContent value="admin">
            <Card>
              <CardHeader>
                <CardTitle>Administração</CardTitle>
                <CardDescription>Acesse as funcionalidades administrativas do sistema.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader className="p-4">
                      <CardTitle className="text-base flex items-center gap-2">
                        <Quote className="h-5 w-5" />
                        Frases Motivacionais
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-4 pt-0">
                      <p className="text-sm text-muted-foreground mb-4">
                        Gerencie as frases motivacionais exibidas na tela inicial.
                      </p>
                      <Button asChild>
                        <Link href="/dashboard/configuracoes/frases-motivacionais">Gerenciar Frases</Link>
                      </Button>
                    </CardContent>
                  </Card>

                  {/* Outros cards de administração podem ser adicionados aqui */}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>
    </div>
  )
}
