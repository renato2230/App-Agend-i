"use client"

import { useState, useEffect } from "react"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"
import { useAuth } from "@/context/auth-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/components/ui/use-toast"
import { Pencil, Trash2, Plus, Quote } from "lucide-react"
import { Skeleton } from "@/components/ui/skeleton"

interface MotivationalQuote {
  id: string
  quote: string
  author: string | null
  category: string | null
  is_active: boolean
}

export default function MotivationalQuotesPage() {
  const [quotes, setQuotes] = useState<MotivationalQuote[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [editingQuote, setEditingQuote] = useState<MotivationalQuote | null>(null)
  const [newQuote, setNewQuote] = useState({
    quote: "",
    author: "",
    category: "",
    is_active: true,
  })
  const [isAdding, setIsAdding] = useState(false)
  const supabase = createClientComponentClient()
  const { user, isAdmin } = useAuth()
  const { toast } = useToast()

  useEffect(() => {
    const fetchQuotes = async () => {
      try {
        setIsLoading(true)
        const { data, error } = await supabase
          .from("motivational_quotes")
          .select("*")
          .order("created_at", { ascending: false })

        if (error) {
          throw error
        }

        setQuotes(data || [])
      } catch (error) {
        console.error("Erro ao buscar frases motivacionais:", error)
        toast({
          title: "Erro",
          description: "Não foi possível carregar as frases motivacionais.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchQuotes()
  }, [supabase, toast])

  const handleAddQuote = async () => {
    try {
      if (!newQuote.quote.trim()) {
        toast({
          title: "Erro",
          description: "A frase não pode estar vazia.",
          variant: "destructive",
        })
        return
      }

      const { data, error } = await supabase
        .from("motivational_quotes")
        .insert({
          quote: newQuote.quote,
          author: newQuote.author || null,
          category: newQuote.category || null,
          is_active: newQuote.is_active,
        })
        .select()

      if (error) {
        throw error
      }

      setQuotes([...(data || []), ...quotes])
      setNewQuote({
        quote: "",
        author: "",
        category: "",
        is_active: true,
      })
      setIsAdding(false)
      toast({
        title: "Sucesso",
        description: "Frase motivacional adicionada com sucesso.",
      })
    } catch (error) {
      console.error("Erro ao adicionar frase motivacional:", error)
      toast({
        title: "Erro",
        description: "Não foi possível adicionar a frase motivacional.",
        variant: "destructive",
      })
    }
  }

  const handleUpdateQuote = async () => {
    try {
      if (!editingQuote || !editingQuote.quote.trim()) {
        toast({
          title: "Erro",
          description: "A frase não pode estar vazia.",
          variant: "destructive",
        })
        return
      }

      const { data, error } = await supabase
        .from("motivational_quotes")
        .update({
          quote: editingQuote.quote,
          author: editingQuote.author,
          category: editingQuote.category,
          is_active: editingQuote.is_active,
        })
        .eq("id", editingQuote.id)
        .select()

      if (error) {
        throw error
      }

      setQuotes(quotes.map((q) => (q.id === editingQuote.id ? editingQuote : q)))
      setEditingQuote(null)
      toast({
        title: "Sucesso",
        description: "Frase motivacional atualizada com sucesso.",
      })
    } catch (error) {
      console.error("Erro ao atualizar frase motivacional:", error)
      toast({
        title: "Erro",
        description: "Não foi possível atualizar a frase motivacional.",
        variant: "destructive",
      })
    }
  }

  const handleDeleteQuote = async (id: string) => {
    try {
      const { error } = await supabase.from("motivational_quotes").delete().eq("id", id)

      if (error) {
        throw error
      }

      setQuotes(quotes.filter((q) => q.id !== id))
      toast({
        title: "Sucesso",
        description: "Frase motivacional excluída com sucesso.",
      })
    } catch (error) {
      console.error("Erro ao excluir frase motivacional:", error)
      toast({
        title: "Erro",
        description: "Não foi possível excluir a frase motivacional.",
        variant: "destructive",
      })
    }
  }

  const handleToggleActive = async (id: string, isActive: boolean) => {
    try {
      const { error } = await supabase.from("motivational_quotes").update({ is_active: isActive }).eq("id", id)

      if (error) {
        throw error
      }

      setQuotes(quotes.map((q) => (q.id === id ? { ...q, is_active: isActive } : q)))
      toast({
        title: "Sucesso",
        description: `Frase motivacional ${isActive ? "ativada" : "desativada"} com sucesso.`,
      })
    } catch (error) {
      console.error("Erro ao atualizar status da frase motivacional:", error)
      toast({
        title: "Erro",
        description: "Não foi possível atualizar o status da frase motivacional.",
        variant: "destructive",
      })
    }
  }

  if (!isAdmin) {
    return (
      <div className="container mx-auto py-6">
        <h1 className="text-2xl font-bold mb-6">Frases Motivacionais</h1>
        <p>Você não tem permissão para acessar esta página.</p>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Frases Motivacionais</h1>
        <Button onClick={() => setIsAdding(true)} disabled={isAdding}>
          <Plus className="h-4 w-4 mr-2" />
          Nova Frase
        </Button>
      </div>

      {isAdding && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Adicionar Nova Frase</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label htmlFor="new-quote">Frase</Label>
                <Textarea
                  id="new-quote"
                  value={newQuote.quote}
                  onChange={(e) => setNewQuote({ ...newQuote, quote: e.target.value })}
                  placeholder="Digite a frase motivacional"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="new-author">Autor</Label>
                <Input
                  id="new-author"
                  value={newQuote.author}
                  onChange={(e) => setNewQuote({ ...newQuote, author: e.target.value })}
                  placeholder="Nome do autor (opcional)"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="new-category">Categoria</Label>
                <Input
                  id="new-category"
                  value={newQuote.category}
                  onChange={(e) => setNewQuote({ ...newQuote, category: e.target.value })}
                  placeholder="Categoria (opcional)"
                  className="mt-1"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="new-active"
                  checked={newQuote.is_active}
                  onCheckedChange={(checked) => setNewQuote({ ...newQuote, is_active: checked })}
                />
                <Label htmlFor="new-active">Ativa</Label>
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsAdding(false)}>
                  Cancelar
                </Button>
                <Button onClick={handleAddQuote}>Adicionar</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {isLoading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="space-y-2">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                  <div className="flex justify-between items-center mt-4">
                    <Skeleton className="h-3 w-1/4" />
                    <div className="flex space-x-2">
                      <Skeleton className="h-8 w-8 rounded-md" />
                      <Skeleton className="h-8 w-8 rounded-md" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="space-y-4">
          {quotes.length === 0 ? (
            <Card>
              <CardContent className="p-6 text-center">
                <Quote className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
                <p>Nenhuma frase motivacional encontrada.</p>
                <Button className="mt-4" onClick={() => setIsAdding(true)}>
                  Adicionar Primeira Frase
                </Button>
              </CardContent>
            </Card>
          ) : (
            quotes.map((quote) => (
              <Card key={quote.id} className={!quote.is_active ? "opacity-60" : undefined}>
                <CardContent className="p-6">
                  {editingQuote?.id === quote.id ? (
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor={`edit-quote-${quote.id}`}>Frase</Label>
                        <Textarea
                          id={`edit-quote-${quote.id}`}
                          value={editingQuote.quote}
                          onChange={(e) => setEditingQuote({ ...editingQuote, quote: e.target.value })}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor={`edit-author-${quote.id}`}>Autor</Label>
                        <Input
                          id={`edit-author-${quote.id}`}
                          value={editingQuote.author || ""}
                          onChange={(e) => setEditingQuote({ ...editingQuote, author: e.target.value })}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor={`edit-category-${quote.id}`}>Categoria</Label>
                        <Input
                          id={`edit-category-${quote.id}`}
                          value={editingQuote.category || ""}
                          onChange={(e) => setEditingQuote({ ...editingQuote, category: e.target.value })}
                          className="mt-1"
                        />
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch
                          id={`edit-active-${quote.id}`}
                          checked={editingQuote.is_active}
                          onCheckedChange={(checked) => setEditingQuote({ ...editingQuote, is_active: checked })}
                        />
                        <Label htmlFor={`edit-active-${quote.id}`}>Ativa</Label>
                      </div>
                      <div className="flex justify-end space-x-2">
                        <Button variant="outline" onClick={() => setEditingQuote(null)}>
                          Cancelar
                        </Button>
                        <Button onClick={handleUpdateQuote}>Salvar</Button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <p className="text-base font-medium">{quote.quote}</p>
                      <div className="flex justify-between items-center mt-4">
                        <div>
                          {quote.author && <p className="text-sm text-muted-foreground">— {quote.author}</p>}
                          {quote.category && (
                            <p className="text-xs text-muted-foreground mt-1">Categoria: {quote.category}</p>
                          )}
                        </div>
                        <div className="flex items-center space-x-3">
                          <div className="flex items-center space-x-2">
                            <Switch
                              id={`active-${quote.id}`}
                              checked={quote.is_active}
                              onCheckedChange={(checked) => handleToggleActive(quote.id, checked)}
                            />
                            <Label htmlFor={`active-${quote.id}`} className="text-xs">
                              {quote.is_active ? "Ativa" : "Inativa"}
                            </Label>
                          </div>
                          <Button variant="ghost" size="icon" onClick={() => setEditingQuote(quote)}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => handleDeleteQuote(quote.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </div>
      )}
    </div>
  )
}
