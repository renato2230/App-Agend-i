"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Mascot, type MascotMood } from "@/components/mascot/mascot"
import { useMascotContext } from "@/context/mascot-context"

export default function MascotSettingsPage() {
  const [selectedMood, setSelectedMood] = useState<MascotMood>("idle")
  const [customMessage, setCustomMessage] = useState("Olá! Eu sou o Dêi!")
  const mascotContext = useMascotContext()

  const moods: { value: MascotMood; label: string }[] = [
    { value: "idle", label: "Normal" },
    { value: "happy", label: "Feliz" },
    { value: "thinking", label: "Pensativo" },
    { value: "celebrating", label: "Comemorando" },
    { value: "sleeping", label: "Dormindo" },
    { value: "waving", label: "Acenando" },
  ]

  const sequences = [
    { name: "Boas-vindas", action: () => mascotContext.playWelcomeSequence() },
    { name: "Celebração", action: () => mascotContext.playCelebrationSequence("uma conquista") },
    {
      name: "Transição Personalizada",
      action: () =>
        mascotContext.transitionMoods([
          { mood: "thinking", message: "Hmm, deixe-me pensar...", duration: 2000 },
          { mood: "happy", message: "Tive uma ideia!", duration: 1500 },
          { mood: "celebrating", message: "Vamos implementar isso agora!", duration: 2000 },
          { mood: "idle", message: "Pronto para começar!" },
        ]),
    },
    {
      name: "Ciclo de Humores",
      action: () =>
        mascotContext.transitionMoods(
          moods.map((mood) => ({
            mood: mood.value,
            message: `Este é o humor "${mood.label}"`,
            duration: 1500,
          })),
        ),
    },
  ]

  return (
    <div className="container mx-auto py-6 space-y-6">
      <h1 className="text-3xl font-bold">Configurações do Mascote</h1>

      <Tabs defaultValue="preview">
        <TabsList className="mb-4">
          <TabsTrigger value="preview">Visualização</TabsTrigger>
          <TabsTrigger value="sequences">Sequências</TabsTrigger>
          <TabsTrigger value="settings">Configurações</TabsTrigger>
        </TabsList>

        <TabsContent value="preview" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Visualização do Mascote</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col items-center space-y-6">
              <div className="h-40 flex items-center justify-center">
                <Mascot mood={selectedMood} message={customMessage} size="lg" />
              </div>

              <div className="grid grid-cols-3 gap-2 w-full max-w-md">
                {moods.map((mood) => (
                  <Button
                    key={mood.value}
                    variant={selectedMood === mood.value ? "default" : "outline"}
                    onClick={() => setSelectedMood(mood.value)}
                    className="w-full"
                  >
                    {mood.label}
                  </Button>
                ))}
              </div>

              <div className="w-full max-w-md">
                <input
                  type="text"
                  value={customMessage}
                  onChange={(e) => setCustomMessage(e.target.value)}
                  className="w-full p-2 border rounded"
                  placeholder="Mensagem personalizada"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sequences" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Sequências de Animação</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-600 dark:text-gray-400">Teste as diferentes sequências de animação do mascote:</p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {sequences.map((sequence, index) => (
                  <Button key={index} onClick={sequence.action} variant="outline" className="h-auto py-4">
                    {sequence.name}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Configurações do Mascote</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span>Mostrar mascote</span>
                <Button variant="outline" onClick={() => mascotContext.toggleMascot()}>
                  {mascotContext.isVisible ? "Esconder" : "Mostrar"}
                </Button>
              </div>

              <div className="flex items-center justify-between">
                <span>Limpar fila de transições</span>
                <Button variant="outline" onClick={() => mascotContext.clearTransitionQueue()}>
                  Limpar
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
