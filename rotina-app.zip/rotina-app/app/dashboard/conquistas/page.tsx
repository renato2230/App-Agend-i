"use client"

import type React from "react"

import { useLocalStorage } from "@/hooks/use-local-storage"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Award, Calendar, Clock, FlameIcon as Fire, Star, Trophy, CheckCircle2 } from "lucide-react"
import { useEffect, useState } from "react"

interface Achievement {
  id: string
  title: string
  description: string
  icon: React.ElementType
  progress: number
  maxProgress: number
  unlocked: boolean
  color: string
}

export default function ConquistasPage() {
  const [achievements, setAchievements] = useLocalStorage<Achievement[]>("achievements", [
    {
      id: "first-routine",
      title: "Primeira Rotina",
      description: "Crie sua primeira rotina",
      icon: Star,
      progress: 1,
      maxProgress: 1,
      unlocked: true,
      color: "text-yellow-500",
    },
    {
      id: "streak-3",
      title: "Sequência Inicial",
      description: "Complete rotinas por 3 dias seguidos",
      icon: Fire,
      progress: 3,
      maxProgress: 3,
      unlocked: true,
      color: "text-orange-500",
    },
    {
      id: "streak-7",
      title: "Consistência",
      description: "Complete rotinas por 7 dias seguidos",
      icon: Fire,
      progress: 5,
      maxProgress: 7,
      unlocked: false,
      color: "text-orange-500",
    },
    {
      id: "streak-30",
      title: "Hábito Formado",
      description: "Complete rotinas por 30 dias seguidos",
      icon: Fire,
      progress: 5,
      maxProgress: 30,
      unlocked: false,
      color: "text-orange-500",
    },
    {
      id: "tasks-50",
      title: "Produtividade",
      description: "Complete 50 tarefas",
      icon: CheckCircle2,
      progress: 24,
      maxProgress: 50,
      unlocked: false,
      color: "text-green-500",
    },
    {
      id: "pomodoro-10",
      title: "Foco Total",
      description: "Complete 10 sessões de Pomodoro",
      icon: Clock,
      progress: 3,
      maxProgress: 10,
      unlocked: false,
      color: "text-blue-500",
    },
    {
      id: "categories-5",
      title: "Organizador",
      description: "Crie 5 categorias diferentes de rotinas",
      icon: Calendar,
      progress: 2,
      maxProgress: 5,
      unlocked: false,
      color: "text-purple-500",
    },
    {
      id: "master",
      title: "Mestre do Agendêi",
      description: "Desbloqueie todas as outras conquistas",
      icon: Trophy,
      progress: 2,
      maxProgress: 7,
      unlocked: false,
      color: "text-amber-500",
    },
  ])

  const [showConfetti, setShowConfetti] = useState(false)

  // Função para simular o desbloqueio de uma conquista
  const unlockAchievement = (id: string) => {
    setAchievements(
      achievements.map((achievement) =>
        achievement.id === id ? { ...achievement, unlocked: true, progress: achievement.maxProgress } : achievement,
      ),
    )
    setShowConfetti(true)
    setTimeout(() => setShowConfetti(false), 3000)
  }

  // Criar confetti
  useEffect(() => {
    if (!showConfetti) return

    const confettiContainer = document.getElementById("confetti-container")
    if (!confettiContainer) return

    for (let i = 0; i < 50; i++) {
      const confetti = document.createElement("div")
      confetti.className = "confetti confetti-animation"
      confetti.style.left = `${Math.random() * 100}%`
      confetti.style.backgroundColor = `hsl(${Math.random() * 360}, 70%, 60%)`
      confetti.style.animationDelay = `${Math.random() * 2}s`
      confettiContainer.appendChild(confetti)

      setTimeout(() => {
        confetti.remove()
      }, 3000)
    }
  }, [showConfetti])

  return (
    <div className="space-y-6 relative">
      <div id="confetti-container" className="absolute inset-0 overflow-hidden pointer-events-none" />

      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Conquistas</h1>
        <div className="flex items-center gap-2">
          <Trophy className="h-5 w-5 text-amber-500" />
          <span className="font-bold">
            {achievements.filter((a) => a.unlocked).length}/{achievements.length} Desbloqueadas
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {achievements.map((achievement) => (
          <Card
            key={achievement.id}
            className={`transition-all duration-300 ${
              achievement.unlocked ? "border-2 border-primary" : "opacity-75 hover:opacity-100"
            }`}
            onClick={() => !achievement.unlocked && Math.random() > 0.7 && unlockAchievement(achievement.id)}
          >
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div className={`p-2 rounded-full ${achievement.unlocked ? "bg-primary/20" : "bg-muted"}`}>
                  <achievement.icon
                    className={`h-6 w-6 ${achievement.unlocked ? achievement.color : "text-muted-foreground"}`}
                  />
                </div>
                {achievement.unlocked && <Award className="h-5 w-5 text-primary" />}
              </div>
              <CardTitle className="mt-2">{achievement.title}</CardTitle>
              <CardDescription>{achievement.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Progresso</span>
                  <span className="font-medium">
                    {achievement.progress}/{achievement.maxProgress}
                  </span>
                </div>
                <Progress value={(achievement.progress / achievement.maxProgress) * 100} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
