"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CalendarIcon, Search, CheckCircle, XCircle } from "lucide-react"
import { useSupabaseData } from "@/hooks/use-supabase-data"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"

export default function HistoricoPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState("todos")
  const [filterCategory, setFilterCategory] = useState("todas")
  const [filterPeriod, setFilterPeriod] = useState("todos")

  const { data: tasks } = useSupabaseData("tasks", [])
  const { data: routines } = useSupabaseData("routines", [])

  // Função para filtrar tarefas
  const filteredTasks = tasks.filter((task) => {
    const matchesSearch = task.name?.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus =
      filterStatus === "todos" ||
      (filterStatus === "concluidas" && task.completed) ||
      (filterStatus === "pendentes" && !task.completed)

    // Encontrar a rotina associada à tarefa
    const routine = routines.find((r) => r.id === task.routine_id)
    const matchesCategory = filterCategory === "todas" || (routine && routine.category === filterCategory)

    // Filtrar por período
    const taskDate = new Date(task.created_at)
    const now = new Date()
    let matchesPeriod = true

    if (filterPeriod === "hoje") {
      matchesPeriod = taskDate.toDateString() === now.toDateString()
    } else if (filterPeriod === "semana") {
      const oneWeekAgo = new Date()
      oneWeekAgo.setDate(now.getDate() - 7)
      matchesPeriod = taskDate >= oneWeekAgo
    } else if (filterPeriod === "mes") {
      const oneMonthAgo = new Date()
      oneMonthAgo.setMonth(now.getMonth() - 1)
      matchesPeriod = taskDate >= oneMonthAgo
    }

    return matchesSearch && matchesStatus && matchesCategory && matchesPeriod
  })

  // Ordenar tarefas por data (mais recentes primeiro)
  const sortedTasks = [...filteredTasks].sort((a, b) => {
    return new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
  })

  // Agrupar tarefas por data
  const groupTasksByDate = () => {
    const groups: Record<string, typeof tasks> = {}

    sortedTasks.forEach((task) => {
      const date = new Date(task.created_at).toDateString()
      if (!groups[date]) {
        groups[date] = []
      }
      groups[date].push(task)
    })

    return groups
  }

  const taskGroups = groupTasksByDate()

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-2xl font-bold">Histórico de Atividades</h1>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Filtros</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar tarefas..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger>
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos os Status</SelectItem>
                <SelectItem value="concluidas">Concluídas</SelectItem>
                <SelectItem value="pendentes">Pendentes</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Categoria" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todas as Categorias</SelectItem>
                <SelectItem value="Trabalho">Trabalho</SelectItem>
                <SelectItem value="Estudo">Estudo</SelectItem>
                <SelectItem value="Saúde">Saúde</SelectItem>
                <SelectItem value="Lazer">Lazer</SelectItem>
                <SelectItem value="Família">Família</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterPeriod} onValueChange={setFilterPeriod}>
              <SelectTrigger>
                <SelectValue placeholder="Período" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todo o Período</SelectItem>
                <SelectItem value="hoje">Hoje</SelectItem>
                <SelectItem value="semana">Última Semana</SelectItem>
                <SelectItem value="mes">Último Mês</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-6">
        {Object.keys(taskGroups).length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-8">
              <div className="rounded-full bg-muted p-3">
                <CalendarIcon className="h-6 w-6 text-muted-foreground" />
              </div>
              <h3 className="mt-4 text-lg font-medium">Nenhuma atividade encontrada</h3>
              <p className="mt-2 text-sm text-muted-foreground text-center">
                Não foram encontradas atividades com os filtros selecionados.
                <br />
                Tente ajustar os filtros ou criar novas tarefas.
              </p>
            </CardContent>
          </Card>
        ) : (
          Object.entries(taskGroups).map(([date, tasks]) => (
            <Card key={date}>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">
                  {format(new Date(date), "EEEE, d 'de' MMMM 'de' yyyy", { locale: ptBR })}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {tasks.map((task) => {
                    const routine = routines.find((r) => r.id === task.routine_id)

                    return (
                      <div key={task.id} className="flex items-start gap-4 p-3 rounded-lg bg-muted/50">
                        <div
                          className={`mt-0.5 rounded-full p-1 ${
                            task.completed
                              ? "bg-green-100 text-green-600 dark:bg-green-900/20 dark:text-green-400"
                              : "bg-amber-100 text-amber-600 dark:bg-amber-900/20 dark:text-amber-400"
                          }`}
                        >
                          {task.completed ? <CheckCircle className="h-5 w-5" /> : <XCircle className="h-5 w-5" />}
                        </div>

                        <div className="flex-1">
                          <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
                            <h3 className="font-medium">{task.name}</h3>
                            <div className="flex flex-wrap gap-2">
                              {routine && <Badge variant="outline">{routine.name}</Badge>}
                              {routine && <Badge variant="secondary">{routine.category}</Badge>}
                              {task.priority && (
                                <Badge
                                  className={
                                    task.priority === "Alta"
                                      ? "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400"
                                      : task.priority === "Média"
                                        ? "bg-amber-100 text-amber-800 dark:bg-amber-900/20 dark:text-amber-400"
                                        : "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400"
                                  }
                                >
                                  {task.priority}
                                </Badge>
                              )}
                            </div>
                          </div>

                          <div className="mt-1 text-sm text-muted-foreground">
                            {task.duration && `Duração: ${task.duration} minutos`}
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}
