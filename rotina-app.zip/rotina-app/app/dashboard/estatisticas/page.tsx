"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { BarChart, LineChart, PieChart, Calendar, Clock, CheckCircle, ListChecks } from "lucide-react"
import { useSupabaseData } from "@/hooks/use-supabase-data"
import { useAuth } from "@/context/auth-context"

export default function EstatisticasPage() {
  const [period, setPeriod] = useState("semana")
  const { isTestUser } = useAuth()
  const { data: routines } = useSupabaseData("routines", [])
  const { data: tasks } = useSupabaseData("tasks", [])
  const { data: stats } = useSupabaseData("stats", [])

  // Dados de exemplo para os gráficos
  const productivityData = [
    { day: "Seg", completed: 8, total: 10 },
    { day: "Ter", completed: 6, total: 8 },
    { day: "Qua", completed: 9, total: 12 },
    { day: "Qui", completed: 7, total: 9 },
    { day: "Sex", completed: 5, total: 7 },
    { day: "Sáb", completed: 3, total: 4 },
    { day: "Dom", completed: 2, total: 3 },
  ]

  const categoryData = [
    { category: "Trabalho", count: 12 },
    { category: "Estudo", count: 8 },
    { category: "Saúde", count: 6 },
    { category: "Lazer", count: 4 },
    { category: "Família", count: 5 },
  ]

  const timeOfDayData = [
    { hour: "6-9", count: 5 },
    { hour: "9-12", count: 12 },
    { hour: "12-15", count: 8 },
    { hour: "15-18", count: 10 },
    { hour: "18-21", count: 7 },
    { hour: "21-24", count: 3 },
  ]

  // Calcular estatísticas
  const completedTasks = tasks.filter((task) => task.completed).length
  const totalTasks = tasks.length
  const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0

  // Renderizar gráfico de barras para produtividade
  const renderProductivityChart = () => {
    const maxValue = Math.max(...productivityData.map((d) => d.total))

    return (
      <div className="h-64 flex items-end space-x-2">
        {productivityData.map((data, index) => (
          <div key={index} className="flex-1 flex flex-col items-center">
            <div className="w-full flex flex-col items-center space-y-1">
              <div className="w-full bg-muted rounded-t-sm" style={{ height: `${(data.total / maxValue) * 180}px` }}>
                <div
                  className="bg-primary rounded-t-sm"
                  style={{ height: `${(data.completed / data.total) * 100}%` }}
                ></div>
              </div>
            </div>
            <div className="text-xs mt-2">{data.day}</div>
            <div className="text-xs text-muted-foreground">
              {data.completed}/{data.total}
            </div>
          </div>
        ))}
      </div>
    )
  }

  // Renderizar gráfico de pizza para categorias
  const renderCategoryChart = () => {
    const total = categoryData.reduce((sum, item) => sum + item.count, 0)
    let cumulativePercentage = 0

    const colors = ["bg-primary", "bg-blue-500", "bg-amber-500", "bg-purple-500", "bg-green-500"]

    return (
      <div className="flex flex-col md:flex-row items-center gap-8">
        <div className="relative w-48 h-48">
          <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
            {categoryData.map((item, index) => {
              const percentage = (item.count / total) * 100
              const startAngle = cumulativePercentage
              cumulativePercentage += percentage

              // Calcular coordenadas para o arco SVG
              const x1 = 50 + 40 * Math.cos((startAngle / 100) * 2 * Math.PI)
              const y1 = 50 + 40 * Math.sin((startAngle / 100) * 2 * Math.PI)
              const x2 = 50 + 40 * Math.cos((cumulativePercentage / 100) * 2 * Math.PI)
              const y2 = 50 + 40 * Math.sin((cumulativePercentage / 100) * 2 * Math.PI)

              const largeArcFlag = percentage > 50 ? 1 : 0

              return (
                <path
                  key={index}
                  d={`M 50 50 L ${x1} ${y1} A 40 40 0 ${largeArcFlag} 1 ${x2} ${y2} Z`}
                  className={colors[index % colors.length]}
                  stroke="white"
                  strokeWidth="1"
                />
              )
            })}
          </svg>
        </div>

        <div className="space-y-2">
          {categoryData.map((item, index) => (
            <div key={index} className="flex items-center gap-2">
              <div className={`w-4 h-4 ${colors[index % colors.length]}`}></div>
              <div className="text-sm">{item.category}</div>
              <div className="text-sm text-muted-foreground">
                {item.count} ({Math.round((item.count / total) * 100)}%)
              </div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  // Renderizar gráfico de linha para horários
  const renderTimeOfDayChart = () => {
    const maxValue = Math.max(...timeOfDayData.map((d) => d.count))
    const points = timeOfDayData
      .map((data, index) => {
        const x = (index / (timeOfDayData.length - 1)) * 100
        const y = 100 - (data.count / maxValue) * 100
        return `${x},${y}`
      })
      .join(" ")

    return (
      <div className="h-64 relative">
        <svg viewBox="0 0 100 100" className="w-full h-full" preserveAspectRatio="none">
          <polyline
            points={points}
            fill="none"
            stroke="hsl(var(--primary))"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {timeOfDayData.map((data, index) => {
            const x = (index / (timeOfDayData.length - 1)) * 100
            const y = 100 - (data.count / maxValue) * 100
            return <circle key={index} cx={x} cy={y} r="2" className="fill-primary" />
          })}
        </svg>

        <div className="flex justify-between mt-2">
          {timeOfDayData.map((data, index) => (
            <div key={index} className="text-xs text-muted-foreground">
              {data.hour}
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-2xl font-bold">Estatísticas</h1>

        <Select value={period} onValueChange={setPeriod}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Período" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="semana">Última Semana</SelectItem>
            <SelectItem value="mes">Último Mês</SelectItem>
            <SelectItem value="trimestre">Último Trimestre</SelectItem>
            <SelectItem value="ano">Último Ano</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium">Taxa de Conclusão</CardTitle>
              <CheckCircle className="h-4 w-4 text-muted-foreground" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{completionRate}%</div>
            <p className="text-xs text-muted-foreground">
              {completedTasks} de {totalTasks} tarefas concluídas
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium">Rotinas Ativas</CardTitle>
              <ListChecks className="h-4 w-4 text-muted-foreground" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{routines.length}</div>
            <p className="text-xs text-muted-foreground">
              {routines.filter((r) => r.frequency === "Diária").length} rotinas diárias
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium">Sequência Atual</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.length > 0 ? stats[0].dias_consecutivos : 0} dias</div>
            <p className="text-xs text-muted-foreground">
              Seu recorde: {stats.length > 0 ? Math.max(stats[0].dias_consecutivos, 7) : 0} dias
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium">Tempo Médio</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {tasks.length > 0
                ? Math.round(tasks.reduce((sum, task) => sum + (task.duration || 0), 0) / tasks.length)
                : 0}{" "}
              min
            </div>
            <p className="text-xs text-muted-foreground">Por tarefa concluída</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="produtividade">
        <TabsList>
          <TabsTrigger value="produtividade" className="flex items-center gap-2">
            <BarChart className="h-4 w-4" />
            <span>Produtividade</span>
          </TabsTrigger>
          <TabsTrigger value="categorias" className="flex items-center gap-2">
            <PieChart className="h-4 w-4" />
            <span>Categorias</span>
          </TabsTrigger>
          <TabsTrigger value="horarios" className="flex items-center gap-2">
            <LineChart className="h-4 w-4" />
            <span>Horários</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="produtividade">
          <Card>
            <CardHeader>
              <CardTitle>Produtividade Diária</CardTitle>
            </CardHeader>
            <CardContent>{renderProductivityChart()}</CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="categorias">
          <Card>
            <CardHeader>
              <CardTitle>Distribuição por Categoria</CardTitle>
            </CardHeader>
            <CardContent>{renderCategoryChart()}</CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="horarios">
          <Card>
            <CardHeader>
              <CardTitle>Atividade por Horário</CardTitle>
            </CardHeader>
            <CardContent>{renderTimeOfDayChart()}</CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
