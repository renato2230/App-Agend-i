"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ChevronLeft, ChevronRight, Plus } from "lucide-react"
import { useSupabaseData } from "@/hooks/use-supabase-data"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import RoutineForm from "@/components/routine-form"

export default function CalendarioPage() {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [currentView, setCurrentView] = useState<"month" | "week" | "day">("month")
  const { data: routines } = useSupabaseData("routines", [])
  const { data: tasks } = useSupabaseData("tasks", [])

  // Funções para navegação no calendário
  const goToPreviousPeriod = () => {
    const newDate = new Date(currentDate)
    if (currentView === "month") {
      newDate.setMonth(newDate.getMonth() - 1)
    } else if (currentView === "week") {
      newDate.setDate(newDate.getDate() - 7)
    } else {
      newDate.setDate(newDate.getDate() - 1)
    }
    setCurrentDate(newDate)
  }

  const goToNextPeriod = () => {
    const newDate = new Date(currentDate)
    if (currentView === "month") {
      newDate.setMonth(newDate.getMonth() + 1)
    } else if (currentView === "week") {
      newDate.setDate(newDate.getDate() + 7)
    } else {
      newDate.setDate(newDate.getDate() + 1)
    }
    setCurrentDate(newDate)
  }

  const goToToday = () => {
    setCurrentDate(new Date())
  }

  // Função para gerar os dias do mês atual
  const getDaysInMonth = () => {
    const year = currentDate.getFullYear()
    const month = currentDate.getMonth()

    const firstDayOfMonth = new Date(year, month, 1)
    const lastDayOfMonth = new Date(year, month + 1, 0)

    const daysInMonth = lastDayOfMonth.getDate()
    const firstDayOfWeek = firstDayOfMonth.getDay() // 0 = Domingo, 1 = Segunda, etc.

    const days = []

    // Adicionar dias do mês anterior para completar a primeira semana
    for (let i = 0; i < firstDayOfWeek; i++) {
      const day = new Date(year, month, -firstDayOfWeek + i + 1)
      days.push({
        date: day,
        isCurrentMonth: false,
        hasEvents: false,
      })
    }

    // Adicionar dias do mês atual
    for (let i = 1; i <= daysInMonth; i++) {
      const day = new Date(year, month, i)

      // Verificar se há eventos neste dia
      const hasEvents = tasks.some((task) => {
        const taskDate = new Date(task.created_at)
        return taskDate.getDate() === i && taskDate.getMonth() === month && taskDate.getFullYear() === year
      })

      days.push({
        date: day,
        isCurrentMonth: true,
        hasEvents,
      })
    }

    // Adicionar dias do próximo mês para completar a última semana
    const lastDay = new Date(year, month, daysInMonth)
    const lastDayOfWeek = lastDay.getDay()
    const remainingDays = 6 - lastDayOfWeek

    for (let i = 1; i <= remainingDays; i++) {
      const day = new Date(year, month + 1, i)
      days.push({
        date: day,
        isCurrentMonth: false,
        hasEvents: false,
      })
    }

    return days
  }

  // Função para formatar o título do período atual
  const formatPeriodTitle = () => {
    const options: Intl.DateTimeFormatOptions = {}

    if (currentView === "month") {
      options.month = "long"
      options.year = "numeric"
    } else if (currentView === "week") {
      const startOfWeek = new Date(currentDate)
      const dayOfWeek = currentDate.getDay()
      startOfWeek.setDate(currentDate.getDate() - dayOfWeek)

      const endOfWeek = new Date(startOfWeek)
      endOfWeek.setDate(startOfWeek.getDate() + 6)

      return `${startOfWeek.getDate()} - ${endOfWeek.getDate()} de ${endOfWeek.toLocaleString("default", { month: "long" })} de ${endOfWeek.getFullYear()}`
    } else {
      options.weekday = "long"
      options.day = "numeric"
      options.month = "long"
    }

    return currentDate.toLocaleString("pt-BR", options)
  }

  // Renderizar o calendário de acordo com a visualização atual
  const renderCalendar = () => {
    if (currentView === "month") {
      const days = getDaysInMonth()

      return (
        <div className="grid grid-cols-7 gap-1">
          {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"].map((day) => (
            <div key={day} className="text-center py-2 text-sm font-medium text-muted-foreground">
              {day}
            </div>
          ))}

          {days.map((day, index) => {
            const isToday = day.date.toDateString() === new Date().toDateString()

            return (
              <div
                key={index}
                className={`min-h-[100px] p-2 border rounded-md ${
                  day.isCurrentMonth ? "bg-card" : "bg-muted/50 text-muted-foreground"
                } ${isToday ? "border-primary" : "border-border"}`}
              >
                <div className="flex justify-between items-start">
                  <span className={`text-sm font-medium ${isToday ? "text-primary" : ""}`}>{day.date.getDate()}</span>
                  {day.hasEvents && <div className="h-2 w-2 rounded-full bg-primary"></div>}
                </div>

                {day.hasEvents && day.isCurrentMonth && (
                  <div className="mt-2">
                    {tasks
                      .filter((task) => {
                        const taskDate = new Date(task.created_at)
                        return (
                          taskDate.getDate() === day.date.getDate() &&
                          taskDate.getMonth() === day.date.getMonth() &&
                          taskDate.getFullYear() === day.date.getFullYear()
                        )
                      })
                      .slice(0, 2)
                      .map((task) => {
                        const routine = routines.find((r) => r.id === task.routine_id)

                        return (
                          <div key={task.id} className="text-xs p-1 mb-1 rounded bg-primary/10 truncate">
                            {task.name}
                            {routine && (
                              <Badge variant="outline" className="ml-1 text-[10px] py-0 h-4">
                                {routine.name}
                              </Badge>
                            )}
                          </div>
                        )
                      })}

                    {tasks.filter((task) => {
                      const taskDate = new Date(task.created_at)
                      return (
                        taskDate.getDate() === day.date.getDate() &&
                        taskDate.getMonth() === day.date.getMonth() &&
                        taskDate.getFullYear() === day.date.getFullYear()
                      )
                    }).length > 2 && (
                      <div className="text-xs text-muted-foreground">
                        +{" "}
                        {tasks.filter((task) => {
                          const taskDate = new Date(task.created_at)
                          return (
                            taskDate.getDate() === day.date.getDate() &&
                            taskDate.getMonth() === day.date.getMonth() &&
                            taskDate.getFullYear() === day.date.getFullYear()
                          )
                        }).length - 2}{" "}
                        mais
                      </div>
                    )}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )
    } else if (currentView === "week") {
      // Implementação da visualização semanal
      return (
        <div className="space-y-4">
          <div className="grid grid-cols-7 gap-2">
            {Array.from({ length: 7 }).map((_, index) => {
              const day = new Date(currentDate)
              day.setDate(currentDate.getDate() - currentDate.getDay() + index)
              const isToday = day.toDateString() === new Date().toDateString()

              return (
                <div key={index} className="text-center">
                  <div className={`text-sm font-medium ${isToday ? "text-primary" : ""}`}>
                    {day.toLocaleString("pt-BR", { weekday: "short" })}
                  </div>
                  <div
                    className={`h-8 w-8 rounded-full flex items-center justify-center mx-auto ${
                      isToday ? "bg-primary text-primary-foreground" : ""
                    }`}
                  >
                    {day.getDate()}
                  </div>
                </div>
              )
            })}
          </div>

          <div className="space-y-2">
            {Array.from({ length: 10 }).map((_, hour) => {
              const displayHour = hour + 8 // Começando às 8h

              return (
                <div key={hour} className="grid grid-cols-[80px_1fr] gap-2">
                  <div className="text-right text-sm text-muted-foreground py-2">{displayHour}:00</div>
                  <div className="grid grid-cols-7 gap-2">
                    {Array.from({ length: 7 }).map((_, dayIndex) => (
                      <div key={dayIndex} className="h-12 border border-border rounded-md bg-card"></div>
                    ))}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )
    } else {
      // Implementação da visualização diária
      return (
        <div className="space-y-4">
          <div className="text-center">
            <div className="text-lg font-medium">{currentDate.toLocaleString("pt-BR", { weekday: "long" })}</div>
            <div className="h-12 w-12 rounded-full flex items-center justify-center mx-auto bg-primary text-primary-foreground">
              {currentDate.getDate()}
            </div>
          </div>

          <div className="space-y-2">
            {Array.from({ length: 14 }).map((_, hour) => {
              const displayHour = hour + 8 // Começando às 8h

              return (
                <div key={hour} className="grid grid-cols-[80px_1fr] gap-4">
                  <div className="text-right text-sm text-muted-foreground py-2">{displayHour}:00</div>
                  <div className="h-16 border border-border rounded-md bg-card p-2">
                    {/* Aqui entrariam os eventos do dia */}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-2xl font-bold">Calendário</h1>

        <div className="flex items-center gap-2">
          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Novo Evento
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Criar Novo Evento</DialogTitle>
              </DialogHeader>
              <RoutineForm />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div className="flex items-center gap-2">
              <Button variant="outline" size="icon" onClick={goToPreviousPeriod}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button variant="outline" onClick={goToToday}>
                Hoje
              </Button>
              <Button variant="outline" size="icon" onClick={goToNextPeriod}>
                <ChevronRight className="h-4 w-4" />
              </Button>
              <CardTitle>{formatPeriodTitle()}</CardTitle>
            </div>

            <Select value={currentView} onValueChange={(value: "month" | "week" | "day") => setCurrentView(value)}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Visualização" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="month">Mês</SelectItem>
                <SelectItem value="week">Semana</SelectItem>
                <SelectItem value="day">Dia</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>{renderCalendar()}</CardContent>
      </Card>
    </div>
  )
}
