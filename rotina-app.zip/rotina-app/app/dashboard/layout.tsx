import type React from "react"
import Sidebar from "@/components/sidebar"
import { createClient } from "@/lib/supabase/server"
import { cookies } from "next/headers"
import OnboardingWrapper from "@/components/onboarding-wrapper"

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  try {
    // Verificar se é o usuário de teste através de cookies
    const cookieStore = cookies()
    const testSession = cookieStore.get("test_session")
    const isTestUser = testSession?.value === "admin"

    if (isTestUser) {
      // Se for usuário de teste, renderizar normalmente
      return (
        <div className="flex min-h-screen">
          <Sidebar />
          <main className="flex-1 p-6 overflow-auto">
            <OnboardingWrapper isTestUser={true}>{children}</OnboardingWrapper>
          </main>
        </div>
      )
    }

    // Verificar autenticação no servidor
    const supabase = createClient()
    const {
      data: { session },
    } = await supabase.auth.getSession()

    // Se não houver sessão, renderizar uma interface simplificada em vez de redirecionar
    // Isso evita o erro de redirecionamento durante o preview
    if (!session) {
      return (
        <div className="flex min-h-screen">
          <main className="flex-1 p-6 overflow-auto">
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                <h1 className="text-2xl font-bold mb-4">Acesso Restrito</h1>
                <p className="mb-4">Você precisa estar logado para acessar esta página.</p>
                <a
                  href="/"
                  className="inline-flex items-center justify-center whitespace-nowrap rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
                >
                  Ir para o login
                </a>
              </div>
            </div>
          </main>
        </div>
      )
    }

    // Verificar se o usuário já completou o onboarding
    let onboardingCompleted = true
    try {
      const { data: profileData } = await supabase
        .from("profiles")
        .select("onboarding_completed")
        .eq("id", session.user.id)
        .single()

      onboardingCompleted = profileData?.onboarding_completed === true
    } catch (error) {
      console.error("Erro ao verificar status do onboarding:", error)
    }

    return (
      <div className="flex min-h-screen">
        <Sidebar />
        <main className="flex-1 p-6 overflow-auto">
          <OnboardingWrapper isTestUser={false} onboardingCompleted={onboardingCompleted}>
            {children}
          </OnboardingWrapper>
        </main>
      </div>
    )
  } catch (error) {
    console.error("Dashboard layout error:", error)
    // Em caso de erro, mostrar uma interface simplificada
    return (
      <div className="flex min-h-screen">
        <main className="flex-1 p-6 overflow-auto">
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <h1 className="text-2xl font-bold mb-4">Erro ao carregar o dashboard</h1>
              <p className="mb-4">Ocorreu um erro ao verificar sua autenticação.</p>
              <a
                href="/"
                className="inline-flex items-center justify-center whitespace-nowrap rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
              >
                Voltar para o login
              </a>
            </div>
          </div>
        </main>
      </div>
    )
  }
}
