"use client"

import { useEffect, useState } from "react"
import DashboardStats from "@/components/dashboard-stats"
import RoutinesList from "@/components/routines-list"
import UpcomingTasks from "@/components/upcoming-tasks"
import WelcomeMessage from "@/components/welcome-message"
import { MotivationalQuote } from "@/components/motivational-quote"
import { MascotTip } from "@/components/mascot/mascot-tip"
import { useMascotContext } from "@/context/mascot-context"

const MASCOT_TIPS = [
  "Organize suas tarefas por prioridade para maximizar sua produtividade!",
  "Lembre-se de fazer pausas regulares para manter seu foco e energia.",
  "Dividir grandes tarefas em partes menores torna-as mais gerenciáveis.",
  "Definir metas claras ajuda a manter o foco e a motivação.",
  "Não se esqueça de celebrar suas conquistas, mesmo as pequenas!",
]

export default function DashboardPage() {
  const [showTips, setShowTips] = useState(false)
  const { makeWaving, makeHappy } = useMascotContext()

  // Mostrar o mascote acenando quando a página carregar
  useEffect(() => {
    makeWaving("Bem-vindo de volta ao Agendêi!")

    // Após 3 segundos, mostrar as dicas
    const timer = setTimeout(() => {
      setShowTips(true)
      makeHappy()
    }, 3000)

    return () => clearTimeout(timer)
  }, [makeWaving, makeHappy])

  return (
    <div className="space-y-6">
      <WelcomeMessage />

      {showTips && <MascotTip tips={MASCOT_TIPS} onClose={() => setShowTips(false)} />}

      <MotivationalQuote />

      <DashboardStats />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-card rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold mb-4">Minhas Rotinas</h2>
          <RoutinesList />
        </div>

        <div className="bg-card rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold mb-4">Próximas Tarefas</h2>
          <UpcomingTasks />
        </div>
      </div>
    </div>
  )
}
