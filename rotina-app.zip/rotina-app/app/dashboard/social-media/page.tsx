"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/context/auth-context"
import {
  Search,
  Upload,
  ImageIcon,
  Video,
  Calendar,
  Instagram,
  Facebook,
  Twitter,
  Linkedin,
  Youtube,
  Edit,
  Trash2,
  Eye,
  Share2,
  Clock,
} from "lucide-react"

// Tipos para o conteúdo de mídia social
interface SocialMediaContent {
  id: string
  title: string
  description: string
  type: "image" | "video"
  platform: string
  status: "draft" | "scheduled" | "published"
  scheduledDate?: string
  mediaUrl?: string
  tags: string[]
  created_at: string
  updated_at: string
}

export default function SocialMediaPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState("all")
  const [filterPlatform, setFilterPlatform] = useState("all")
  const [filterStatus, setFilterStatus] = useState("all")
  const { isTestUser } = useAuth()

  // Dados de exemplo para conteúdo de mídia social
  const [socialMediaContent, setSocialMediaContent] = useState<SocialMediaContent[]>([
    {
      id: "1",
      title: "Lançamento do Novo Produto",
      description: "Estamos animados para anunciar o lançamento do nosso novo produto! #novidade #lançamento",
      type: "image",
      platform: "instagram",
      status: "published",
      mediaUrl: "/placeholder.svg?height=500&width=500",
      tags: ["novidade", "lançamento", "produto"],
      created_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
      updated_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: "2",
      title: "Dicas de Produtividade",
      description: "Confira nossas 5 dicas para aumentar sua produtividade diária! #produtividade #dicas #trabalho",
      type: "image",
      platform: "facebook",
      status: "scheduled",
      scheduledDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
      mediaUrl: "/placeholder.svg?height=500&width=500",
      tags: ["produtividade", "dicas", "trabalho"],
      created_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
      updated_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: "3",
      title: "Tutorial: Como Usar Nossa Plataforma",
      description: "Neste vídeo, mostramos como aproveitar ao máximo nossa plataforma. #tutorial #howto",
      type: "video",
      platform: "youtube",
      status: "draft",
      mediaUrl: "/placeholder.svg?height=500&width=500",
      tags: ["tutorial", "howto", "plataforma"],
      created_at: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
      updated_at: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    },
  ])

  // Estado para o formulário de upload
  const [uploadForm, setUploadForm] = useState({
    title: "",
    description: "",
    type: "image",
    platform: "instagram",
    status: "draft",
    scheduledDate: "",
    tags: "",
    file: null as File | null,
  })

  // Filtrar conteúdo
  const filteredContent = socialMediaContent.filter((content) => {
    const matchesSearch =
      content.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      content.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      content.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase()))

    const matchesType = filterType === "all" || content.type === filterType
    const matchesPlatform = filterPlatform === "all" || content.platform === filterPlatform
    const matchesStatus = filterStatus === "all" || content.status === filterStatus

    return matchesSearch && matchesType && matchesPlatform && matchesStatus
  })

  // Ordenar conteúdo por data (mais recentes primeiro)
  const sortedContent = [...filteredContent].sort((a, b) => {
    return new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()
  })

  // Função para lidar com o upload de arquivo
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setUploadForm({
        ...uploadForm,
        file: e.target.files[0],
      })
    }
  }

  // Função para lidar com mudanças no formulário
  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setUploadForm({
      ...uploadForm,
      [name]: value,
    })
  }

  // Função para lidar com mudanças em selects
  const handleSelectChange = (name: string, value: string) => {
    setUploadForm({
      ...uploadForm,
      [name]: value,
    })
  }

  // Função para adicionar novo conteúdo
  const handleAddContent = () => {
    const newContent: SocialMediaContent = {
      id: Date.now().toString(),
      title: uploadForm.title,
      description: uploadForm.description,
      type: uploadForm.type as "image" | "video",
      platform: uploadForm.platform,
      status: uploadForm.status as "draft" | "scheduled" | "published",
      scheduledDate: uploadForm.scheduledDate || undefined,
      mediaUrl: uploadForm.file ? URL.createObjectURL(uploadForm.file) : "/placeholder.svg?height=500&width=500",
      tags: uploadForm.tags.split(",").map((tag) => tag.trim()),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }

    setSocialMediaContent([...socialMediaContent, newContent])

    // Resetar formulário
    setUploadForm({
      title: "",
      description: "",
      type: "image",
      platform: "instagram",
      status: "draft",
      scheduledDate: "",
      tags: "",
      file: null,
    })
  }

  // Função para excluir conteúdo
  const handleDeleteContent = (id: string) => {
    setSocialMediaContent(socialMediaContent.filter((content) => content.id !== id))
  }

  // Renderizar ícone da plataforma
  const renderPlatformIcon = (platform: string) => {
    switch (platform) {
      case "instagram":
        return <Instagram className="h-4 w-4" />
      case "facebook":
        return <Facebook className="h-4 w-4" />
      case "twitter":
        return <Twitter className="h-4 w-4" />
      case "linkedin":
        return <Linkedin className="h-4 w-4" />
      case "youtube":
        return <Youtube className="h-4 w-4" />
      default:
        return <Share2 className="h-4 w-4" />
    }
  }

  // Renderizar ícone do tipo de conteúdo
  const renderTypeIcon = (type: string) => {
    switch (type) {
      case "image":
        return <ImageIcon className="h-4 w-4" />
      case "video":
        return <Video className="h-4 w-4" />
      default:
        return <ImageIcon className="h-4 w-4" />
    }
  }

  // Renderizar badge de status
  const renderStatusBadge = (status: string, scheduledDate?: string) => {
    switch (status) {
      case "draft":
        return (
          <Badge variant="outline" className="bg-muted">
            Rascunho
          </Badge>
        )
      case "scheduled":
        return (
          <Badge className="bg-amber-100 text-amber-800 dark:bg-amber-900/20 dark:text-amber-400">
            <Clock className="mr-1 h-3 w-3" />
            {scheduledDate && new Date(scheduledDate).toLocaleDateString("pt-BR")}
          </Badge>
        )
      case "published":
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400">Publicado</Badge>
      default:
        return null
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-2xl font-bold">Conteúdo para Redes Sociais</h1>

        <Dialog>
          <DialogTrigger asChild>
            <Button>
              <Upload className="mr-2 h-4 w-4" />
              Novo Conteúdo
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Adicionar Novo Conteúdo</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="title">Título</Label>
                <Input
                  id="title"
                  name="title"
                  value={uploadForm.title}
                  onChange={handleFormChange}
                  placeholder="Título do conteúdo"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Descrição/Legenda</Label>
                <Textarea
                  id="description"
                  name="description"
                  value={uploadForm.description}
                  onChange={handleFormChange}
                  placeholder="Descrição ou legenda para o post"
                  rows={3}
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="type">Tipo de Conteúdo</Label>
                  <Select value={uploadForm.type} onValueChange={(value) => handleSelectChange("type", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="image">Imagem</SelectItem>
                      <SelectItem value="video">Vídeo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="platform">Plataforma</Label>
                  <Select value={uploadForm.platform} onValueChange={(value) => handleSelectChange("platform", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a plataforma" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="instagram">Instagram</SelectItem>
                      <SelectItem value="facebook">Facebook</SelectItem>
                      <SelectItem value="twitter">Twitter</SelectItem>
                      <SelectItem value="linkedin">LinkedIn</SelectItem>
                      <SelectItem value="youtube">YouTube</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select value={uploadForm.status} onValueChange={(value) => handleSelectChange("status", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Rascunho</SelectItem>
                      <SelectItem value="scheduled">Agendado</SelectItem>
                      <SelectItem value="published">Publicado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {uploadForm.status === "scheduled" && (
                  <div className="space-y-2">
                    <Label htmlFor="scheduledDate">Data de Publicação</Label>
                    <Input
                      id="scheduledDate"
                      name="scheduledDate"
                      type="datetime-local"
                      value={uploadForm.scheduledDate}
                      onChange={handleFormChange}
                      required
                    />
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="tags">Tags (separadas por vírgula)</Label>
                <Input
                  id="tags"
                  name="tags"
                  value={uploadForm.tags}
                  onChange={handleFormChange}
                  placeholder="Ex: produto, lançamento, novidade"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="file">Arquivo de Mídia</Label>
                <Input
                  id="file"
                  type="file"
                  accept={uploadForm.type === "image" ? "image/*" : "video/*"}
                  onChange={handleFileChange}
                  required
                />
              </div>

              <div className="flex justify-end pt-4">
                <Button onClick={handleAddContent}>Adicionar Conteúdo</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Filtros</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar conteúdo..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger>
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os Tipos</SelectItem>
                <SelectItem value="image">Imagens</SelectItem>
                <SelectItem value="video">Vídeos</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterPlatform} onValueChange={setFilterPlatform}>
              <SelectTrigger>
                <SelectValue placeholder="Plataforma" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas as Plataformas</SelectItem>
                <SelectItem value="instagram">Instagram</SelectItem>
                <SelectItem value="facebook">Facebook</SelectItem>
                <SelectItem value="twitter">Twitter</SelectItem>
                <SelectItem value="linkedin">LinkedIn</SelectItem>
                <SelectItem value="youtube">YouTube</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger>
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os Status</SelectItem>
                <SelectItem value="draft">Rascunhos</SelectItem>
                <SelectItem value="scheduled">Agendados</SelectItem>
                <SelectItem value="published">Publicados</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="grid">
        <div className="flex justify-between items-center mb-4">
          <TabsList>
            <TabsTrigger value="grid">Grade</TabsTrigger>
            <TabsTrigger value="list">Lista</TabsTrigger>
            <TabsTrigger value="calendar">Calendário</TabsTrigger>
          </TabsList>

          <div className="text-sm text-muted-foreground">{sortedContent.length} itens encontrados</div>
        </div>

        <TabsContent value="grid">
          {sortedContent.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-8">
                <div className="rounded-full bg-muted p-3">
                  <ImageIcon className="h-6 w-6 text-muted-foreground" />
                </div>
                <h3 className="mt-4 text-lg font-medium">Nenhum conteúdo encontrado</h3>
                <p className="mt-2 text-sm text-muted-foreground text-center">
                  Não foram encontrados conteúdos com os filtros selecionados.
                  <br />
                  Tente ajustar os filtros ou adicionar novo conteúdo.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {sortedContent.map((content) => (
                <Card key={content.id} className="overflow-hidden">
                  <div className="aspect-video bg-muted relative">
                    <img
                      src={content.mediaUrl || "/placeholder.svg"}
                      alt={content.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-2 right-2 flex gap-1">
                      {renderStatusBadge(content.status, content.scheduledDate)}
                    </div>
                    <div className="absolute top-2 left-2">
                      <Badge variant="secondary" className="flex items-center gap-1">
                        {renderPlatformIcon(content.platform)}
                        {content.platform.charAt(0).toUpperCase() + content.platform.slice(1)}
                      </Badge>
                    </div>
                    <div className="absolute bottom-2 left-2">
                      <Badge variant="outline" className="bg-black/50 text-white border-none flex items-center gap-1">
                        {renderTypeIcon(content.type)}
                        {content.type === "image" ? "Imagem" : "Vídeo"}
                      </Badge>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-medium truncate">{content.title}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-2 mt-1">{content.description}</p>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {content.tags.map((tag) => (
                        <Badge key={tag} variant="outline" className="text-xs">
                          #{tag}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                  <div className="p-4 pt-0 flex justify-between items-center">
                    <div className="text-xs text-muted-foreground">
                      {new Date(content.created_at).toLocaleDateString("pt-BR")}
                    </div>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleDeleteContent(content.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="list">
          <Card>
            <CardContent className="p-0">
              {sortedContent.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-8">
                  <div className="rounded-full bg-muted p-3">
                    <ImageIcon className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <h3 className="mt-4 text-lg font-medium">Nenhum conteúdo encontrado</h3>
                  <p className="mt-2 text-sm text-muted-foreground text-center">
                    Não foram encontrados conteúdos com os filtros selecionados.
                    <br />
                    Tente ajustar os filtros ou adicionar novo conteúdo.
                  </p>
                </div>
              ) : (
                <div className="divide-y">
                  {sortedContent.map((content) => (
                    <div key={content.id} className="flex items-start gap-4 p-4">
                      <div className="w-16 h-16 bg-muted rounded-md overflow-hidden flex-shrink-0">
                        <img
                          src={content.mediaUrl || "/placeholder.svg"}
                          alt={content.title}
                          className="w-full h-full object-cover"
                        />
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-2">
                          <h3 className="font-medium truncate">{content.title}</h3>
                          <div className="flex flex-wrap gap-1">
                            <Badge variant="secondary" className="flex items-center gap-1">
                              {renderPlatformIcon(content.platform)}
                              {content.platform.charAt(0).toUpperCase() + content.platform.slice(1)}
                            </Badge>
                            {renderStatusBadge(content.status, content.scheduledDate)}
                          </div>
                        </div>

                        <p className="text-sm text-muted-foreground line-clamp-2 mt-1">{content.description}</p>

                        <div className="flex justify-between items-center mt-2">
                          <div className="flex flex-wrap gap-1">
                            {content.tags.slice(0, 3).map((tag) => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                #{tag}
                              </Badge>
                            ))}
                            {content.tags.length > 3 && (
                              <Badge variant="outline" className="text-xs">
                                +{content.tags.length - 3}
                              </Badge>
                            )}
                          </div>

                          <div className="flex gap-1">
                            <Button variant="ghost" size="icon">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => handleDeleteContent(content.id)}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="calendar">
          <Card>
            <CardHeader>
              <CardTitle>Calendário de Publicações</CardTitle>
              <CardDescription>Visualize e gerencie suas publicações agendadas</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <div className="rounded-full bg-muted p-3 inline-block">
                  <Calendar className="h-6 w-6 text-muted-foreground" />
                </div>
                <h3 className="mt-4 text-lg font-medium">Calendário em Desenvolvimento</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  A visualização de calendário estará disponível em breve.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
