"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { useSupabaseData } from "@/hooks/use-supabase-data"
import { useAuth } from "@/context/auth-context"
import { ArrowLeft, Plus, Edit, Trash2, Clock, AlertCircle } from "lucide-react"
import RoutineForm from "@/components/routine-form"
import TaskForm from "@/components/task-form"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/components/ui/use-toast"

export default function RotineDetailPage() {
  const params = useParams()
  const router = useRouter()
  const routineId = params.id as string
  const { user } = useAuth()
  const {
    data: routines,
    updateItem: updateRoutine,
    removeItem: removeRoutine,
    fetchData: fetchRoutines,
    isLoading: isLoadingRoutine,
  } = useSupabaseData("routines", [])
  const {
    data: tasks,
    addItem: addTask,
    updateItem: updateTask,
    removeItem: removeTask,
    fetchData: fetchTasks,
    isLoading: isLoadingTasks,
  } = useSupabaseData("tasks", [], { filter: { routine_id: routineId } })
  const [routine, setRoutine] = useState<any>(null)
  const [editingTask, setEditingTask] = useState<any>(null)
  const { toast } = useToast()

  useEffect(() => {
    const foundRoutine = routines.find((r: any) => r.id === routineId)
    setRoutine(foundRoutine)
  }, [routines, routineId])

  const handleDeleteRoutine = async () => {
    if (confirm("Tem certeza que deseja excluir esta rotina? Todas as tarefas associadas também serão excluídas.")) {
      const success = await removeRoutine(routineId)
      if (success) {
        toast({
          title: "Rotina excluída",
          description: "A rotina foi excluída com sucesso.",
        })
        router.push("/dashboard/rotinas")
      }
    }
  }

  const handleTaskStatusChange = async (task: any, completed: boolean) => {
    await updateTask(task.id, { completed })
  }

  const handleDeleteTask = async (taskId: string) => {
    if (confirm("Tem certeza que deseja excluir esta tarefa?")) {
      const success = await removeTask(taskId)
      if (success) {
        toast({
          title: "Tarefa excluída",
          description: "A tarefa foi excluída com sucesso.",
        })
      }
    }
  }

  if (isLoadingRoutine) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Carregando rotina...</p>
        </div>
      </div>
    )
  }

  if (!routine) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <AlertCircle className="mx-auto h-10 w-10 text-muted-foreground" />
          <h2 className="mt-2 text-xl font-semibold">Rotina não encontrada</h2>
          <p className="mt-1 text-muted-foreground">A rotina que você está procurando não existe ou foi removida.</p>
          <Button className="mt-4" onClick={() => router.push("/dashboard/rotinas")}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Voltar para Rotinas
          </Button>
        </div>
      </div>
    )
  }

  const completedTasks = tasks.filter((task: any) => task.completed).length
  const progress = tasks.length > 0 ? (completedTasks / tasks.length) * 100 : 0

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <Button variant="outline" onClick={() => router.push("/dashboard/rotinas")}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar
        </Button>

        <div className="flex gap-2">
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Edit className="mr-2 h-4 w-4" />
                Editar Rotina
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Editar Rotina</DialogTitle>
              </DialogHeader>
              <RoutineForm
                routine={routine}
                onSuccess={() => {
                  fetchRoutines()
                }}
              />
            </DialogContent>
          </Dialog>

          <Button variant="destructive" onClick={handleDeleteRoutine}>
            <Trash2 className="mr-2 h-4 w-4" />
            Excluir Rotina
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">{routine.name}</CardTitle>
              <div className="flex flex-wrap gap-2 mt-2">
                <Badge>{routine.category}</Badge>
                <Badge variant="outline">
                  <Clock className="mr-1 h-4 w-4" />
                  {routine.frequency}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              {routine.description && <p className="text-muted-foreground mb-6">{routine.description}</p>}

              <div className="mb-6">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium">
                    Progresso: {completedTasks}/{tasks.length} tarefas
                  </span>
                  <span className="text-sm font-medium">{Math.round(progress)}%</span>
                </div>
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary"
                    style={{ width: `${progress}%`, transition: "width 0.3s ease" }}
                  ></div>
                </div>
              </div>

              <Separator className="my-6" />

              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-medium">Tarefas</h3>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="mr-2 h-4 w-4" />
                        Adicionar Tarefa
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Adicionar Tarefa</DialogTitle>
                      </DialogHeader>
                      <TaskForm
                        routineId={routineId}
                        onSuccess={() => {
                          fetchTasks()
                        }}
                      />
                    </DialogContent>
                  </Dialog>
                </div>

                {isLoadingTasks ? (
                  <div className="space-y-2">
                    {[1, 2, 3].map((i) => (
                      <div
                        key={i}
                        className="flex items-center justify-between p-3 bg-muted/50 rounded-md animate-pulse"
                      >
                        <div className="h-5 w-1/3 bg-muted rounded" />
                        <div className="h-4 w-1/4 bg-muted rounded" />
                      </div>
                    ))}
                  </div>
                ) : tasks.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">Nenhuma tarefa cadastrada para esta rotina.</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Clique em "Adicionar Tarefa" para começar a criar sua rotina.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {tasks.map((task: any) => (
                      <div key={task.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-md">
                        <div className="flex items-center gap-3 flex-1">
                          <Checkbox
                            checked={task.completed}
                            onCheckedChange={(checked) => handleTaskStatusChange(task, !!checked)}
                          />
                          <div className={task.completed ? "line-through text-muted-foreground" : ""}>
                            <div className="font-medium">{task.name}</div>
                            {task.description && <p className="text-sm text-muted-foreground">{task.description}</p>}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">{task.priority}</Badge>
                          <Badge variant="outline">{task.duration} min</Badge>
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <Edit className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Editar Tarefa</DialogTitle>
                              </DialogHeader>
                              <TaskForm
                                task={task}
                                routineId={routineId}
                                onSuccess={() => {
                                  fetchTasks()
                                }}
                              />
                            </DialogContent>
                          </Dialog>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-destructive"
                            onClick={() => handleDeleteTask(task.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Detalhes</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Criada em</span>
                <span>{new Date(routine.created_at).toLocaleDateString()}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Última atualização</span>
                <span>{new Date(routine.updated_at).toLocaleDateString()}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Total de tarefas</span>
                <span>{tasks.length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Tarefas concluídas</span>
                <span>{completedTasks}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Progresso</span>
                <span>{Math.round(progress)}%</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Dicas</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <ul className="text-sm space-y-2 list-disc pl-5 text-muted-foreground">
                <li>Marque as tarefas como concluídas para acompanhar seu progresso</li>
                <li>Adicione descrições detalhadas para cada tarefa</li>
                <li>Defina prioridades para focar no que é mais importante</li>
                <li>Estabeleça durações realistas para cada tarefa</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Modal de edição de tarefa */}
      <Dialog open={!!editingTask} onOpenChange={(open) => !open && setEditingTask(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Tarefa</DialogTitle>
          </DialogHeader>
          {editingTask && (
            <TaskForm
              task={editingTask}
              routineId={routineId}
              onSuccess={() => {
                fetchTasks()
                setEditingTask(null)
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
