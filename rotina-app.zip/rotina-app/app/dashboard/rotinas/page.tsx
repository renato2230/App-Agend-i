"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { useSupabaseData } from "@/hooks/use-supabase-data"
import { Plus, Search, Calendar, List, Grid3X3, Clock, Edit, Trash2, ArrowRight } from "lucide-react"
import RoutineForm from "@/components/routine-form"
import { useToast } from "@/components/ui/use-toast"

export default function RotinasPage() {
  const router = useRouter()
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null)
  const [showAddRoutine, setShowAddRoutine] = useState(false)
  const { data: routines, isLoading, fetchData, removeItem } = useSupabaseData("routines", [])
  const { toast } = useToast()

  const handleDeleteRoutine = async (id: string) => {
    if (confirm("Tem certeza que deseja excluir esta rotina? Todas as tarefas associadas também serão excluídas.")) {
      const success = await removeItem(id)
      if (success) {
        toast({
          title: "Rotina excluída",
          description: "A rotina foi excluída com sucesso.",
        })
      }
    }
  }

  const filteredRoutines = routines.filter((routine: any) => {
    const matchesSearch =
      routine.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (routine.description && routine.description.toLowerCase().includes(searchTerm.toLowerCase()))
    const matchesCategory = !categoryFilter || routine.category === categoryFilter
    return matchesSearch && matchesCategory
  })

  const categories = Array.from(new Set(routines.map((routine: any) => routine.category)))

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Rotinas</h2>
          <p className="text-muted-foreground">Gerencie suas rotinas diárias, semanais e mensais.</p>
        </div>
        <Dialog open={showAddRoutine} onOpenChange={setShowAddRoutine}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Nova Rotina
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Criar Nova Rotina</DialogTitle>
            </DialogHeader>
            <RoutineForm
              onSuccess={() => {
                fetchData()
                setShowAddRoutine(false)
              }}
            />
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar rotinas..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant={categoryFilter === null ? "default" : "outline"}
            size="sm"
            onClick={() => setCategoryFilter(null)}
          >
            Todas
          </Button>
          {categories.map((category) => (
            <Button
              key={category}
              variant={categoryFilter === category ? "default" : "outline"}
              size="sm"
              onClick={() => setCategoryFilter(category)}
            >
              {category}
            </Button>
          ))}
        </div>
      </div>

      <Tabs defaultValue="grid">
        <div className="flex justify-between items-center">
          <TabsList>
            <TabsTrigger value="grid">
              <Grid3X3 className="h-4 w-4 mr-2" />
              Grade
            </TabsTrigger>
            <TabsTrigger value="list">
              <List className="h-4 w-4 mr-2" />
              Lista
            </TabsTrigger>
            <TabsTrigger value="calendar">
              <Calendar className="h-4 w-4 mr-2" />
              Calendário
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="grid" className="mt-6">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <Card key={i} className="animate-pulse">
                  <CardHeader className="h-24 bg-muted rounded-t-lg" />
                  <CardContent className="py-4">
                    <div className="h-4 w-3/4 bg-muted rounded mb-2" />
                    <div className="h-3 w-1/2 bg-muted rounded" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredRoutines.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground">Nenhuma rotina encontrada.</p>
              <Button className="mt-4" onClick={() => setShowAddRoutine(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Criar Nova Rotina
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredRoutines.map((routine: any) => (
                <Card key={routine.id} className="overflow-hidden">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-xl">{routine.name}</CardTitle>
                      <Badge>{routine.category}</Badge>
                    </div>
                    <CardDescription>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Clock className="mr-1 h-3 w-3" />
                        {routine.frequency}
                      </div>
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pb-2">
                    {routine.description && (
                      <p className="text-sm text-muted-foreground line-clamp-2">{routine.description}</p>
                    )}
                  </CardContent>
                  <CardFooter className="flex justify-between pt-0">
                    <div className="flex gap-2">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm">
                            <Edit className="h-3.5 w-3.5 mr-1" />
                            Editar
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Editar Rotina</DialogTitle>
                          </DialogHeader>
                          <RoutineForm
                            routine={routine}
                            onSuccess={() => {
                              fetchData()
                            }}
                          />
                        </DialogContent>
                      </Dialog>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-destructive"
                        onClick={() => handleDeleteRoutine(routine.id)}
                      >
                        <Trash2 className="h-3.5 w-3.5 mr-1" />
                        Excluir
                      </Button>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-primary"
                      onClick={() => router.push(`/dashboard/rotinas/${routine.id}`)}
                    >
                      Detalhes
                      <ArrowRight className="ml-1 h-3.5 w-3.5" />
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="list" className="mt-6">
          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-4">
                    <div className="h-5 w-1/3 bg-muted rounded mb-2" />
                    <div className="h-4 w-1/2 bg-muted rounded" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredRoutines.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground">Nenhuma rotina encontrada.</p>
              <Button className="mt-4" onClick={() => setShowAddRoutine(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Criar Nova Rotina
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredRoutines.map((routine: any) => (
                <Card key={routine.id} className="overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h3 className="font-medium">{routine.name}</h3>
                          <Badge>{routine.category}</Badge>
                          <Badge variant="outline">
                            <Clock className="mr-1 h-3 w-3" />
                            {routine.frequency}
                          </Badge>
                        </div>
                        {routine.description && <p className="text-sm text-muted-foreground">{routine.description}</p>}
                      </div>
                      <div className="flex gap-2 self-end sm:self-auto">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="outline" size="sm">
                              <Edit className="h-3.5 w-3.5 mr-1" />
                              Editar
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Editar Rotina</DialogTitle>
                            </DialogHeader>
                            <RoutineForm
                              routine={routine}
                              onSuccess={() => {
                                fetchData()
                              }}
                            />
                          </DialogContent>
                        </Dialog>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-destructive"
                          onClick={() => handleDeleteRoutine(routine.id)}
                        >
                          <Trash2 className="h-3.5 w-3.5 mr-1" />
                          Excluir
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-primary"
                          onClick={() => router.push(`/dashboard/rotinas/${routine.id}`)}
                        >
                          Detalhes
                          <ArrowRight className="ml-1 h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="calendar" className="mt-6">
          <Card>
            <CardContent className="p-6">
              <div className="text-center py-12">
                <p className="text-muted-foreground">Visualização de calendário em desenvolvimento.</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Em breve você poderá visualizar suas rotinas em um calendário.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
