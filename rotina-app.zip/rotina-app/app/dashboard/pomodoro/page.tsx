"use client"

import { useState, useEffect, useRef } from "react"
import { Play, Pause, RotateCcw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useLocalStorage } from "@/hooks/use-local-storage"

export default function PomodoroPage() {
  const [mode, setMode] = useState<"work" | "shortBreak" | "longBreak">("work")
  const [timeLeft, setTimeLeft] = useState(25 * 60) // 25 minutos em segundos
  const [isActive, setIsActive] = useState(false)
  const [cycles, setCycles] = useState(0)
  const [settings, setSettings] = useLocalStorage("pomodoroSettings", {
    work: 25,
    shortBreak: 5,
    longBreak: 15,
    longBreakInterval: 4,
  })

  const timerRef = useRef<NodeJS.Timeout | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  useEffect(() => {
    audioRef.current = new Audio("/notification.mp3")

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
    }
  }, [])

  useEffect(() => {
    // Atualiza o tempo quando o modo muda
    switch (mode) {
      case "work":
        setTimeLeft(settings.work * 60)
        break
      case "shortBreak":
        setTimeLeft(settings.shortBreak * 60)
        break
      case "longBreak":
        setTimeLeft(settings.longBreak * 60)
        break
    }

    setIsActive(false)
    if (timerRef.current) {
      clearInterval(timerRef.current)
    }
  }, [mode, settings])

  useEffect(() => {
    if (isActive) {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            // Timer acabou
            if (timerRef.current) clearInterval(timerRef.current)
            playNotification()
            handleTimerComplete()
            return 0
          }
          return prev - 1
        })
      }, 1000)
    } else if (timerRef.current) {
      clearInterval(timerRef.current)
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current)
    }
  }, [isActive])

  const handleTimerComplete = () => {
    setIsActive(false)

    if (mode === "work") {
      const newCycles = cycles + 1
      setCycles(newCycles)

      if (newCycles % settings.longBreakInterval === 0) {
        setMode("longBreak")
      } else {
        setMode("shortBreak")
      }
    } else {
      setMode("work")
    }
  }

  const playNotification = () => {
    if (audioRef.current) {
      audioRef.current.play().catch((e) => console.error("Erro ao tocar áudio:", e))
    }
  }

  const toggleTimer = () => {
    setIsActive(!isActive)
  }

  const resetTimer = () => {
    setIsActive(false)
    if (timerRef.current) clearInterval(timerRef.current)

    switch (mode) {
      case "work":
        setTimeLeft(settings.work * 60)
        break
      case "shortBreak":
        setTimeLeft(settings.shortBreak * 60)
        break
      case "longBreak":
        setTimeLeft(settings.longBreak * 60)
        break
    }
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const calculateProgress = () => {
    let total
    switch (mode) {
      case "work":
        total = settings.work * 60
        break
      case "shortBreak":
        total = settings.shortBreak * 60
        break
      case "longBreak":
        total = settings.longBreak * 60
        break
      default:
        total = 25 * 60
    }

    const progress = (1 - timeLeft / total) * 283 // 283 é o perímetro aproximado do círculo
    return progress
  }

  const handleSettingChange = (key: keyof typeof settings, value: string) => {
    setSettings({
      ...settings,
      [key]: Number.parseInt(value),
    })
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Pomodoro Timer</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Timer</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center">
            <div className="flex space-x-4 mb-8">
              <Button variant={mode === "work" ? "default" : "outline"} onClick={() => setMode("work")}>
                Trabalho
              </Button>
              <Button variant={mode === "shortBreak" ? "default" : "outline"} onClick={() => setMode("shortBreak")}>
                Pausa Curta
              </Button>
              <Button variant={mode === "longBreak" ? "default" : "outline"} onClick={() => setMode("longBreak")}>
                Pausa Longa
              </Button>
            </div>

            <div className="relative w-64 h-64 mb-8">
              <svg className="w-full h-full" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r="45"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  className="text-muted"
                />
                <circle
                  cx="50"
                  cy="50"
                  r="45"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="5"
                  strokeDasharray="283"
                  strokeDashoffset={283 - calculateProgress()}
                  className={`timer-circle ${
                    mode === "work" ? "text-primary" : mode === "shortBreak" ? "text-green-500" : "text-blue-500"
                  }`}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-4xl font-bold">{formatTime(timeLeft)}</span>
                <span className="text-sm text-muted-foreground capitalize">
                  {mode === "work" ? "Trabalho" : mode === "shortBreak" ? "Pausa Curta" : "Pausa Longa"}
                </span>
              </div>
            </div>

            <div className="flex space-x-4">
              <Button size="lg" onClick={toggleTimer} className={isActive ? "bg-red-500 hover:bg-red-600" : ""}>
                {isActive ? <Pause className="mr-2" /> : <Play className="mr-2" />}
                {isActive ? "Pausar" : "Iniciar"}
              </Button>
              <Button size="lg" variant="outline" onClick={resetTimer}>
                <RotateCcw className="mr-2" />
                Reiniciar
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Configurações</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Tempo de Trabalho (min)</label>
              <Select value={settings.work.toString()} onValueChange={(value) => handleSettingChange("work", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  {[15, 20, 25, 30, 35, 40, 45, 50, 55, 60].map((value) => (
                    <SelectItem key={value} value={value.toString()}>
                      {value}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Pausa Curta (min)</label>
              <Select
                value={settings.shortBreak.toString()}
                onValueChange={(value) => handleSettingChange("shortBreak", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  {[3, 5, 7, 10].map((value) => (
                    <SelectItem key={value} value={value.toString()}>
                      {value}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Pausa Longa (min)</label>
              <Select
                value={settings.longBreak.toString()}
                onValueChange={(value) => handleSettingChange("longBreak", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  {[10, 15, 20, 25, 30].map((value) => (
                    <SelectItem key={value} value={value.toString()}>
                      {value}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Intervalo para Pausa Longa</label>
              <Select
                value={settings.longBreakInterval.toString()}
                onValueChange={(value) => handleSettingChange("longBreakInterval", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  {[2, 3, 4, 5, 6].map((value) => (
                    <SelectItem key={value} value={value.toString()}>
                      {value}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="pt-4 border-t">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Ciclos completados</span>
                <span className="font-bold">{cycles}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Dicas para usar o Pomodoro</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 list-disc pl-5">
            <li>Escolha uma tarefa para trabalhar</li>
            <li>Configure o timer para 25 minutos (ou seu tempo preferido)</li>
            <li>Trabalhe na tarefa até o timer tocar</li>
            <li>Faça uma pausa curta (5 minutos)</li>
            <li>A cada 4 pomodoros, faça uma pausa mais longa (15-30 minutos)</li>
            <li>Repita o processo</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}
