"use client"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import ProfileForm from "@/components/profile-form"
import { useLocalStorage } from "@/hooks/use-local-storage"
import { CalendarCheck2, FileText, User } from "lucide-react"
import ClientList from "@/components/client-list"
import BudgetCreator from "@/components/budget-creator"

export default function PerfilPage() {
  const [profileData] = useLocalStorage("profileData", {
    nome: "Carlos Silva",
    profissao: "Designer Gráfico",
    telefone: "(11) 98765-4321",
    email: "carlos@exemplo.com",
    website: "www.carlosdesign.com.br",
    bio: "Designer gráfico com mais de 5 anos de experiência em identidade visual e materiais promocionais.",
  })

  const [stats] = useLocalStorage("profileStats", {
    clientesAtivos: 12,
    projetosEmAndamento: 5,
    orcamentosEnviados: 28,
    taxaConversao: "68%",
  })

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Meu Perfil Profissional</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {Object.entries(stats).map(([key, value], index) => {
          const icons = [
            <User key="user" className="h-5 w-5 text-white" />,
            <FileText key="file" className="h-5 w-5 text-white" />,
            <CalendarCheck2 key="calendar" className="h-5 w-5 text-white" />,
            <FileText key="file2" className="h-5 w-5 text-white" />,
          ]

          const titles = {
            clientesAtivos: "Clientes Ativos",
            projetosEmAndamento: "Projetos Atuais",
            orcamentosEnviados: "Orçamentos Enviados",
            taxaConversao: "Taxa de Conversão",
          }

          const colors = ["bg-primary", "bg-blue-500", "bg-amber-500", "bg-purple-500"]

          return (
            <div key={key} className="bg-card rounded-lg shadow p-6">
              <div className="flex items-center">
                <div className={`p-3 rounded-full ${colors[index % colors.length]}`}>{icons[index % icons.length]}</div>
                <div className="ml-4">
                  <h3 className="text-lg font-semibold">{titles[key as keyof typeof titles]}</h3>
                  <p className="text-2xl font-bold">{value}</p>
                </div>
              </div>
            </div>
          )
        })}
      </div>

      <Tabs defaultValue="perfil" className="w-full">
        <TabsList className="grid grid-cols-3 mb-8">
          <TabsTrigger value="perfil">Perfil</TabsTrigger>
          <TabsTrigger value="clientes">Clientes</TabsTrigger>
          <TabsTrigger value="orcamentos">Orçamentos</TabsTrigger>
        </TabsList>

        <TabsContent value="perfil" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Informações do Perfil</CardTitle>
              <CardDescription>
                Gerencie suas informações profissionais que serão exibidas para seus clientes.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ProfileForm initialData={profileData} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="clientes" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Agenda de Clientes</CardTitle>
              <CardDescription>Gerencie seus clientes e acompanhe seus compromissos.</CardDescription>
            </CardHeader>
            <CardContent>
              <ClientList />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="orcamentos" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Gerador de Orçamentos</CardTitle>
              <CardDescription>Crie orçamentos rápidos para enviar aos seus clientes via WhatsApp.</CardDescription>
            </CardHeader>
            <CardContent>
              <BudgetCreator />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
