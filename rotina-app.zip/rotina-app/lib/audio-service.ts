export class AudioService {
  private sounds: Map<string, HTMLAudioElement> = new Map()
  private volume = 0.5
  private isSupported = true

  constructor() {
    // Verificar se o áudio é suportado no navegador
    this.isSupported = typeof Audio !== "undefined"
  }

  // Carregar um som com melhor tratamento de erros
  async loadSound(id: string, url: string): Promise<boolean> {
    if (!this.isSupported) {
      return false
    }

    return new Promise((resolve) => {
      try {
        const audio = new Audio()

        // Configurar eventos
        audio.addEventListener(
          "canplaythrough",
          () => {
            this.sounds.set(id, audio)
            resolve(true)
          },
          { once: true },
        )

        audio.addEventListener(
          "error",
          () => {
            console.warn(`Não foi possível carregar o som: ${id}`)
            resolve(false)
          },
          { once: true },
        )

        // Definir a fonte e iniciar o carregamento
        audio.src = url
        audio.volume = this.volume
        audio.load()
      } catch (error) {
        console.warn(`Erro ao criar elemento de áudio para ${id}:`, error)
        resolve(false)
      }
    })
  }

  // Reproduzir um som com verificação de suporte
  playSound(id: string): void {
    if (!this.isSupported) return

    const sound = this.sounds.get(id)
    if (sound) {
      try {
        // Criar uma nova instância para permitir reproduções sobrepostas
        const clone = new Audio(sound.src)
        clone.volume = this.volume

        clone.play().catch((error) => {
          console.warn(`Erro ao reproduzir som ${id}:`, error)
        })
      } catch (error) {
        console.warn(`Erro ao clonar som ${id}:`, error)
      }
    }
  }

  // Parar um som
  stopSound(id: string): void {
    if (!this.isSupported) return

    const sound = this.sounds.get(id)
    if (sound) {
      try {
        sound.pause()
        sound.currentTime = 0
      } catch (error) {
        console.warn(`Erro ao parar som ${id}:`, error)
      }
    }
  }

  // Parar todos os sons
  stopAllSounds(): void {
    if (!this.isSupported) return

    this.sounds.forEach((sound, id) => {
      try {
        sound.pause()
        sound.currentTime = 0
      } catch (error) {
        console.warn(`Erro ao parar som ${id}:`, error)
      }
    })
  }

  // Definir o volume (0.0 a 1.0)
  setVolume(volume: number): void {
    this.volume = Math.max(0, Math.min(1, volume))

    if (!this.isSupported) return

    this.sounds.forEach((sound) => {
      try {
        sound.volume = this.volume
      } catch (error) {
        console.warn("Erro ao definir volume:", error)
      }
    })
  }

  // Verificar se um som está carregado
  isSoundLoaded(id: string): boolean {
    return this.sounds.has(id)
  }

  // Obter a lista de sons carregados
  getLoadedSounds(): string[] {
    return Array.from(this.sounds.keys())
  }

  // Liberar recursos
  dispose(): void {
    this.stopAllSounds()
    this.sounds.clear()
  }
}
