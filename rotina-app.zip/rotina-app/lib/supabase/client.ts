"use client"

import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"
import type { Database } from "@/lib/supabase/database.types"

// Singleton para o cliente Supabase
let supabaseInstance: ReturnType<typeof createClientComponentClient<Database>> | null = null

// Cria uma instância do cliente Supabase para componentes do lado do cliente
export const createClient = () => {
  try {
    // Verificar se estamos no navegador
    if (typeof window === "undefined") {
      return createMockClient()
    }

    // Verificar se já temos uma instância
    if (supabaseInstance) {
      return supabaseInstance
    }

    // Verificar se as variáveis de ambiente estão disponíveis
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

    if (!supabaseUrl || !supabaseKey) {
      console.error("Supabase URL or Key is missing. Using mock client.")
      return createMockClient()
    }

    // Criar uma nova instância
    supabaseInstance = createClientComponentClient<Database>({
      supabaseUrl,
      supabaseKey,
    })

    return supabaseInstance
  } catch (error) {
    console.error("Error creating Supabase client:", error)
    return createMockClient()
  }
}

// Cliente mock para desenvolvimento e fallback
function createMockClient() {
  console.warn("Using mock Supabase client. Some features may not work.")

  return {
    auth: {
      getSession: async () => ({ data: { session: null }, error: null }),
      getUser: async () => ({ data: { user: null }, error: null }),
      signInWithPassword: async () => ({ data: { user: null }, error: null }),
      signUp: async () => ({ data: { user: null }, error: null }),
      signOut: async () => ({ error: null }),
      onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {} } } }),
    },
    from: () => ({
      select: () => ({ data: [], error: null }),
      insert: () => ({ data: null, error: null }),
      update: () => ({ data: null, error: null }),
      delete: () => ({ data: null, error: null }),
      eq: () => ({ data: null, error: null }),
      order: () => ({ data: null, error: null }),
      single: () => ({ data: null, error: null }),
    }),
  } as any
}
