export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          updated_at: string | null
          username: string | null
          full_name: string | null
          avatar_url: string | null
          website: string | null
          onboarding_completed: boolean | null
        }
        Insert: {
          id: string
          updated_at?: string | null
          username?: string | null
          full_name?: string | null
          avatar_url?: string | null
          website?: string | null
          onboarding_completed?: boolean | null
        }
        Update: {
          id?: string
          updated_at?: string | null
          username?: string | null
          full_name?: string | null
          avatar_url?: string | null
          website?: string | null
          onboarding_completed?: boolean | null
        }
      }
      routines: {
        Row: {
          id: string
          created_at: string
          updated_at: string
          name: string
          description: string | null
          frequency: string
          category: string
          user_id: string
        }
        Insert: {
          id?: string
          created_at?: string
          updated_at?: string
          name: string
          description?: string | null
          frequency: string
          category: string
          user_id: string
        }
        Update: {
          id?: string
          created_at?: string
          updated_at?: string
          name?: string
          description?: string | null
          frequency?: string
          category?: string
          user_id?: string
        }
      }
      tasks: {
        Row: {
          id: string
          created_at: string
          updated_at: string
          name: string
          description: string | null
          duration: number
          priority: string
          completed: boolean
          routine_id: string
          user_id: string
          order: number
        }
        Insert: {
          id?: string
          created_at?: string
          updated_at?: string
          name: string
          description?: string | null
          duration?: number
          priority?: string
          completed?: boolean
          routine_id: string
          user_id: string
          order?: number
        }
        Update: {
          id?: string
          created_at?: string
          updated_at?: string
          name?: string
          description?: string | null
          duration?: number
          priority?: string
          completed?: boolean
          routine_id?: string
          user_id?: string
          order?: number
        }
      }
      social_media_posts: {
        Row: {
          id: string
          created_at: string
          updated_at: string
          title: string
          description: string | null
          media_url: string | null
          platform: string
          scheduled_date: string | null
          status: string
          user_id: string
          tags: string[] | null
        }
        Insert: {
          id?: string
          created_at?: string
          updated_at?: string
          title: string
          description?: string | null
          media_url?: string | null
          platform: string
          scheduled_date?: string | null
          status?: string
          user_id: string
          tags?: string[] | null
        }
        Update: {
          id?: string
          created_at?: string
          updated_at?: string
          title?: string
          description?: string | null
          media_url?: string | null
          platform?: string
          scheduled_date?: string | null
          status?: string
          user_id?: string
          tags?: string[] | null
        }
      }
      motivational_quotes: {
        Row: {
          id: string
          created_at: string
          quote: string
          author: string | null
          category: string | null
          is_active: boolean
        }
        Insert: {
          id?: string
          created_at?: string
          quote: string
          author?: string | null
          category?: string | null
          is_active?: boolean
        }
        Update: {
          id?: string
          created_at?: string
          quote?: string
          author?: string | null
          category?: string | null
          is_active?: boolean
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}
