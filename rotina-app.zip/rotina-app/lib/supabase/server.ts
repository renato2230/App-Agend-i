import { createServerComponentClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import type { Database } from "@/lib/supabase/database.types"

// Cria uma instância do cliente Supabase para componentes do lado do servidor
export const createClient = () => {
  try {
    // Verificar se as variáveis de ambiente estão disponíveis
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

    if (!supabaseUrl || !supabaseKey) {
      console.error("Supabase URL or Key is missing. Using mock client.")
      return createMockClient()
    }

    return createServerComponentClient<Database>({
      cookies,
      supabaseUrl,
      supabaseKey,
    })
  } catch (error) {
    console.error("Error creating server Supabase client:", error)
    return createMockClient()
  }
}

// Cliente mock para desenvolvimento e fallback
function createMockClient() {
  console.warn("Using mock Supabase server client. Some features may not work.")

  return {
    auth: {
      getSession: async () => ({ data: { session: null }, error: null }),
    },
    from: () => ({
      select: () => ({ data: [], error: null }),
    }),
  } as any
}
