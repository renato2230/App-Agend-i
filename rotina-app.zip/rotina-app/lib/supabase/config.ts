// Configuração do Supabase
export const supabaseConfig = {
  url: process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  anonKey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "",
  serviceKey: process.env.SUPABASE_SERVICE_ROLE_KEY || "",
}

// Verificar se as configurações do Supabase estão disponíveis
export function isSupabaseConfigured(): boolean {
  return Boolean(supabaseConfig.url && supabaseConfig.anonKey)
}

// Obter mensagem de erro para configuração do Supabase
export function getSupabaseConfigError(): string {
  if (!supabaseConfig.url) return "NEXT_PUBLIC_SUPABASE_URL is missing"
  if (!supabaseConfig.anonKey) return "NEXT_PUBLIC_SUPABASE_ANON_KEY is missing"
  return ""
}
